import sys
import os
import glob
import numpy
import plotCurves
from matplotlib import pyplot

def findBestExperiment():
 

  bestExp = None
  bestExpStats = numpy.zeros(3)

  targetDifferences = []

  experiments = glob.glob('customS/ghost*')

  for e in experiments:
    
    filename = os.path.join(e, 'clExperiment.txt')
    
    # Read file and compute average statistics
    avgStats = numpy.zeros(3)
    count = 0  
    f = open(filename, 'r')
    for line in f:
      elements = numpy.array(map(float, line.strip().split(' ')))
      avgStats += elements
      count += 1
    avgStats /= count

    # Update best experiment if average is better
    if (avgStats[2] > bestExpStats[2]):
      bestExpStats = avgStats
      bestExp = e

    # Extra data for plotting
    targetDifferences.append(avgStats[2])

  print bestExp
  print bestExpStats

  titleStr = 'Best Exp: %s\nTraining episodes needed: %d\nSource performance: %3.2f\nTarget difference: %3.2f' % (bestExp, bestExpStats[0], bestExpStats[1], bestExpStats[2])

  pyplot.hist(targetDifferences, 100)
  pyplot.title(titleStr)
  pyplot.xlabel('Difference between curves')
  pyplot.ylabel('Number of experiments')
#pyplot.savefig('recursiveExp1.png')
  pyplot.show()



def plotCurve(filename):

  windowSize = 20

  taskData = numpy.genfromtxt(filename)
  h = pyplot.plot(range(len(taskData)), plotCurves.mySmooth(taskData[:,1], windowSize), 'b-')
  pyplot.xlabel('Episode')
  pyplot.ylabel('Reward')
  pyplot.show()


if __name__=="__main__":
  findBestExperiment()
#  plotCurve(sys.argv[1])




