
import sys

def padPolicy(f, depth, pad):
  
  # Read old policy
  fin = open(f, 'r')
  oldPolicy = fin.readlines()
  fin.close()

  # Pad with 0s!
  for i in range(depth+1, depth+1+pad):
    oldPolicy.insert(i, str(0.0) + '\n')

  # Write back out saved policy
  fout = open(f, 'w')
  newPolicy = "".join(oldPolicy)
  fout.write(newPolicy)
  fout.close()


def main():

  args = sys.argv[1:]
  print args

  for a in args:
    padPolicy(a, 2, 2)

if __name__=="__main__":
  main()




