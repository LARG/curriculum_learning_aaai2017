function smoothed = mySmooth(data, window)

smoothed = zeros(length(data), 1);

for d=1:length(data)   
    smoothed(d) = mean(data(max([1,d-window]):d));   
end