
import numpy
from matplotlib import pyplot
import os



def mySmooth(data, window):
  smoothed = numpy.zeros((len(data), 1))
  for d in range(len(data)):
    smoothed[d] = numpy.mean(data[max(0, d-window):d])
  return smoothed

def myStepAgg(data, offset):
  smoothed = numpy.zeros((len(data), 1))
  smoothed[0] = offset
  for d in range(len(data)):
    if d > 0:
       smoothed[d] = data[d] + smoothed[d-1]
  return smoothed

def main():
  windowSize = 100
  directory = 'depthS/'


# Independent on target task
  targetTask = numpy.genfromtxt(os.path.join(directory, 'max_independent_1/avg_curve'))
  h2 = pyplot.plot(myStepAgg(targetTask[:,2], 0), mySmooth(targetTask[:,1], windowSize), 'r-', marker='8', markevery=100, label="Baseline Q-Learning Agent")

# Source task
  offset = 150100 #episodes:630
  srcTask = numpy.genfromtxt(os.path.join(directory, 'max_auto_curr7/avg_curve'))
  h1 = pyplot.plot(myStepAgg(srcTask[:,2], offset), mySmooth(srcTask[:,1], windowSize), 'b-', marker='D', markevery=100, label="Full generated curriculum")
  #srcVar = numpy.genfromtxt(os.path.join(directory, 'max_auto_curr/stdev_curve'))
  #pyplot.errorbar(range(offset, offset+len(srcVar)), srcTask[:,1], srcVar[:,1], linestyle='None', marker='^')
  
  #offset = 230
  #srcTask = numpy.genfromtxt(os.path.join(directory, 'max_auto_curr8/avg_curve'))
  #h1 = pyplot.plot(range(offset, offset+len(srcTask)), mySmooth(srcTask[:,1], windowSize), 'm--', marker='1', markevery=100, label="Old Handwritten Curriculum")
# Transfer
  #offset = 120
  #transferTask = numpy.genfromtxt(os.path.join(directory, 'max_shaping_1/avg_curve'))
  #h3 = pyplot.plot(range(offset, offset+len(transferTask)), mySmooth(transferTask[:,1], windowSize), 'g-', label="Hand-made Curriculum")

# Subsets
  offset = 2698852 # episodes: 930
  transferTask = numpy.genfromtxt(os.path.join(directory, 'max_shaping_s1/avg_curve'))
  h3 = pyplot.plot(myStepAgg(transferTask[:,2], offset), mySmooth(transferTask[:,1], windowSize), 'm--', marker='v', markevery=100, label="Hand Curriculum 1")

  offset = 2698852 #episodes: 580
  transferTask = numpy.genfromtxt(os.path.join(directory, 'max_shaping_s2/avg_curve'))
  h3 = pyplot.plot(myStepAgg(transferTask[:,2], offset), mySmooth(transferTask[:,1], windowSize), 'c--', marker='s', markevery=100, label="Hand Curriculum 2")

  offset = 2704852 #episodes 1410
  transferTask = numpy.genfromtxt(os.path.join(directory, 'max_shaping_s3/avg_curve'))
  h3 = pyplot.plot(myStepAgg(transferTask[:,2], offset), mySmooth(transferTask[:,1], windowSize), 'g--', marker='p', markevery = 100, label="Hand Curriculum 3")



#title1 = 'Task 1: Line ghosts'
#title2 = 'Task 2: Infinite edible time'

#title = title1 + '\n' + title2
  title = 'Multi-stage Curriculum Transfer'

  pyplot.legend(loc=4)
  #pyplot.title(title)
  pyplot.xlabel('Episodes of Training') 
  pyplot.ylabel('Expected Reward')

  #pyplot.savefig("/home/sanmit/Desktop/graph.png")

  pyplot.show()

if __name__=="__main__":
  main()

