 
close all;
clear;
clc;
hold on;

windowSize = 20;

directory = 'customS/';


%{
% Source task
src_curve = load('independent_1/avg_curve');
plot(src_curve(:,1), mySmooth(src_curve(:,2), windowSize), 'b-');

% Independent on target task
target_curve = load('independent_1k/avg_curve');
plot(target_curve(:,1), mySmooth(target_curve(:,2), windowSize), 'r-');


% Target with 200 episodes of transfer from source
transfer_curve = load('transfer_1/avg_curve');
plot(transfer_curve(:,1), mySmooth(transfer_curve(:,2), windowSize), 'g-')


legend('Source task', 'Target task', 'Target with transfer', 'Location', 'SouthEast')
xlabel('Episode')
ylabel('Reward')

%}

% Source task
src_curve = load([directory, 'independent_1/avg_curve']);
plot(src_curve(:,1), mySmooth(src_curve(:,2), windowSize), 'b-');

% Independent on target task
target_curve = load([directory, 'independent_1k/avg_curve']);
plot(target_curve(:,1), mySmooth(target_curve(:,2), windowSize), 'r-');


% Target with 200 episodes of transfer from source
transfer_curve = load([directory, 'transfer_1/avg_curve']);
plot(transfer_curve(:,1), mySmooth(transfer_curve(:,2), windowSize), 'g-')


legend('Source task', 'Target task', 'Target with transfer', 'Location', 'SouthEast')
xlabel('Episode')
ylabel('Reward')
title('Source task with line/clustering ghosts')



%{

% Independent on target task
target_curve = load('independent_1k/avg_curve');
plot(target_curve(:,1), mySmooth(target_curve(:,2), windowSize), 'r-');

src_curve = load('depth3_1k/avg_curve');
plot(src_curve(:,1), mySmooth(src_curve(:,2), windowSize), 'g-');

src_curve = load('depth3_noFuture_1k/avg_curve');
plot(src_curve(:,1), mySmooth(src_curve(:,2), windowSize), 'k-');

src_curve = load('depth2_1k/avg_curve');
plot(src_curve(:,1), mySmooth(src_curve(:,2), windowSize), 'b-');


legend('Depth 4', 'Depth 3', 'Depth 3 (no future)', 'Depth 2', 'Location', 'SouthEast')
xlabel('Episode')
ylabel('Reward')


%}

