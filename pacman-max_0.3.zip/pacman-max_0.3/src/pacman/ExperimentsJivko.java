package pacman;

import pacman.game.Constants;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.Buffer;
import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Queue;
import java.util.Random;

import javax.imageio.ImageIO;


import pacman.entries.ghosts.*;
import pacman.entries.pacman.BasicRLPacMan;
import pacman.entries.pacman.CustomFeatureSet;
import pacman.entries.pacman.CustomFeatureSetV2;
import pacman.entries.pacman.DepthFeatureSet;
import pacman.entries.pacman.FeatureSet;
import pacman.entries.pacman.QPacMan;
import pacman.entries.pacman.RLPacMan;
import pacman.entries.pacman.SarsaPacMan;
import pacman.game.Game;
import pacman.game.GameView;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.internal.Maze;
import pacman.teaching.AdviseAtFirst;
import pacman.teaching.AdviseImportantStates;
import pacman.teaching.CorrectImportantMistakes;
import pacman.teaching.PredictImportantMistakes;
import pacman.teaching.Student;
import pacman.teaching.TeachingStrategy;
import pacman.utils.DataFile;
import pacman.utils.LearningCurve;
import pacman.utils.Stats;

public class ExperimentsJivko {
	
// Note on notation:
// custom refers to the CustomFeatureSet (using something else defaults to DepthFeatureSet)
// S refers to SarsaPacMan (using something else defaults to QPacMan)
	
	
/* 	4 options for RLPacMan learner type
 * 		- teacher: teacher RLPacMan loads policy
 * 		- independent: student starts from scratch
 * 		- transfer: student loads policy
 * 		- (baseline, advise, correct, predict): uses teacher+independent and a strategy for teacher 
 * 
 * 	Notes on folder names in mydata
 * 		- mydata/TEACHER/STUDENT/LEARNER-TYPE_MAZE-NUM/
 * 
 * 
 * 
 */	
	
	public static String TEACHER = "depthS"; // Teacher feature set and algorithm
	public static String STUDENT = "depthS"; // Student feature set and algorithm
	public static String dataDir = "/home/jsinapov/research/TL-RL/pacman/";
	public static String pathSep = "/";
	public static String DIR = dataDir+TEACHER+pathSep+STUDENT; // Where to store data
	
	public static int BUDGET = 1000; // Advice budget
	public static int REPEATS = 5; //10; //30 // Curves to average
	public static int LENGTH = 500; // 10; // 100; // Points per curve
	public static int SAVE_POLICY_K = 25; //save policy every k train episodes
	public static int TRANSFER_POLICY_K = -1;
	public static int TEST = 1; //30; // Test episodes per point
	public static int TRAIN = 1; //10 // Train episodes per point

	public static Random rng = new Random();
	
	// Ghost "policies"
	public static StandardGhosts ghostsS = new StandardGhosts();
    public static RandomGhosts ghostsR = new RandomGhosts();
    public static ChaserGhosts ghostsC = new ChaserGhosts();
    public static LineGhosts ghostsL = new LineGhosts();
    
    public static int ghostType = 0;		// 0 = RandomGhosts, 1 = StandardGhosts, 2 = ChaserGhosts
    
    // Task parameters
    public static int mazeNum = 0;
    // Controls how fast ghosts move when pacman has eaten power pill. Lower numbers = slower (1 = frozen). 
    public static int ghostSlowdown = 2;
    public static int nGhosts = 4;
    
    public static String sourceTask = "independent_1";
    
    public static Constants defaultConstants;
    
	/**
	 * Run experiments.
	 */
	public static void main(String[] args) {

		
		System.out.println("Calling INNER Experiments program");
			
		demo();
		
		
		//computeBaselineEX1();
		
		
		//computeTransferEX1();
		
		//Step 2: transfer : TO DO
		
		//game parameters
		/*mazeNum = 0; //which maze;
		ghostType = 0; //which of three types of ghosts
		ghostSlowdown = 8; //ghost speed
		nGhosts = 4; //how many ghosts
		
		
		
		//train on source task
		train("independent", 0) ;*/
		
		
		
		
		//now, change the parameters...
		
		//train on target task
		//train("transfer", 0);
		
		// STANDARD SOURCE TASK
		/*mazeNum = 1;
		ghostType = 1;
		LENGTH = 1000;
		REPEATS = 1;
		ghostSlowdown = 2;*/
		//train("independent", 0);
		
		/*RLPacMan pacman = create("transfer", 0);		// Technically all the policies are after 10 episodes of training (i.e. you can use 0-9 for the 9 here)
		watch(pacman);*/
		
/*		// SOURCE TASK: Chaser ghosts
		mazeNum = 1;
		ghostType = 2;
		LENGTH = 600;
		ghostSlowdown = 2;
		train("independent", 0);
*/		
		
		
		
/*		//Train directly on real, target task: no transfer
		mazeNum=1;
		ghostType=1;
//		LENGTH=10;
		ghostSlowdown=2;
		train("independent",0);
*/
		
/*		//Train on real, target task: use transfer
		mazeNum=1;
		ghostType=1;
		//LENGTH=1000;
		ghostSlowdown=2;
		train("transfer", 0);
*/		

		// Source task: 3 ghosts on target maze, with some slowdown
		/*mazeNum = 1;
		ghostType = 1;
		LENGTH = 20;
		ghostSlowdown = 2;
		nGhosts = 4;
		train("independent", 0,true);*/
	
		
		// WATCH!
		
		/*mazeNum = 1;
		ghostType = 1;
//		LENGTH=10;
		ghostSlowdown=2;
		nGhosts = 4;
		RLPacMan pacman = create("transfer", 0);		// Technically all the policies are after 10 episodes of training (i.e. you can use 0-9 for the 9 here)
		watch(pacman);*/
		
		
		
		/*defaultConstants = new Constants();
		mazeNum = 0; //which maze;
		for (int m = 0; m <= 3; m++){
			defaultConstants.MAZE_NUM = m;
			System.out.println("\n\nFeatures for maze "+ m);
			computeGraphFeatures();
		}*/
	}
	
	
	
	public static void demo(){
		defaultConstants = new Constants();
		
		//train params
		LENGTH = 300; //how many train episodes
		REPEATS = 1; 
		SAVE_POLICY_K = 1;
		TEST = 1;
				
		mazeNum = 2; //which maze;
		ghostType = 1; //which of three types of ghosts
		ghostSlowdown = 2; //ghost speed
		nGhosts = 4; //how many ghosts
		
		defaultConstants.MAZE_NUM = mazeNum; //which maze;
		defaultConstants.GHOST_TYPE = ghostType; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = ghostSlowdown; //ghost speed
		defaultConstants.NUM_GHOSTS = nGhosts; //how many ghosts
		//defaultConstants.nodeNames[4]="mymaze";
		//defaultConstants.distNames[4]="dmymaze";
	
		//increase delay for watching
		defaultConstants.DELAY = defaultConstants.DELAY*5;
				
		//train
		String demo_name = "independent_temp";
		//train(demo_name,0,false,false);
		//trainFD(demo_name, 0, false,true);
				
		//transfer and watch
		sourceTask = generateDirectoryName(demo_name,
					mazeNum,ghostType,ghostSlowdown,nGhosts);

				
		//test params
		mazeNum = 0; //which maze;
		ghostType = 1; //which of three types of ghosts
		ghostSlowdown = 2; //ghost speed
		nGhosts = 4; //how many ghosts
		
		defaultConstants.MAZE_NUM = mazeNum; //which maze;
		defaultConstants.GHOST_TYPE = ghostType; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = ghostSlowdown; //ghost speed
		defaultConstants.NUM_GHOSTS = nGhosts; //how many ghosts
		
		TRANSFER_POLICY_K = -1; //at what point to transfer (-1 means at the end of the source task)
				
		RLPacMan pacman = create("transfer_demo", 0);		
		((SarsaPacMan)pacman).debug=false;
		//watch(pacman,false);
		watchAndSave(pacman,false,"pacman_frame_","/home/jsinapov/research/TL-RL/papers/AAMAS_2015/videos/videos_ARFL/v6");
	}
	
	public static void computeTransferEX1(){
		//training params
		LENGTH = 300; //how many train episodes
								
		//experiment params
		REPEATS = 5; 
		SAVE_POLICY_K = 1; 
			
		ArrayList<String> source_tasks_lines = new ArrayList<String>();
		
		ArrayList<String> source_task_names = new ArrayList<String>();
		
		
		//Step 1: generate an index of source tasks
		DataFile task_index_file = new DataFile(new String(DIR+"/task_index.csv"));
		task_index_file.clear();
		task_index_file.append(new String("task_number,directory_name,maze_index,ghost_type,ghost_slowdown,num_ghosts\n"));
		int task_counter = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 9; slowdown+=2){
					for (int num_g = 1; num_g < 5; num_g++){
						
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
						
						String csv_line = new String(task_counter+","+source_task_dir+","+
								maze+","+gtype+","+slowdown+","+num_g);
						
						task_index_file.append(csv_line);
						task_index_file.append("\n");
						source_tasks_lines.add(csv_line);
						task_counter++;
					}
				}
			}
		}
		
		task_index_file.close();
		
		//Step 2: randomly pick pairs of tasks, load feature weights from source task and learn on target task
		int pairs_to_sample = 600;
		
		Random R = new Random(1);
		for (int pair = 0; pair < pairs_to_sample; pair++){
			int source_i = R.nextInt(task_counter);
			int target_j = R.nextInt(task_counter);
			
			sourceTask = new String("baseline/"+source_task_names.get(source_i));
			
			String target_task_line = source_tasks_lines.get(target_j);
			String [] tokens = target_task_line.split(",");
	
			defaultConstants.MAZE_NUM = Integer.parseInt(tokens[2]); //which maze;
			defaultConstants.GHOST_TYPE = Integer.parseInt(tokens[3]); //which of three types of ghosts
			defaultConstants.GHOST_SPEED_REDUCTION = Integer.parseInt(tokens[4]); //ghost speed
			defaultConstants.NUM_GHOSTS = Integer.parseInt(tokens[5]); //how many ghosts

		
			String transfer_learner = new String("transfer_"+source_i+"_to_"+target_j);
			train(transfer_learner, 0,false,false);
		}			
	}
	
	public static void computeBaselineEX1(){
		//training params
		LENGTH = 1500; //how many train episodes
						
		//experiment params
		REPEATS = 10; //10; //30 // Curves to average
		SAVE_POLICY_K = 1; //save policy every k train episodes		
	
		//Step 1: generate baseline curves for all possible tasks
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						System.out.println(maze+"\t"+gtype+"\t"+slowdown+"\t"+num_g);
						
						mazeNum = maze; //which maze;
						ghostType = gtype; //which of three types of ghosts
						ghostSlowdown = slowdown; //ghost speed
						nGhosts = num_g; //how many ghosts
						
						defaultConstants = new Constants();
						defaultConstants.MAZE_NUM = maze; //which maze;
						defaultConstants.GHOST_TYPE = gtype; //which of three types of ghosts
						defaultConstants.GHOST_SPEED_REDUCTION = slowdown; //ghost speed
						defaultConstants.NUM_GHOSTS = num_g; //how many ghosts

						train("independent", 0,false,false);
					}
				}
			}
		}
		
		//Step 2:
		//manually move all the folders that are generated into a "baseline" folder
	}
	
	public static String generateDirectoryName(String learner, 
						int mazeNum_i, int ghostType_i, 
						int ghostSlowdown_i, int nGhosts){
		return new String(learner+"_maze"+mazeNum_i+"_type"+ghostType_i+"_slow"+ghostSlowdown_i+"_ghosts"+nGhosts+"");
	}

	/** Set up a learner. */
	public static RLPacMan create(String learner, int runNum) {
		
		FeatureSet teacherProto = TEACHER.startsWith("custom") ? new CustomFeatureSet() : new DepthFeatureSet();
		FeatureSet studentProto = STUDENT.startsWith("custom") ? new CustomFeatureSet() : new DepthFeatureSet();

		// Lone teacher
		if (learner.startsWith("teacher")) {
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy(dataDir+TEACHER+"/teacher/policy");
			return teacher;
		}
			
		// Lone student
		else if (learner.startsWith("independent")) {
			return STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
		}
		
		// TL: lead policy into student and let it run from there
		else if (learner.startsWith("transfer")) {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			if (TRANSFER_POLICY_K == -1)
				student.loadPolicy(DIR +"/" + sourceTask + "/policy" + runNum);
			else 
				student.loadPolicy(DIR +"/" + sourceTask + "/policy" + runNum+"_train"+TRANSFER_POLICY_K);
			return student;
		}
		
		// Student-teacher pair
		else {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy(dataDir+TEACHER+"/teacher/policy");
			
			// Front-load the advice budget
			if (learner.startsWith("baseline")) {
				TeachingStrategy strategy = new AdviseAtFirst();
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states
			if (learner.startsWith("advise")) {
				int threshold = Integer.parseInt(learner.substring(6));
				TeachingStrategy strategy = new AdviseImportantStates(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Correct important mistakes
			if (learner.startsWith("correct")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new CorrectImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states with predicted mistakes
			if (learner.startsWith("predict")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new PredictImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
		}
		
		return null;
	}
	
	/** Generate learning curves. */
	public static void train(String learner, int start, boolean watchAtEnd, boolean watchDuring) {
		
		String directory = generateDirectoryName(learner,mazeNum,ghostType,ghostSlowdown,nGhosts);
		
		
		System.out.println("Training directory: "+directory);
		
		/*String directory = learner + "_" + mazeNum;
		
		
		// TODO: Hacks
		if (nGhosts < 4){
			directory += ("_" + nGhosts);
		}*/
		
		//directory = "transfer_1_3";
		
		// Make sure directory exists
		File file = new File(DIR+pathSep+directory);
		if (!file.exists()){
			file.mkdir();
			//System.out.println("Creating directory "+file.toString());
		}
		//else System.out.println("Directory " +file.toString() + " already created.");
		
		
		// Load old curves
// Currently we are passing in 0, so this part will be skipped. Otherwise, the next part would be skipped. 
		LearningCurve[] curves = new LearningCurve[REPEATS];
		for (int i=0; i<start; i++)
			curves[i] = new LearningCurve(LENGTH+1, TRAIN, DIR+pathSep+directory+"/curve"+i);
		
		// Begin new curves
		for (int i=start; i<REPEATS; i++) {
			System.out.print("\trepeat "+i+"\n");
			if (i == REPEATS-1)
				System.out.println();
			
			
			curves[i] = new LearningCurve(LENGTH+1, TRAIN);
			
			//System.out.println("Training "+DIR+pathSep+directory+" for repeat "+i+"...");
// This just sets up the student or teacher with the specified feature set and learning algorithm
			RLPacMan pacman = create(learner, i);
			
			// First point
			double[] initialData = pacman.episodeData();		// Starts off empty
			
			System.out.println("Evaluating start...");
			double [] eval_result =evaluate(pacman, TEST);
			
			double initialScore = eval_result[0];		// This returns the average score over TEST number of games
			double initialTime = eval_result[1];		// This returns the average score over TEST number of games
			
			
			curves[i].set(0, initialScore, initialData, initialTime);
						
			//make a directory where to save the policies after each episode
			String repeat_path = new String(DIR+pathSep+directory+pathSep+"repeat"+i);
			File repeat_folder = new File(repeat_path);
			if (!repeat_folder.exists()){
				repeat_folder.mkdir();
			}
			
			// Rest of the points
			int num_train_episodes = 0;
			for (int x=1; x<=LENGTH; x++) {
				double[] data = new double[initialData.length];
				
				System.out.println("training episode "+x);

			
				
				for (int y=0; y<TRAIN; y++) {
					episode(pacman);	// Does the same thing as evaluate, but doesn't return score
					//episodeWithFaultDetection(pacman);
					
					num_train_episodes++;
					
					
					double[] episodeData = pacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				
				if (x % SAVE_POLICY_K == 0)
					pacman.savePolicy(repeat_path+pathSep+"policy"+i+"_train"+x);
				
				
				System.out.println("evaluating after episode "+x);
				double [] eval_result2 =evaluate(pacman, TEST) ;
				double score = eval_result2[0];		// This returns the average score over TEST number of games
				double time = eval_result2[1];		// This returns the average score over TEST number of games
		
				curves[i].set(x, score, data, time);
				
				System.out.print("e"+num_train_episodes+":"+score+" ");
				if (x % 30 == 0)
					System.out.println();
				
				if (watchDuring){
					((SarsaPacMan)pacman).debug=false;
					watch(pacman,true);
					((SarsaPacMan)pacman).debug=false;
				}
			}
			//System.out.println("\nTraining finished, saving policies and curves...");
			
			
			// Save new curve and policy
			pacman.savePolicy(DIR+"/"+directory+"/policy"+i);
			curves[i].save(DIR+"/"+directory+"/curve"+i);
			
			// Average all curves
			LearningCurve avgCurve = new LearningCurve(Arrays.copyOf(curves, i+1));
			avgCurve.save(DIR+"/"+directory+"/avg_curve");
			
			// Variance curve
			LearningCurve stdCurve = LearningCurve.getScoreVarianceCurve(Arrays.copyOf(curves, i+1), true);
			stdCurve.save(DIR+"/"+directory+"/stdev_curve");
			
			if (i == REPEATS -1 && watchAtEnd)
				watch(pacman, false);
		}
		
		System.out.println("Done.");
	}
 
	/** Generate learning curves. */
	public static void trainFD(String learner, int start, boolean watchAtEnd, boolean watchDuring) {
		
		boolean watchTrain = true;
		
		String directory = generateDirectoryName(learner,mazeNum,ghostType,ghostSlowdown,nGhosts);
		
		
		System.out.println("Training directory: "+directory);
	
		
		// Make sure directory exists
		File file = new File(DIR+pathSep+directory);
		if (!file.exists()){
			file.mkdir();
		}
		
		//buffer size of subtask
		int fd_buffer = 50;
		
		// Load old curves
		// Currently we are passing in 0, so this part will be skipped. Otherwise, the next part would be skipped. 
		LearningCurve[] curves = new LearningCurve[REPEATS];
		for (int i=0; i<start; i++)
			curves[i] = new LearningCurve(LENGTH+1, TRAIN, DIR+pathSep+directory+"/curve"+i);
		
		// Begin new curves
		for (int i=start; i<REPEATS; i++) {
			System.out.print("\trepeat "+i+"\n");
			if (i == REPEATS-1)
				System.out.println();
			
			
			curves[i] = new LearningCurve(LENGTH+1, TRAIN);
			
			//System.out.println("Training "+DIR+pathSep+directory+" for repeat "+i+"...");
			// This just sets up the student or teacher with the specified feature set and learning algorithm
			RLPacMan pacman = create(learner, i);
			
			// First point
			double[] initialData = pacman.episodeData();		// Starts off empty
			
			System.out.println("Evaluating start...");
			double [] eval_result =evaluate(pacman, TEST);
			
			double initialScore = eval_result[0];		// This returns the average score over TEST number of games
			double initialTime = eval_result[1];		// This returns the average score over TEST number of games
			
			
			curves[i].set(0, initialScore, initialData, initialTime);
						
			//make a directory where to save the policies after each episode
			String repeat_path = new String(DIR+pathSep+directory+pathSep+"repeat"+i);
			File repeat_folder = new File(repeat_path);
			if (!repeat_folder.exists()){
				repeat_folder.mkdir();
			}
			
			// Rest of the points
			int num_train_episodes = 0;
			for (int x=1; x<=LENGTH; x++) {
				double[] data = new double[initialData.length];
				
				System.out.println("training episode "+x);

			
				String train_state = "regular";
				
				for (int y=0; y<TRAIN; y++) {
					if (train_state == "regular"){
						episodeWithFaultDetection(pacman,fd_buffer,true,watchTrain);
					}
					
					//episode(pacman);	// Does the same thing as evaluate, but doesn't return score
				
					
					num_train_episodes++;
					
					double[] episodeData = pacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				
				if (x % SAVE_POLICY_K == 0)
					pacman.savePolicy(repeat_path+pathSep+"policy"+i+"_train"+x);
				
				
				/*System.out.println("evaluating after episode "+x);
				double [] eval_result2 =evaluate(pacman, TEST) ;
				double score = eval_result2[0];		// This returns the average score over TEST number of games
				double time = eval_result2[1];		// This returns the average score over TEST number of games
		
				curves[i].set(x, score, data, time);
				
				System.out.print("e"+num_train_episodes+":"+score+" ");
				if (x % 30 == 0)
					System.out.println();
				
				if (watchDuring){
					((SarsaPacMan)pacman).debug=false;
					watch(pacman,true);
					((SarsaPacMan)pacman).debug=false;
				}*/
			}
			//System.out.println("\nTraining finished, saving policies and curves...");
			
			
			// Save new curve and policy
			pacman.savePolicy(DIR+"/"+directory+"/policy"+i);
			curves[i].save(DIR+"/"+directory+"/curve"+i);
			
			// Average all curves
			LearningCurve avgCurve = new LearningCurve(Arrays.copyOf(curves, i+1));
			avgCurve.save(DIR+"/"+directory+"/avg_curve");
			
			// Variance curve
			LearningCurve stdCurve = LearningCurve.getScoreVarianceCurve(Arrays.copyOf(curves, i+1), true);
			stdCurve.save(DIR+"/"+directory+"/stdev_curve");
			
			if (i == REPEATS -1 && watchAtEnd)
				watch(pacman, false);
		}
		
		System.out.println("Done.");
	}
	
	/** Train a learner for one more episode. */
// Basically does the same thing as evaluate but doesn't return the score	
	public static void episode(RLPacMan pacman) {

		Game game = new Game(rng.nextLong(), defaultConstants);
		pacman.startEpisode(game, false);

		while(!game.gameOver()) {
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
				
			pacman.processStep(game);
			
			
		}
	}
	
	public static void episodeSubtask(String gameState, int maxNumEpisodes, String fault_type,
									boolean watch){
		
	}
	
	public static String episodeWithFaultDetection(RLPacMan pacman, 
							int fd_buffer, boolean doFD,
							boolean watch) {

		Game game = new Game(rng.nextLong(), defaultConstants);
		pacman.startEpisode(game, false);
		
		Queue<String> q = new ArrayDeque<String>();
		int bufferSize = fd_buffer;
	
		GameView gv = new GameView(game);
		if (watch)
			gv=new GameView(game).showGame();
		
		while(!game.gameOver()) {
			
			//add game state to array
			q.add(game.getGameState());
			if (q.size() > bufferSize)
				q.poll();
			
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
			
			
			if (doFD){
			//fault 1: pacman is eaten; assumes that pacman starts with only 1 life
				if (game.getPacmanNumberOfLivesRemaining() == 0 && game.getCurrentLevelTime() != game.constants.LEVEL_LIMIT ){

					System.out.println(game.getCurrentLevelTime() +"\t"+game.constants.LEVEL_LIMIT);
					
					return "fault_eaten";
				}
			}
				
			pacman.processStep(game);
			
			if (watch){
				try{Thread.sleep(defaultConstants.DELAY);}catch(Exception e){}
					gv.repaint();
			}
		
		}
		if (watch){
			gv.setVisible(false);
			gv.setEnabled(false);
			gv.getFrame().dispose();
		}
		return "ok";
	}

	/** Estimate the current performance of a learner. */
// Width is the number of episodes to test for (i.e. variable TEST above)	
	public static double[] evaluate(RLPacMan pacman, int width) {
		
		double[] scoreAndTime = new double[2];		
		double sumScore = 0;
		double sumSteps = 0;
		
// For each test episode		
		for(int i=0; i<width; i++) {
// Create and start a new game			
			Game game = new Game(rng.nextLong(), defaultConstants);
			pacman.startEpisode(game, true);
			while(!game.gameOver()) {
// getMove in pacman learner returns the lastAction	
// This will then recompute the next move to make.
				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));			
				pacman.processStep(game);
			}
			
			sumScore += game.getScore();
			sumSteps += game.getTotalTime();
			//System.out.println("time taken: " + game.getTotalTime());
		}

		scoreAndTime[0] = sumScore/width;
		scoreAndTime[1] = sumSteps/width;
		
		
		return scoreAndTime;
	}
	
	public static void computeGraphFeatures(){
		Game game=new Game(rng.nextLong(), defaultConstants);
		
		//get maze
		Maze M = game.getCurrentMaze();
		
				
		//get number of nodes
		int num_nodes = M.graph.length;
			
		//get starting positions for ghosts and pacman
		int lair_index = M.lairNodeIndex;
		int ghost_start = M.initialGhostNodeIndex;
		int pacman_start = M.initialPacManNodeIndex;
		
		//get pill indeces
		int [] pill_indeces = M.pillIndices;
		int [] power_pill_indeces = M.powerPillIndices;
		
		//node to pill ratio:
		double node_to_pill_ratio = (double)num_nodes/(double)pill_indeces.length;
		
		//starting distance between pacman and ghosts
		int dist_ghost_to_pacman = game.getShortestPath(ghost_start, pacman_start).length;
		int dist_lair_to_pacman = game.getManhattanDistance(lair_index, pacman_start);
		
		//average distance between power pills
		double avg_pp_to_pp_distance = 0;
		int c = 0;
		for (int i = 0; i < power_pill_indeces.length; i ++){
			for (int j = 0; j < power_pill_indeces.length; j++){
				if (i!=j){
					avg_pp_to_pp_distance += (double)game.getShortestPath(ghost_start, pacman_start).length;
					c++;
				}
			}
		}
		avg_pp_to_pp_distance = avg_pp_to_pp_distance /(double)c;
		
		//average distance between power pills and lair
		double avg_lair_to_pp_distance = 0;
		for (int i = 0; i < power_pill_indeces.length; i ++){
			avg_lair_to_pp_distance += game.getShortestPath(ghost_start, power_pill_indeces[i]).length;
		}
		avg_lair_to_pp_distance = avg_lair_to_pp_distance / (double)power_pill_indeces.length;
		
		//average effective eccentricity
		double avg_effective_eccentricity = 0;
		double max_effective_eccentricity = Double.MIN_VALUE;
		for (int i = 0; i < M.graph.length; i ++){
			double max = Double.MIN_VALUE;
			for (int j = 0; j < M.graph.length; j ++){
			
				if (game.getNeighbouringNodes(M.graph[i].nodeIndex).length > 0
						&& game.getNeighbouringNodes(M.graph[j].nodeIndex).length > 0){
					double d_uv = game.getShortestPath(M.graph[i].nodeIndex, M.graph[j].nodeIndex).length;
					if (d_uv > max)
						max = d_uv;
				}
			}
			
			avg_effective_eccentricity+=max;
			
			if (max > max_effective_eccentricity)
				max_effective_eccentricity = max;
		}
		avg_effective_eccentricity = avg_effective_eccentricity / (double)M.graph.length;
		
		//average effective eccentricity for between junctions
		double avg_effective_eccentricity_junct = 0;
		double max_effective_eccentricity_junct = Double.MIN_VALUE;
		for (int i = 0; i < M.junctionIndices.length; i ++){
			double max = Double.MIN_VALUE;
			for (int j = 0; j < M.junctionIndices.length; j ++){
			
				if (game.getNeighbouringNodes(M.junctionIndices[i]).length > 0
						&& game.getNeighbouringNodes(M.junctionIndices[j]).length > 0){
					double d_uv = game.getShortestPath(M.junctionIndices[i], M.junctionIndices[j]).length;
					if (d_uv > max)
						max = d_uv;
				}
			}
			
			avg_effective_eccentricity_junct+=max;
			
			if (max > max_effective_eccentricity_junct)
				max_effective_eccentricity_junct = max;
		}
		avg_effective_eccentricity_junct = avg_effective_eccentricity_junct / (double)M.junctionIndices.length;
		
		//for each pair of junctions, compute shortest path and count how many junctions are on it
		double avg_num_junctions_between_junctions = 0;
		for (int i = 0; i < M.junctionIndices.length; i ++){
			for (int j = 0; j < M.junctionIndices.length; j ++){
				int [] path_ij = game.getShortestPath(M.junctionIndices[i], M.junctionIndices[j]);
				
				double num_juncts_in_path = 0;
				
				for (int k = 0; k < path_ij.length; k++){
					for (int p = 0; p < M.junctionIndices.length; p ++){
						if (path_ij[k]==M.junctionIndices[p] && i != p && j != p)
							num_juncts_in_path+=1.0;
					}
				}
				
				avg_num_junctions_between_junctions += num_juncts_in_path;
			}
		}
		avg_num_junctions_between_junctions = avg_num_junctions_between_junctions/(M.junctionIndices.length*M.junctionIndices.length);
		
		//histogram of degrees of nodes
		int [] hist = new int[5];
		for (int i = 0; i < 5; i ++){
			hist[i]=0;
		}
		for (int i = 0; i < M.graph.length; i ++){
			int degree_i = game.getNeighbouringNodes(M.graph[i].nodeIndex).length;
			hist[degree_i]++;
		}
		
		
		
		System.out.println("num_nodes\t"+num_nodes);
		//System.out.println("starting positions:\t"+lair_index+"\t"+ghost_start+"\t"+pacman_start);
		System.out.println("num_pills\t"+pill_indeces.length);
		//and power pills:\t"+pill_indeces.length+"\t"+power_pill_indeces.length);
		
		System.out.println("node_to_pill_ratio\t"+node_to_pill_ratio);
		System.out.println("dist_ghost_to_pacman\t"+dist_ghost_to_pacman);
	
		System.out.println("avg_pp_to_pp_distance\t"+avg_pp_to_pp_distance);
		System.out.println("avg_lair_to_pp_distance\t"+avg_lair_to_pp_distance);
		System.out.println("avg_effective_eccentricity\t"+avg_effective_eccentricity);
		System.out.println("avg_effective_eccentricity_junct\t"+avg_effective_eccentricity_junct);
		
		System.out.println("max_effective_eccentricity\t"+max_effective_eccentricity);
		System.out.println("max_effective_eccentricity_junct\t"+max_effective_eccentricity_junct);
		
		System.out.println("avg_num_junctions_between_junctions\t"+avg_num_junctions_between_junctions);
		
		//System.out.println("Histogram of degrees:");
		for (int i = 2; i < 5; i ++){
			System.out.println( "dhist_"+(i)+"\t"+hist[i]);
		}
		
		
	}
	
	/** Observe a learner play a game. */
	public static void watchAndSave(RLPacMan pacman, boolean destroyWindow, String prefix, String path) {
		
		
		Game game=new Game(rng.nextLong(), defaultConstants);
		
		pacman.startEpisode(game, true);
		GameView gv=new GameView(game).showGame();
		int c = 0;
		

		while(!game.gameOver()) {
			
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
			pacman.processStep(game);
			
			try{Thread.sleep(defaultConstants.DELAY);}catch(Exception e){}
			gv.repaint();
	
			//Image img_i = gv.createImage(100, 100);
			Image img_i = gv.getImage();
			BufferedImage bi = (BufferedImage)img_i;
			
			
			StringBuffer leadingZeros = new StringBuffer();
			if (c < 10)
				leadingZeros.append("0000");
			else if (c < 100)
				leadingZeros.append("000");
			else if (c < 1000)
				leadingZeros.append("00");
			else if (c < 10000)
				leadingZeros.append("0");
			
			
			
			File f = new File(new String(path+"/img"+leadingZeros.toString()+c+".png"));
			c++;
			try {
				ImageIO.write(bi, "png", f);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (destroyWindow){
			gv.setVisible(false);
			gv.setEnabled(false);
			gv.getFrame().dispose();
		}
	}

	/** Observe a learner play a game. */
	public static void watch(RLPacMan pacman, boolean destroyWindow) {
		
		
		Game game=new Game(rng.nextLong(), defaultConstants);
		
		pacman.startEpisode(game, true);
		GameView gv=new GameView(game).showGame();
		
		

		while(!game.gameOver()) {
			
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
			pacman.processStep(game);
			
			try{Thread.sleep(defaultConstants.DELAY);}catch(Exception e){}
			gv.repaint();
			Image img_i = gv.createImage(100, 100);
			BufferedImage bi = (BufferedImage)img_i;
			File f = new File("./output.png");
			try {
				ImageIO.write(bi, "png", f);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (destroyWindow){
			gv.setVisible(false);
			gv.setEnabled(false);
			gv.getFrame().dispose();
		}
	}
		
	
	/** Select a teacher from the independent students. */
	public static void findBestTeacher() {
		
		double[] scores = new double[REPEATS];
		
		for (int i=0; i<REPEATS; i++) {
			BasicRLPacMan pacman = (BasicRLPacMan)create("independent",-1);
			pacman.loadPolicy(DIR+"/independent/policy"+i);
			scores[i] = evaluate(pacman, 500)[0];
			System.out.println(DIR+"/independent/policy"+i+": "+scores[i]);
		}
		
		int bestPolicy = 0;
		for (int i=0; i<REPEATS; i++)
			if (scores[i] > scores[bestPolicy])
				bestPolicy = i;
		
		System.out.println("Best: "+DIR+"/independent/policy"+bestPolicy);
	}
	
	/** Make a plottable file of Q-value gaps over a few episodes. */
	public static void plotGaps() {

		DataFile file = new DataFile(dataDir+TEACHER+"/teacher/gaps");
		file.clear();

		BasicRLPacMan pacman = (BasicRLPacMan)create("teacher", -1);
		int x = 0;

		for (int i=0; i<1; i++) {
			Game game = new Game(rng.nextLong());
			pacman.startEpisode(game, true);

			while(!game.gameOver()) {

				double[] qvalues = pacman.getQValues();
				Arrays.sort(qvalues);
				double gap = qvalues[qvalues.length-1] - qvalues[0];

				file.append(x+"\t"+gap+"\n");
				x++;

				/*if (ghostType == 0)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsR.getMove(game.copy(), -1));
				else if (ghostType == 1)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsS.getMove(game.copy(), -1));
				else if (ghostType == 2)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsC.getMove(game.copy(), -1));
				else {
					System.err.println("INVALID GHOST TYPE");
					System.exit(1);
				}*/
				
				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
				
				
				
				pacman.processStep(game);
			}
		}

		file.close();
	}
	
	/** Test SVM choice prediction. */
	public static void testSVM() {
			
		BasicRLPacMan student = (BasicRLPacMan)create("independent", -1);
		BasicRLPacMan teacher = (BasicRLPacMan)create("teacher", -1);
		PredictImportantMistakes strategy = new PredictImportantMistakes(0);
		
		for (int i=0; i<300; i++) {
			Game game = new Game(rng.nextLong());
			student.startEpisode(game, false);
			teacher.startEpisode(game, true);
			
			strategy.startEpisode();
			int right = 0, wrong = 0, truePos = 0, falseNeg = 0, falsePos = 0;
			
			while(!game.gameOver()) {
				MOVE advice = teacher.getMove(game, -1);
				MOVE choice = student.getMove(game, -1);
				strategy.recordExample(teacher, choice);
				
				if (i > 0) {
					MOVE guess = strategy.predictChoice(teacher);
					boolean predict = (guess != advice);
					boolean mistake = (choice != advice);
					
					if (guess == choice)
						right++;
					else
						wrong++;
					
					if (mistake && predict)
						truePos++;
					else if (mistake && !predict)
						falseNeg++;
					else if (!mistake && predict)
						falsePos++;
				}
				
				if (ghostType == 0)
					game.advanceGame(choice, ghostsR.getMove(game.copy(), -1));
				else if (ghostType == 1)
					game.advanceGame(choice, ghostsS.getMove(game.copy(), -1));
				else if (ghostType == 2)
					game.advanceGame(choice, ghostsC.getMove(game.copy(), -1));
				else {
					System.err.println("INVALID GHOST TYPE");
					System.exit(1);
				}
				student.processStep(game);
				teacher.processStep(game);
			}
			
			if (i > 0) {
				double accuracy = right/(double)(right+wrong);
				double precision = truePos/(double)(truePos+falsePos);
				double recall = truePos/(double)(truePos+falseNeg);
				
				DecimalFormat f = new DecimalFormat("#.##");
				System.out.println("During episode "+i+": a="+f.format(accuracy)+", p="+f.format(precision)+", r="+f.format(recall));
			}
		}
	}
	
	/** Compare areas under two types of learning curves. */
	public static void compare(String dir1, String dir2) {
		
		LearningCurve[] curves1 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves1[i] = new LearningCurve(LENGTH+1, TRAIN, dataDir+dir1+"/curve"+i);
		
		double[] areas1 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas1[i] = curves1[i].area();
		
		LearningCurve[] curves2 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves2[i] = new LearningCurve(LENGTH+1, TRAIN, dataDir+dir2+"/curve"+i);
		
		double[] areas2 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas2[i] = curves2[i].area();
		
		double t0 = Stats.t(areas1, areas2);
		double dof = Stats.dof(areas1, areas2);
		System.out.println(dir1+" > "+dir2+" with 95% confidence if:");
		System.out.println(t0+" > t_0.05_"+dof);
	}
	
	private static EnumMap<GHOST, MOVE> getGhostMove(Game game, int ghostType){
		
		switch(ghostType){
			case 0:
				return ghostsR.getMove(game.copy(), -1);
			case 1:
				return ghostsS.getMove(game.copy(), -1);
			case 2:
				return ghostsC.getMove(game.copy(), -1);
			case 3:
				return ghostsL.getMove(game.copy(), -1);
			default:
				System.err.println("INVALID GHOST TYPE");
				System.exit(1);
				return null;				// Compilier is complaining... 
		}
	}
}