package pacman;

import pacman.game.Constants.GHOST;
import pacman.game.Constants;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Random;

import pacman.entries.ghosts.*;
import pacman.entries.pacman.BasicRLPacMan;
import pacman.entries.pacman.CustomFeatureSet;
import pacman.entries.pacman.DepthFeatureSet;
import pacman.entries.pacman.FeatureSet;
import pacman.entries.pacman.QFunction;
import pacman.entries.pacman.QPacMan;
import pacman.entries.pacman.RLPacMan;
import pacman.entries.pacman.SarsaPacMan;
import pacman.game.Game;
import pacman.game.GameView;
import pacman.game.Constants.MOVE;
import pacman.teaching.AdviseAtFirst;
import pacman.teaching.AdviseImportantStates;
import pacman.teaching.CorrectImportantMistakes;
import pacman.teaching.PredictImportantMistakes;
import pacman.teaching.Student;
import pacman.teaching.TeachingStrategy;
import pacman.utils.DataFile;
import pacman.utils.EvaluationMetrics;
import pacman.utils.LearningCurve;
import pacman.utils.Stats;

public class Experiments {
	
// Note on notation:
// custom refers to the CustomFeatureSet (using something else defaults to DepthFeatureSet)
// S refers to SarsaPacMan (using something else defaults to QPacMan)
	
	
/* 	4 options for RLPacMan learner type
 * 		- teacher: teacher RLPacMan loads policy
 * 		- independent: student starts from scratch
 * 		- transfer: student loads policy
 * 		- (baseline, advise, correct, predict): uses teacher+independent and a strategy for teacher 
 * 
 * 	Notes on folder names in mydata
 * 		- mydata/TEACHER/STUDENT/LEARNER-TYPE_MAZE-NUM/
 * 
 * 
 * 
 */	
	
/*	
	
	TODO:
			
	
	
*/
	
	public static String TEACHER = "customS"; // Teacher feature set and algorithm
	public static String STUDENT = "depthS"; // Student feature set and algorithm
	public static String DIR = "myData/"+TEACHER+"/"+STUDENT; // Where to store data
	
	public static int BUDGET = 1000; // Advice budget
	public static int REPEATS = 5; //10; //30 // Curves to average
	//public static int LENGTH = 1000; // 10; // 100; // Points per curve
	public static int TEST = 50; //30; // Test episodes per point
	public static int TRAIN = 1; //10 // Train episodes per point 

	public static Random rng = new Random();
	
	// Ghost "policies"
	public static StandardGhosts ghostsS = new StandardGhosts();
    public static RandomGhosts ghostsR = new RandomGhosts();
    public static ChaserGhosts ghostsC = new ChaserGhosts();
    public static LineGhosts ghostsL = new LineGhosts();
    
    
    
    // Task parameters
	public static Constants constants = new Constants();
    
	/**
	 * Run experiments.
	 */
	public static void main(String[] args) throws Exception {

		System.out.println("Calling INNER Experiments program");		
		
		
		
		//evaluateSourceTask(args);
		findTaskClosestPolicy(args);
		System.out.println("Finished.");	
		System.exit(0);

		
		
		
		
		
		
		if (args.length > 0){
			try {
				constants.loadFromFile(args[0]);
			} catch (Exception e){
				System.err.println("ERROR LOADING CONSTANTS FROM FILE: " + args[0]);
				e.printStackTrace();
			}
			
		}
		else {
			System.out.println("Did not find file. Loading from code...");
	
			constants.SOURCE_TASK = "independent_1k";
			constants.LEARNER = "independent";
			constants.LENGTH = 100;
			constants.MAZE_NUM = 1;
			constants.setVariable("GHOST_TYPE", "3");
			constants.NUM_GHOSTS = 4;
			constants.GHOST_SPEED_REDUCTION = 2;
			constants.SAVE_DIR = "test";
		}
		

/*		
		int counter = 0;
		
		constants.loadFromFile("tasks/lineGhosts");
		constants.LEARNER = "independent";
		constants.SAVE_DIR = "lineGhosts_" + counter;
		train(constants.LEARNER, 0);
		
		constants.loadFromFile("tasks/targetTask");			
		constants.SOURCE_TASK = "lineGhosts_" + counter;
		constants.SAVE_DIR = "target_" + counter;
		train(constants.LEARNER, 0);
		counter++;
		
		while (counter < 100){
			
			System.out.println("COUNTER " + counter);
			
			constants.loadFromFile("tasks/lineGhosts");					// Load source task
			constants.SAVE_DIR = "lineGhosts_" + counter;
			train(constants.LEARNER, 0);								// Train x episodes on source
																		// Save weights
			// Check performance on target
			constants.loadFromFile("tasks/targetTask");			
			constants.SOURCE_TASK = "lineGhosts_" + counter;
			constants.SAVE_DIR = "target_" + counter;
			train(constants.LEARNER, 0);
			
			counter++;
		}		
*/		
			
		
		// Train!
		train(constants.LEARNER, 0);
	
		
		// Evaluate on target!
//		evaluatePolicyTrajectory(200);
		
		
		// WATCH!
//		constants.MAZE_NUM = 1;
//		constants.GHOST_TYPE = 1;
//		LENGTH=10;
//		constants.GHOST_SPEED_REDUCTION=1;
//		constants.NUM_GHOSTS = 3;		
//		GHOST.BLINKY.initialLairTime = 4;
//		GHOST.INKY.initialLairTime = 6;
//		GHOST.PINKY.initialLairTime = 8;
//		GHOST.SUE.initialLairTime = 10;				
//		RLPacMan pacman = create("transfer", 0, "");		// Technically all the policies are after 10 episodes of training (i.e. you can use 0-9 for the 9 here)
//		watch(pacman);

		
			
		System.out.println("Completed");
		
		
	}
	
	
/** 
 * 		The source task file should have the same thing in SAVE_DIR as SOURCE_TASK, since the target task is common for many source tasks
 * 		and this removes the need to have different files for each target. 
 * 
 * 
 * */	
	
	
	public static void findTaskClosestPolicy(String[] args) throws Exception {
		
		if (args.length < 3){
			System.err.println("ERROR: 3 arguments needed. [Source task file] [Target Policy] [REPEAT INDEX]");
			return;
		}
		
		REPEATS = 1;
		TRAIN = 10;
		TEST = 50;				// 10?
		
		
		String sourceTask = args[0];
		String targetPolicy = args[1];
		int repeatIndex = Integer.parseInt(args[2]);

		
		constants.loadFromFile(sourceTask);
		
		// Create save directory for source task
		String directory = constants.LEARNER + "_" + constants.MAZE_NUM;
		if (constants.SAVE_DIR != null){
			directory = constants.SAVE_DIR;
		}		
		File file = new File(DIR+"/"+directory);
		if (!file.exists())
			file.mkdir();
	
		
		LearningCurve[] sourceCurves = new LearningCurve[REPEATS];
		
		int[] numEpisodes = new int[REPEATS];
		double[] sourcePerformance = new double[REPEATS];
		double[] targetPerformance = new double[REPEATS];
		
		// Begin new curves
		for (int i=0; i<REPEATS; i++) {
			
			// repeatIndex = i;
			
			if (new File(DIR+"/"+directory+"/sourceCurve"+repeatIndex).exists()){
				continue;
			}
			
			double minDistance = Double.POSITIVE_INFINITY; 

			
			sourceCurves[i] = new LearningCurve(constants.LENGTH+1, TRAIN);
			
			System.out.println("Training "+DIR+"/"+directory+" "+i+"...");			
			RLPacMan sourcePacman = create(constants.LEARNER, repeatIndex, "");
			
			// First point
			double[] initialData = sourcePacman.episodeData();		// Starts off empty
			double[] initialScoreTime = evaluate(sourcePacman, TEST);
			double initialScore = initialScoreTime[0];		// This returns the average score over TEST number of games
			double initialTime = initialScoreTime[1];
			sourceCurves[i].set(0, initialScore, initialData, initialTime);
			System.out.println(0);
			
			// Rest of the points
			for (int x=1; x<=constants.LENGTH; x++) {
				
				double[] data = new double[initialData.length];
				
				System.out.println(x);
				
				// Train for k episodes on source task
				for (int y=0; y<TRAIN; y++) {
					
					//System.out.println("Train " + y);					
					episode(sourcePacman);	// Does the same thing as evaluate, but doesn't return score
					
					//watch(sourcePacman);
					
					double[] episodeData = sourcePacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				
				double[] scoreTime = evaluate(sourcePacman, 100);	// TEST
				double score = scoreTime[0];
				double time = scoreTime[1];
				sourceCurves[i].set(x, score, data, time);
				
				sourcePacman.savePolicy(DIR+"/"+directory+"/policy"+repeatIndex+"_"+x);
				
				System.out.println("SOURCE TASK ITER " + x + ": " + score);
				
				//watch(sourcePacman);
				

				// Compare policies				
				int depth = 4;
				if (constants.MAZE_NUM == 4){		// myMaze
					depth = 2;
				}				
				FeatureSet studentProto = STUDENT.startsWith("custom") ? new CustomFeatureSet(depth) : new DepthFeatureSet();				
				QFunction targetQFunction = new QFunction(studentProto, DIR +"/" + targetPolicy);			
				double distance = sourcePacman.getQFunction().euclideanDistanceTo(targetQFunction);
				//System.out.println(targetQFunction.toString());
				//System.out.println("Distance " + distance + " min: " + minDistance);
				if (distance < minDistance){
					minDistance = distance;
					numEpisodes[i] = TRAIN * x;
					sourcePerformance[i] = score;
					targetPerformance[i] = distance;
				}
				else{
					break;
				}
									
				constants.loadFromFile(sourceTask);
			}
			
			
			constants.loadFromFile(sourceTask);
		
			
			// Save stats for this repeat
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(DIR+"/"+directory+"/clExperiment" + repeatIndex + ".txt", true)));
			writer.println(numEpisodes[i] + " " + sourcePerformance[i] + " " + targetPerformance[i]);
			writer.close();

			
			// Save source curve (this will serve as our checkpoint)
			sourceCurves[i].save(DIR+"/"+directory+"/sourceCurve"+repeatIndex);
			
			
		}
		
		
		// Print results and save them out!
		double avgEpisodes = 0;
		double avgPerformance = 0;
		double avgTargetDifference = 0;
				
		System.out.println("R\tnTrain\tSource Score\tTarget Score");
		for (int r=0; r < REPEATS; r++){
			System.out.printf("%d\t%d\t%f\t%f\n", r, numEpisodes[r], sourcePerformance[r], targetPerformance[r]);
			avgEpisodes += numEpisodes[r];
			avgPerformance += sourcePerformance[r];
			avgTargetDifference += targetPerformance[r];
		}
		avgEpisodes /= REPEATS;
		avgPerformance /= REPEATS;
		avgTargetDifference /= REPEATS;
		
		System.out.println();		
		System.out.println(avgEpisodes + " " + avgPerformance + " " + avgTargetDifference);		
	
		
		
		
	}
	
	
	public static void evaluateSourceTask(String[] args) throws Exception {
		
		
		if (args.length < 4){
			System.err.println("ERROR: 4 arguments needed. [Source task file] [Target task file] [Target Independent Curve] [REPEAT INDEX]");
			return;
		}
		
		REPEATS = 1;
		TRAIN = 20;
		TEST = 50;				// 10?
		
		int repeatIndex = Integer.parseInt(args[3]);
		
		constants.loadFromFile(args[0]);
			
		// Create save directory for source task
		String directory = constants.LEARNER + "_" + constants.MAZE_NUM;
		if (constants.SAVE_DIR != null){
			directory = constants.SAVE_DIR;
		}		
		File file = new File(DIR+"/"+directory);
		if (!file.exists())
			file.mkdir();
	
		
		LearningCurve[] sourceCurves = new LearningCurve[REPEATS];
		
		int[] numEpisodes = new int[REPEATS];
		double[] sourcePerformance = new double[REPEATS];
		double[] targetPerformance = new double[REPEATS];
		
		// Begin new curves
		for (int i=0; i<REPEATS; i++) {
			
			// repeatIndex = i;
			
			if (new File(DIR+"/"+directory+"/sourceCurve"+repeatIndex).exists()){
				continue;
			}
			
			double previousRewardDifference = 0;
			//LearningCurve previousCurve = new LearningCurve(constants.LENGTH+1, 1, DIR+"/"+args[2]);
			
			
			// Load source task
			//constants.loadFromFile(args[0]);
			
			sourceCurves[i] = new LearningCurve(constants.LENGTH+1, TRAIN);
			
			System.out.println("Training "+DIR+"/"+directory+" "+i+"...");			
			RLPacMan sourcePacman = create(constants.LEARNER, repeatIndex, "");
			
			// First point
			double[] initialData = sourcePacman.episodeData();		// Starts off empty
			double[] initialScoreTime = evaluate(sourcePacman, TEST);
			double initialScore = initialScoreTime[0];		// This returns the average score over TEST number of games
			double initialTime = initialScoreTime[1];
			sourceCurves[i].set(0, initialScore, initialData, initialTime);
			System.out.println(0);
			
			// Rest of the points
			for (int x=1; x<=constants.LENGTH; x++) {
				
				double[] data = new double[initialData.length];
				
				System.out.println(x);
				
				// Train for k episodes on source task
				for (int y=0; y<TRAIN; y++) {
					
					//System.out.println("Train " + y);					
					episode(sourcePacman);	// Does the same thing as evaluate, but doesn't return score
					
					//watch(sourcePacman);
					
					double[] episodeData = sourcePacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				
				double[] scoreTime = evaluate(sourcePacman, 100);	// TEST
				double score = scoreTime[0];
				double time = scoreTime[1];
				sourceCurves[i].set(x, score, data, time);
				
				sourcePacman.savePolicy(DIR+"/"+directory+"/policy"+repeatIndex+"_"+x);
				
				System.out.println("SOURCE TASK ITER " + x + ": " + score);
				
				//watch(sourcePacman);
				
				// Transfer that policy and train on target task for LENGTH - k episodes				
				int nTrainingEpisodes = 0; //TRAIN * x;
				
				constants.loadFromFile(args[1]);
				
				RLPacMan targetPacman = create(constants.LEARNER, repeatIndex, "_"+x);
				
				LearningCurve targetCurve = new LearningCurve(constants.LENGTH-nTrainingEpisodes+1, 1);
				// Initial point
				double[] initialTData = targetPacman.episodeData();		// Starts off empty
				double[] initialTScoreTime = evaluate(targetPacman, TEST);
				double initialTScore = initialTScoreTime[0];		// This returns the average score over TEST number of games
				double initialTTime = initialTScoreTime[1];
				targetCurve.set(0, initialTScore, initialTData, initialTTime);
				
				
				
				double[] dataT = new double[initialTData.length];
						
				for (int t=nTrainingEpisodes+1; t<=constants.LENGTH; t++) {
				
					System.out.println("\tTest " + i + "_" + x + "_" + t);
					
					// Train for 1 episode
					episode(targetPacman);	// Does the same thing as evaluate, but doesn't return score					
					double[] episodeData = targetPacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
					
					double[] scoreTTime = evaluate(targetPacman, TEST);
					double scoreT = scoreTTime[0];
					double timeT = scoreTTime[1];
					targetCurve.set(t-nTrainingEpisodes, scoreT, dataT, timeT);
				
				}
				
				// Save the target curve
				targetCurve.save(DIR+"/"+directory+"/targetCurve"+repeatIndex+"_"+x);
				
				LearningCurve independentTargetCurve = new LearningCurve(constants.LENGTH+1, 1, DIR+"/"+args[2]);
				
				// Calculate reward difference (by loading baseline curve and computing ... )
				double rewardDifference = EvaluationMetrics.transferDifference(targetCurve, independentTargetCurve, nTrainingEpisodes);
				
				System.out.println("\tReward difference: " + rewardDifference);
				
				// If the reward difference did not decrease, keep track of the reward difference and repeat by increasing k. 
				if (rewardDifference > previousRewardDifference){
					previousRewardDifference = rewardDifference;
					numEpisodes[i] = TRAIN * x;
					sourcePerformance[i] = score;					
					targetPerformance[i] = rewardDifference;
					System.out.println("Updated repeat " + i + " to " + numEpisodes[i] + " episodes with score " + sourcePerformance[i] + " and target performance " + targetPerformance[i]);
				}
				// If it decreased, keep track of k and store the performance reached on the source task, and break the loop.
				else {
					break;
				}
				constants.loadFromFile(args[0]);
			}
			
			
			constants.loadFromFile(args[0]);
			
			
			
			
			
			
			// Save stats for this repeat
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(DIR+"/"+directory+"/clExperiment" + repeatIndex + ".txt", true)));
			writer.println(numEpisodes[i] + " " + sourcePerformance[i] + " " + targetPerformance[i]);
			writer.close();

			
			// Save source curve (this will serve as our checkpoint)
			sourceCurves[i].save(DIR+"/"+directory+"/sourceCurve"+repeatIndex);
			
			
			
			// Save new curve and policy
//			sourcePacman.savePolicy(DIR+"/"+directory+"/policy"+i);
//			sourceCurves[i].save(DIR+"/"+directory+"/curve"+i);
			
			// Average all curves
//			LearningCurve avgCurve = new LearningCurve(Arrays.copyOf(sourceCurves, i+1));
//			avgCurve.save(DIR+"/"+directory+"/avg_curve");
		}
		
		
		// Print results and save them out!
		double avgEpisodes = 0;
		double avgPerformance = 0;
		double avgTargetDifference = 0;
				
		System.out.println("R\tnTrain\tSource Score\tTarget Score");
		for (int r=0; r < REPEATS; r++){
			System.out.printf("%d\t%d\t%f\t%f\n", r, numEpisodes[r], sourcePerformance[r], targetPerformance[r]);
			avgEpisodes += numEpisodes[r];
			avgPerformance += sourcePerformance[r];
			avgTargetDifference += targetPerformance[r];
		}
		avgEpisodes /= REPEATS;
		avgPerformance /= REPEATS;
		avgTargetDifference /= REPEATS;
		
		System.out.println();		
		System.out.println(avgEpisodes + " " + avgPerformance + " " + avgTargetDifference);		
		
	}
	


	/** Assumes global constants are already loaded for the game to evaluate on 
	 * 	Prints */
	public static void evaluatePolicyTrajectory(int runLength){
		
		//LearningCurve[] curves = new LearningCurve[REPEATS];
					
		for (int i = 1; i <= runLength; i++){
			
			double score = 0;
			
			for (int r=0; r < REPEATS; r++){				
				RLPacMan pacman = create("transfer", r, "_"+i);
				score += evaluate(pacman, 1)[0];
			}
			System.out.println(score/REPEATS);
		}
	}
	
	/** Set up a learner.
	@param epNum can either be empty to load the final policy, or must be of the format "_x" where x is a number
	*/
	public static RLPacMan create(String learner, int runNum, String epNum) {
		
		int depth = 4;
		if (constants.MAZE_NUM == 4){		// myMaze
			depth = 2;
			//System.out.println("Setting depth 2");
		}
		
		FeatureSet teacherProto = TEACHER.startsWith("custom") ? new CustomFeatureSet(depth) : new DepthFeatureSet();
		FeatureSet studentProto = STUDENT.startsWith("custom") ? new CustomFeatureSet(depth) : new DepthFeatureSet();

		//System.out.println("feature size: " + studentProto.size());
		
		// Lone teacher
		if (learner.startsWith("teacher")) {
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy("myData/"+TEACHER+"/teacher/policy");
			return teacher;
		}
			
		// Lone student
		else if (learner.startsWith("independent")) {
			return STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
		}
		
		// TL: lead policy into student and let it run from there
		else if (learner.startsWith("transfer")) {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			//System.out.println("Trying to load from: " + DIR +"/" + constants.SOURCE_TASK + "/policy" + runNum + epNum);
			student.loadPolicy(DIR +"/" + constants.SOURCE_TASK + "/policy" + runNum + epNum);
			return student;
		}
		
		// Student-teacher pair
		else {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy("myData/"+TEACHER+"/teacher/policy");
			
			// Front-load the advice budget
			if (learner.startsWith("baseline")) {
				TeachingStrategy strategy = new AdviseAtFirst();
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states
			if (learner.startsWith("advise")) {
				int threshold = Integer.parseInt(learner.substring(6));
				TeachingStrategy strategy = new AdviseImportantStates(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Correct important mistakes
			if (learner.startsWith("correct")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new CorrectImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states with predicted mistakes
			if (learner.startsWith("predict")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new PredictImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
		}
		
		return null;
	}
	
	/** Generate learning curves. */
	public static void train(String learner, int start) {
		
		
		String directory = learner + "_" + constants.MAZE_NUM;
		if (constants.SAVE_DIR != null){
			directory = constants.SAVE_DIR;
		}
		
		// Make sure directory exists
		File file = new File(DIR+"/"+directory);
		if (!file.exists())
			file.mkdir();
		
		// Load old curves
// Currently we are passing in 0, so this part will be skipped. Otherwise, the next part would be skipped. 
		LearningCurve[] curves = new LearningCurve[REPEATS];
		for (int i=0; i<start; i++)
			curves[i] = new LearningCurve(constants.LENGTH+1, TRAIN, DIR+"/"+directory+"/curve"+i);
		
		// Begin new curves
		for (int i=start; i<REPEATS; i++) {
			curves[i] = new LearningCurve(constants.LENGTH+1, TRAIN);
			
			System.out.println("Training "+DIR+"/"+directory+" "+i+"...");
// This just sets up the student or teacher with the specified feature set and learning algorithm
			RLPacMan pacman = create(learner, i, "");
						
			// First point
			double[] initialData = pacman.episodeData();		// Starts off empty
			double[] initialScoreTime = evaluate(pacman, TEST);
			double initialScore = initialScoreTime[0];		// This returns the average score over TEST number of games
			double initialTime = initialScoreTime[1];
			curves[i].set(0, initialScore, initialData, initialTime);
			System.out.println(0);
			
			// Rest of the points
			for (int x=1; x<=constants.LENGTH; x++) {
				double[] data = new double[initialData.length];
				
				System.out.print(x);

				//watch(pacman);
				
				for (int y=0; y<TRAIN; y++) {
					episode(pacman);	// Does the same thing as evaluate, but doesn't return score
					
					double[] episodeData = pacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				double[] scoreTime = evaluate(pacman, TEST);
				double score = scoreTime[0];
				double time = scoreTime[1];
				curves[i].set(x, score, data, time);
				
				System.out.println(": " + score);
				
				pacman.savePolicy(DIR+"/"+directory+"/policy"+i+"_"+x);
				
				if (score >= constants.PERFORMANCE_THRESHOLD){
					break;
				}
				
			}
			
			
			
			// Save new curve and policy
			pacman.savePolicy(DIR+"/"+directory+"/policy"+i);
			curves[i].save(DIR+"/"+directory+"/curve"+i);
			
			// Average all curves
			try{
				LearningCurve avgCurve = new LearningCurve(Arrays.copyOf(curves, i+1));
				avgCurve.save(DIR+"/"+directory+"/avg_curve");
			}catch(Exception e){
				System.err.println("FAILED TO SAVE AVG_CURVE");
			}
		}
		
		System.out.println("Done.");
	}

	/** Train a learner for one more episode. */
// Basically does the same thing as evaluate but doesn't return the score	
	public static void episode(RLPacMan pacman) {

		Game game = new Game(rng.nextLong(), constants);
		pacman.startEpisode(game, false);

		while(!game.gameOver()) {
			
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));				
			pacman.processStep(game);
		}
	}

	/** Estimate the current performance of a learner. */
// Width is the number of episodes to test for (i.e. variable TEST above)	
	public static double[] evaluate(RLPacMan pacman, int width) {
		
		double[] scoreAndTime = new double[2];		
		double sumScore = 0;
		double sumSteps = 0;
		
// For each test episode		
		for(int i=0; i<width; i++) {
// Create and start a new game			
			Game game = new Game(rng.nextLong(), constants);
			pacman.startEpisode(game, true);
			while(!game.gameOver()) {
// getMove in pacman learner returns the lastAction	
// This will then recompute the next move to make.
				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));			
				pacman.processStep(game);
			}
			
			sumScore += game.getScore();
			sumSteps += game.getTotalTime();
			//System.out.println("time taken: " + game.getTotalTime());
		}

		scoreAndTime[0] = sumScore/width;
		scoreAndTime[1] = sumSteps/width;
		
		
		return scoreAndTime;
	}

	/** Observe a learner play a game. */
	public static void watch(RLPacMan pacman) {
		
		Game game=new Game(rng.nextLong(), constants);
		pacman.startEpisode(game, true);
		GameView gv=new GameView(game).showGame();

		while(!game.gameOver()) {
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));			
			pacman.processStep(game);
			
			try{Thread.sleep(game.constants.DELAY);}catch(Exception e){}
			gv.repaint();
		}
	}
	
	/** Select a teacher from the independent students. */
	public static void findBestTeacher() {
		
		double[] scores = new double[REPEATS];
		
		for (int i=0; i<REPEATS; i++) {
			BasicRLPacMan pacman = (BasicRLPacMan)create("independent",-1,"");
			pacman.loadPolicy(DIR+"/independent/policy"+i);
			scores[i] = evaluate(pacman, 500)[0];
			System.out.println(DIR+"/independent/policy"+i+": "+scores[i]);
		}
		
		int bestPolicy = 0;
		for (int i=0; i<REPEATS; i++)
			if (scores[i] > scores[bestPolicy])
				bestPolicy = i;
		
		System.out.println("Best: "+DIR+"/independent/policy"+bestPolicy);
	}
	
	/** Make a plottable file of Q-value gaps over a few episodes. */
	public static void plotGaps() {

		DataFile file = new DataFile("myData/"+TEACHER+"/teacher/gaps");
		file.clear();

		BasicRLPacMan pacman = (BasicRLPacMan)create("teacher", -1,"");
		int x = 0;

		for (int i=0; i<1; i++) {
			Game game = new Game(rng.nextLong());
			pacman.startEpisode(game, true);

			while(!game.gameOver()) {

				double[] qvalues = pacman.getQValues();
				Arrays.sort(qvalues);
				double gap = qvalues[qvalues.length-1] - qvalues[0];

				file.append(x+"\t"+gap+"\n");
				x++;

				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));
				pacman.processStep(game);
			}
		}

		file.close();
	}
	
	/** Test SVM choice prediction. */
	public static void testSVM() {
			
		BasicRLPacMan student = (BasicRLPacMan)create("independent", -1,"");
		BasicRLPacMan teacher = (BasicRLPacMan)create("teacher", -1,"");
		PredictImportantMistakes strategy = new PredictImportantMistakes(0);
		
		for (int i=0; i<300; i++) {
			Game game = new Game(rng.nextLong());
			student.startEpisode(game, false);
			teacher.startEpisode(game, true);
			
			strategy.startEpisode();
			int right = 0, wrong = 0, truePos = 0, falseNeg = 0, falsePos = 0;
			
			while(!game.gameOver()) {
				MOVE advice = teacher.getMove(game, -1);
				MOVE choice = student.getMove(game, -1);
				strategy.recordExample(teacher, choice);
				
				if (i > 0) {
					MOVE guess = strategy.predictChoice(teacher);
					boolean predict = (guess != advice);
					boolean mistake = (choice != advice);
					
					if (guess == choice)
						right++;
					else
						wrong++;
					
					if (mistake && predict)
						truePos++;
					else if (mistake && !predict)
						falseNeg++;
					else if (!mistake && predict)
						falsePos++;
				}
							
				game.advanceGame(choice, getGhostMove(game, game.constants.GHOST_TYPE));
				student.processStep(game);
				teacher.processStep(game);
			}
			
			if (i > 0) {
				double accuracy = right/(double)(right+wrong);
				double precision = truePos/(double)(truePos+falsePos);
				double recall = truePos/(double)(truePos+falseNeg);
				
				DecimalFormat f = new DecimalFormat("#.##");
				System.out.println("During episode "+i+": a="+f.format(accuracy)+", p="+f.format(precision)+", r="+f.format(recall));
			}
		}
	}
	
	/** Compare areas under two types of learning curves. */
	public static void compare(String dir1, String dir2) {
		
		LearningCurve[] curves1 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves1[i] = new LearningCurve(constants.LENGTH+1, TRAIN, "myData/"+dir1+"/curve"+i);
		
		double[] areas1 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas1[i] = curves1[i].area();
		
		LearningCurve[] curves2 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves2[i] = new LearningCurve(constants.LENGTH+1, TRAIN, "myData/"+dir2+"/curve"+i);
		
		double[] areas2 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas2[i] = curves2[i].area();
		
		double t0 = Stats.t(areas1, areas2);
		double dof = Stats.dof(areas1, areas2);
		System.out.println(dir1+" > "+dir2+" with 95% confidence if:");
		System.out.println(t0+" > t_0.05_"+dof);
	}
	
	private static EnumMap<GHOST, MOVE> getGhostMove(Game game, int ghostType){
		
		switch(ghostType){
			case 0:
				return ghostsR.getMove(game.copy(), -1);
			case 1:
				return ghostsS.getMove(game.copy(), -1);
			case 2:
				return ghostsC.getMove(game.copy(), -1);
			case 3:
				return ghostsL.getMove(game.copy(), -1);
			default:
				System.err.println("INVALID GHOST TYPE");
				System.exit(1);
				return null;				// Compilier is complaining... 
		}
	}
}
