package pacman;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import pacman.transferability.InstancesCreatorTL;
import pacman.transferability.SourceTaskSelector;
import pacman.transferability.Task;
import pacman.transferability.TaskFilter;
import pacman.transferability.TransferabilityMatrix;
import pacman.transferability.UtilsTL;
import pacman.utils.UtilsIO;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.GaussianProcesses;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.functions.SMOreg;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.classifiers.meta.AdditiveRegression;
import weka.classifiers.meta.Bagging;
import weka.classifiers.meta.Stacking;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.trees.M5P;
import weka.classifiers.trees.REPTree;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;


public class LearningTransferability {

	public static void main(String [] args){
		try {
			
			
			/*int [] task_nums = {2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
			double [] losses_mean = new double[task_nums.length];
			double [] losses_stdev = new double[task_nums.length];
			for (int i = 0; i < task_nums.length; i ++){
				double [] r_i =experiment("/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/TL_matrix_js_k30.txt",
						"pct_difference",20,task_nums[i],65*(i+1));
				
				losses_mean[i]=r_i[0];
				losses_stdev[i]=r_i[1];
			}
			for (int i = 0; i < task_nums.length; i ++){
				
				System.out.println(task_nums[i]+","+losses_mean[i]+","+losses_stdev[i]);
			}*/
			
			
			experiment("/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/TL_matrix_js_k30.txt",
						"pct_difference",20,-1,1);
			/*experiment("/home/jsinapov/research/TL-RL/AAMAS2014_data/TL_matrix_js_k3.txt",
					"pct_difference",20,-1);
			experiment("/home/jsinapov/research/TL-RL/AAMAS2014_data/TL_matrix_js_k5.txt",
					"pct_difference",20,-1);
			experiment("/home/jsinapov/research/TL-RL/AAMAS2014_data/TL_matrix_js_k10.txt",
					"pct_difference",20,-1);
			experiment("/home/jsinapov/research/TL-RL/AAMAS2014_data/TL_matrix_js_k15.txt",
					"pct_difference",20,-1);
			experiment("/home/jsinapov/research/TL-RL/AAMAS2014_data/TL_matrix_js_k30.txt",
					"pct_difference",20,-1);*/
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void outputData(ArrayList<Task> tasks,TransferabilityMatrix M,
			InstancesCreatorTL IC, String path){
		//1. Output names of tasks
		ArrayList<String> task_names = new ArrayList<String>();
		for (int i = 0; i < tasks.size(); i++)
			task_names.add(tasks.get(i).getName());
		UtilsIO.writeStringsToFile(task_names, new String(path+"/tasks.txt"));
		
		//2. Output transferability
		try {
			FileWriter FW = new FileWriter(new File(new String(path+"/transferability.txt")));
			for (int i = 0; i < tasks.size(); i ++){
				for (int j = 0; j < tasks.size(); j++){
					FW.write(new String(tasks.get(i).getName()+","+tasks.get(j).getName()+","+
							M.getValue(tasks.get(i).getName(), tasks.get(j).getName())+"\n"));
				
				}
			}
			FW.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//3. Output pairwise relational features
		try {
			FileWriter FW = new FileWriter(new File(new String(path+"/relational_features.txt")));
			for (int i = 0; i < tasks.size(); i ++){
				for (int j = 0; j < tasks.size(); j++){
					Instance x_ij = IC.createInstance(tasks.get(i), tasks.get(j));
					
					FW.write(new String(tasks.get(i).getName()+","+tasks.get(j).getName()+","));
					for (int k = 0; k < x_ij.numAttributes()-1; k++){
						if (x_ij.attribute(k).isNominal())
							FW.write("\""+x_ij.stringValue(k)+"\"");
						else
							FW.write(""+x_ij.value(k));
						
						if (k < x_ij.numAttributes()-2)
							FW.write(",");
						
					}
					
					FW.write("\n");
				
				}
			}
			FW.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//4. output task feature descriptors
		try {
			FileWriter FW = new FileWriter(new File(new String(path+"/task_descriptors.txt")));
			
			FW.write("task_id,");
			for (int i = 0; i < tasks.get(0).getAttributeNames().size();i++){
				FW.write(tasks.get(0).getAttributeNames().get(i));
				if (i <  tasks.get(0).getAttributeNames().size()-1)
					FW.write(",");
				else FW.write("\n");
			}
			
			for (int i = 0; i < tasks.size(); i ++){
				
				FW.write(new String(tasks.get(i).getName()+","));
					
				ArrayList<String> attr_names = tasks.get(i).getAttributeNames();
				for (int k = 0; k < attr_names.size(); k++){
					
					if (tasks.get(i).getAttributeTypes().get(k) != "nominal")
						FW.write(""+tasks.get(i).getAttributeValues().get(k));
					else 
						FW.write("\""+(int)tasks.get(i).getAttributeValues().get(k).doubleValue()+"\"");
					
					if (k < attr_names.size()-1)
						FW.write(",");
					else FW.write("\n");
				}
			}
			FW.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//5. compute task distance matrix
		try {
			FileWriter FW = new FileWriter(new File(new String(path+"/task_distances_for_baseline.txt")));
			for (int i = 0; i < tasks.size(); i ++){
				for (int j = 0; j < tasks.size(); j++){
					FW.write(new String(tasks.get(i).getName()+","+tasks.get(j).getName()+","+
							UtilsTL.getTaskDistance(tasks.get(i), tasks.get(j))+"\n"));
					
					
				
				}
			}
			FW.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static double [] experiment(String matrixfile, String features,
			int DCM_k, int num_train_tasks, int r_seed) throws Exception {
		System.out.println("\n\n\nUsing Matrix:\t"+matrixfile);
		System.out.println("Features:\t"+features);
		
		boolean doSampleBasedCV = false;
		
		Random r = new Random(r_seed);
		
		//get tasks
		ArrayList<Task> tasks = getTasks();
		
		ArrayList<String> attr_types = tasks.get(0).getAttributeTypes();
		double [] task_min_values = new double[tasks.get(0).getAttributeNames().size()];
		double [] task_max_values = new double[tasks.get(0).getAttributeNames().size()];
		for (int i = 0; i < task_min_values.length;i ++){
			task_max_values[i]=Double.MIN_VALUE;
			task_min_values[i]=Double.MAX_VALUE;
		}
		
		for (int i =0; i < tasks.size(); i++){
			ArrayList<Double> x_i = tasks.get(i).getAttributeValues();
			for (int k = 0; k < x_i.size(); k++){
				if (attr_types.get(k).equals("numeric")){
					double v = x_i.get(k).doubleValue();
					if (v > task_max_values[k]){
						task_max_values[k]=v;
					}
					if (v < task_min_values[k]){
						task_min_values[k]=v;
					}
				}
			}
		}
		
		/*for (int i = 0; i < task_min_values.length;i ++){
			System.out.println("Range "+i+":\t"+task_min_values[i]+" to "+ task_max_values[i]);
		}*/
		
		//load transferability matrix
		TransferabilityMatrix M = new TransferabilityMatrix(getTaskNames());
		M.loadFromFile(matrixfile);
		
		
		//test symmetricity
		int count_sym = 0;
		double avg_error = 0;
		for (int i = 0; i < tasks.size(); i ++){
			for (int j = 0; j < tasks.size(); j++){
				if (i!=j){
					double v_ij = M.getValue(tasks.get(i).getName(), tasks.get(j).getName());
					double v_ji = M.getValue(tasks.get(j).getName(), tasks.get(i).getName());
					double error_ij = Math.abs(v_ij-v_ji);
					avg_error+=error_ij;
					count_sym++;
				}
			}	
		}
		
		avg_error =avg_error / (double) count_sym;
		System.out.println("Sym error:\t"+avg_error);
		
		//create instances creator
		InstancesCreatorTL IC = new InstancesCreatorTL(features);
		IC.setMinMaxRanges(task_min_values, task_max_values);
		IC.setAttributeInfo(tasks.get(0).getAttributeNames(), tasks.get(0).getAttributeTypes());
		IC.setTransferabilityMatrix(M);
		IC.generateHeader();
		
		outputData(tasks,M,IC,"/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/data_for_anthony");
		
		
		//create all pairs
		ArrayList<Task[]> pairs = new ArrayList<Task[]>();
		for (int i = 0; i < tasks.size(); i ++){
			for (int j = 0; j < tasks.size(); j++){
				if (i != j){
					Task [] pair = new Task[2];
					pair[0]=tasks.get(i);
					pair[1]=tasks.get(j);
					pairs.add(pair);
				}
			}
		}

		//create instances for all pairs
		Instances weka_data = IC.createInstances(pairs);
		
		
		
		//evaluation for sample based cv
		Evaluation EV_cv = new Evaluation(weka_data);
		
		if (doSampleBasedCV){
			System.out.println("Performing sample-based cross validation...");
			EV_cv.crossValidateModel(getClassifier(weka_data), weka_data, 10, new Random(1));
			
			System.out.println("\n\nSample based CV:\n");
			System.out.println(EV_cv.toSummaryString());
		}
		//System.out.println(weka_data);*/
		
		int num_folds = 10;
		
		//evaluation
		Evaluation EV = new Evaluation(weka_data);
		Evaluation EV_overlap = new Evaluation(weka_data);
		Evaluation EV_overlap_random = new Evaluation(weka_data);
		Evaluation EV_testonly = new Evaluation(weka_data);
		Evaluation EV_topchoice = new Evaluation(weka_data);
		
		//evaluation statistics
		ArrayList<double[]> predicted_vs_actual_selected = new ArrayList<double[]>();
		ArrayList<Double> predicted_errors = new ArrayList<Double>();
		ArrayList<Double> loss_errors = new ArrayList<Double>();
		ArrayList<Integer> ranking_histogram = new ArrayList<Integer>();
		
		//evaluation statistics (random)
		ArrayList<Double> loss_errors_random = new ArrayList<Double>();
		ArrayList<Integer> ranking_histogram_random = new ArrayList<Integer>();
			
		//evaluation statistics (baseline)
		ArrayList<Double> loss_errors_baseline = new ArrayList<Double>();
		ArrayList<Integer> ranking_histogram_baseline = new ArrayList<Integer>();
				
	
		
		ArrayList<Double> dcms_model = new ArrayList<Double>();
		ArrayList<Double> dcms_baseline = new ArrayList<Double>();
		ArrayList<Double> dcms_random = new ArrayList<Double>();
		
		double avg_DCM_model = 0;
		double avg_DCM_baseline = 0;
		double avg_DCM_random = 0;
		double avg_DCM_optimal = 0;
		int dcm_counter = 0;
		
		//used when using subset of tasks for training
		Random r_n = new Random(r_seed);
		
		for (int fold = 0; fold < num_folds; fold++){
			//System.out.println("Fold "+fold);
			
			ArrayList<Task> tasks_train = TaskFilter.getTrainFold(tasks, num_folds, fold);
			ArrayList<Task> tasks_test = TaskFilter.getTestFold(tasks, num_folds, fold);
			
			
			
			//System.out.println("Train tasks:\t"+tasks_train.size());
			//System.out.println("Test tasks:\t"+tasks_test.size());
			
			SourceTaskSelector STS = new SourceTaskSelector(IC);
			STS.setClassifier(getClassifier(weka_data));
			
			//System.out.println("\nBuilding Classifier...");
			if (num_train_tasks == -1){
				STS.train(tasks_train);
			}
			else {
				
				
				ArrayList<Task> tasks_train_subset = TaskFilter.getRandomSubset(tasks_train, num_train_tasks, r_n);
			
				STS.train(tasks_train_subset);
			}
			
			//test on pairs from train and test
			ArrayList<Task[]> test_pairs_overlap = TaskFilter.getPairs(tasks_train, tasks_test);
			Instances weka_overlap = IC.createInstances(test_pairs_overlap);
			EV.evaluateModel(STS.getClassifier(), weka_overlap);
			EV_overlap.evaluateModel(STS.getClassifier(), weka_overlap);

			
			ArrayList<Task[]> test_pairs = TaskFilter.getPairs(tasks_test);
			Instances weka_test = IC.createInstances(test_pairs);
			EV.evaluateModel(STS.getClassifier(), weka_test);
			EV_testonly.evaluateModel(STS.getClassifier(), weka_test);
			
			//System.out.println(EV.toSummaryString());
			
			//evaluate random guessing
			Random r_test = new Random(fold);
			for (int p = 0; p < weka_overlap.numInstances(); p++){
				double prior_prediction = weka_data.instance(r_test.nextInt(weka_data.numInstances())).classValue();
				EV_overlap_random.evaluateModelOnce(prior_prediction, weka_overlap.instance(p));
			}
			
			
			
			//find the best sources for all test tasks
			for (int t = 0; t < tasks_test.size(); t++){
				
				//System.out.println("\nTarget task:\t"+tasks_test.get(t).getName());
				
				//pick the source
				Task best_predicted_source_t = STS.findBestSource(tasks_train, tasks_test.get(t));
				
				//System.out.println("\tBest predicted source:\t"+best_predicted_source_t.getName());
				
				//get predicted jumpstart for top choice
				double predicted_js = STS.processPair(best_predicted_source_t, tasks_test.get(t));
				ArrayList<Task[]> top_pair_data = new ArrayList<Task[]>();
				Task [] top_pair = new Task[2];
				top_pair[0]=best_predicted_source_t;
				top_pair[1]=tasks_test.get(t);
				top_pair_data.add(top_pair);
				Instances top_pair_weka_data = IC.createInstances(top_pair_data);
				EV_topchoice.evaluateModel(STS.getClassifier(), top_pair_weka_data);
				
				//get actual jumpstart for predicted best source
				double actual_js = M.getValue(best_predicted_source_t.getName(), tasks_test.get(t).getName());
				double [] pred_vs_act = new double[2];
				pred_vs_act[0]=predicted_js;
				pred_vs_act[1]=actual_js;
				predicted_vs_actual_selected.add(pred_vs_act);
				
				if (!Double.isNaN(actual_js)){
					//System.out.println(predicted_js+"\t"+actual_js);
					
					predicted_errors.add(new Double(Math.abs(predicted_js-actual_js)));
					
	
					//get actual best source and it's jumpstart
					Task best_actual_source_t = M.getBestSource(tasks_train, tasks_test.get(t));
					double best_actual_js = M.getValue(best_actual_source_t.getName(), tasks_test.get(t).getName());
					
					//compute loss
					double loss_t = Math.abs(actual_js-best_actual_js);
					loss_errors.add(loss_t);
					
					
					/* random selection */
					Task random_source_i = tasks_train.get(r.nextInt(tasks_train.size()));
					double js_random_i = M.getValue(random_source_i.getName(), tasks_test.get(t).getName());
					double loss_random_t = Math.abs(js_random_i-best_actual_js);
					loss_errors_random.add(loss_random_t);
					
					/* baseline selection */
					Task baseline_source_i = UtilsTL.getClosestTask(tasks_train, tasks_test.get(t));
					double js_baseline_i = M.getValue(baseline_source_i.getName(), tasks_test.get(t).getName());
					double loss_baseline_t = Math.abs(js_baseline_i-best_actual_js);
					loss_errors_baseline.add(loss_baseline_t);
					
					/* sort sources */
					ArrayList<Task> sorted_sources_groundtruth = M.sortTasksByScore(tasks_train, tasks_test.get(t));
					
					//position of best selected in true ranking
					int pos_in_ranking = -1;
					int pos_in_ranking_random = -1;
					int pos_in_ranking_baseline = -1;
					for (int k = 0; k < sorted_sources_groundtruth.size(); k++){
						if (sorted_sources_groundtruth.get(k).getName().equals(best_predicted_source_t.getName())){
							pos_in_ranking = k;
						}
						
						if (sorted_sources_groundtruth.get(k).getName().equals(random_source_i.getName())){
							pos_in_ranking_random = k;
						}
						
						if (sorted_sources_groundtruth.get(k).getName().equals(baseline_source_i.getName())){
							pos_in_ranking_baseline = k;
						}
					}
					
					double [] sorted_sources_ground_scores = M.getScores(sorted_sources_groundtruth, tasks_test.get(t));
					double DCG_truth = UtilsTL.computeDiscountedCumulativeGain(sorted_sources_ground_scores, DCM_k);
				
					
					
					ArrayList<Task> sorted_sources_model = STS.sortSources(tasks_train, tasks_test.get(t));
					double [] sorted_sources_model_scores = M.getScores(sorted_sources_model, tasks_test.get(t));
					double DCG_model = UtilsTL.computeDiscountedCumulativeGain(sorted_sources_model_scores, DCM_k);
					avg_DCM_model +=	(DCG_model / DCG_truth);	
					dcms_model.add(new Double((DCG_model / DCG_truth)));
					
					
					/*for (int p = 0; p < DCM_k; p++){
						System.out.println(sorted_sources_groundtruth.get(p).getName()+": "+sorted_sources_ground_scores[p]+
												"\t"+sorted_sources_model.get(p).getName()+": "+sorted_sources_model_scores[p]);
					}*/
					
					
					ArrayList<Task> sorted_sources_baseline = UtilsTL.sortTasksByDistance(tasks_train, tasks_test.get(t));
					double [] sorted_sources_model_baseline = M.getScores(sorted_sources_baseline, tasks_test.get(t));
					double DCG_baseline = UtilsTL.computeDiscountedCumulativeGain(sorted_sources_model_baseline, DCM_k);
					avg_DCM_baseline +=	(DCG_baseline / DCG_truth);
					dcms_baseline.add(new Double((DCG_baseline / DCG_truth)));
					
					ArrayList<Task> sorted_sources_random = UtilsTL.shuffleTasks(tasks_train, r);
					double [] sorted_sources_model_random = M.getScores(sorted_sources_random, tasks_test.get(t));
					double DCG_random = UtilsTL.computeDiscountedCumulativeGain(sorted_sources_model_random, DCM_k);
					avg_DCM_random +=	(DCG_random / DCG_truth);
					dcms_random.add(new Double((DCG_random / DCG_truth)));
					
					//System.out.println(DCG_truth+"\t"+DCG_model+"\t"+DCG_baseline+"\t"+DCG_random);
					
					
					dcm_counter++;
					
					ranking_histogram.add(new Integer(pos_in_ranking));
					ranking_histogram_random.add(new Integer(pos_in_ranking_random));
					ranking_histogram_baseline.add(new Integer(pos_in_ranking_baseline));
					
				}
				/*for (int k = 0; k < 10; k ++){
					System.out.println(sorted_sources.get(k).getName()+"\t"+M.getValue(sorted_sources.get(k).getName(), tasks_test.get(t).getName()));
				}*/
			}
		}
		
		if (doSampleBasedCV){
			System.out.println("\n\nSample based CV:\n");
			System.out.println(EV_cv.toSummaryString());
		}
		
		System.out.println("\n\nTask-based CV (overlap):\n");
		System.out.println(EV_overlap.toSummaryString());
		
		System.out.println("\n\nTask-based CV random (overlap):\n");
		System.out.println(EV_overlap_random.toSummaryString());
		
		System.out.println("\n\nTop choice evaluation:\n");
		System.out.println(EV_topchoice.toSummaryString());
		
		/*System.out.println("\n\nTask-based CV (test only):\n");
		System.out.println(EV_testonly.toSummaryString());
		
		
		System.out.println("\n\nTask-based CV:\n");
		System.out.println(EV.toSummaryString());*/
		
		
		double [] predicted_errors_array = UtilsTL.toDoubleArray(predicted_errors);
		UtilsTL.saveArray(predicted_errors_array, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/predicted_errors_array.txt");
		
		double [] loss_errors_array = UtilsTL.toDoubleArray(loss_errors);
		UtilsTL.saveArray(loss_errors_array, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/loss_errors_array.txt");
		
		double [] loss_errors_random_array = UtilsTL.toDoubleArray(loss_errors_random);
		UtilsTL.saveArray(loss_errors_random_array, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/loss_errors_random_array.txt");
		
		double [] loss_errors_baseline_array = UtilsTL.toDoubleArray(loss_errors_baseline);
		UtilsTL.saveArray(loss_errors_baseline_array, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/loss_errors_baseline_array.txt");
		
		double [] rank_hist = UtilsTL.toIntegerArray(ranking_histogram);
		UtilsTL.saveArray(rank_hist, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/rank_hist.txt");
		
		double [] rank_hist_baseline = UtilsTL.toIntegerArray(ranking_histogram_baseline);	
		UtilsTL.saveArray(rank_hist_baseline, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/rank_hist_baseline.txt");
		
		double [] rank_hist_random = UtilsTL.toIntegerArray(ranking_histogram_random);	
		UtilsTL.saveArray(rank_hist_random, "/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/rank_hist_random.txt");
		
		double [] dcms_model_array = UtilsTL.toDoubleArray(dcms_model);
		double [] dcms_baseline_array = UtilsTL.toDoubleArray(dcms_baseline);
		double [] dcms_random_array = UtilsTL.toDoubleArray(dcms_random);
		
		
		System.out.println("Avg. of predicted_errors_array:\t"+Utils.mean(predicted_errors_array)+" +- "+Math.sqrt(Utils.variance(predicted_errors_array)));
		
		System.out.println("Avg. of loss_errors_array:\t"+Utils.mean(loss_errors_array)+" +- "+Math.sqrt(Utils.variance(loss_errors_array)));
		System.out.println("Avg. of loss_errors_array (baseline):\t"+Utils.mean(loss_errors_baseline_array)+" +- "+Math.sqrt(Utils.variance(loss_errors_baseline_array)));
		System.out.println("Avg. of loss_errors_array (random):\t"+Utils.mean(loss_errors_random_array)+" +- "+Math.sqrt(Utils.variance(loss_errors_random_array)));
		
		System.out.println("Avg. pos. in ranking:\t"+Utils.mean(rank_hist)+" +- "+Math.sqrt(Utils.variance(rank_hist)));
		System.out.println("Avg. pos. in ranking (baseline):\t"+Utils.mean(rank_hist_baseline)+" +- "+Math.sqrt(Utils.variance(rank_hist_baseline)));
		System.out.println("Avg.  pos. in ranking: (random):\t"+Utils.mean(rank_hist_random)+" +- "+Math.sqrt(Utils.variance(rank_hist_random)));
		
		
		avg_DCM_model = avg_DCM_model / dcm_counter;
		avg_DCM_baseline = avg_DCM_baseline / dcm_counter;
		avg_DCM_random = avg_DCM_random / dcm_counter;

		System.out.println("DCM (model):\t"+Utils.mean(dcms_model_array)+" +- "+Math.sqrt(Utils.variance(dcms_model_array)));
		System.out.println("DCM (baseline):\t"+Utils.mean(dcms_baseline_array)+" +- "+Math.sqrt(Utils.variance(dcms_baseline_array)));
		System.out.println("DCM (random):\t"+Utils.mean(dcms_random_array)+" +- "+Math.sqrt(Utils.variance(dcms_random_array)));
		
		System.out.println("DCM (model):\t"+avg_DCM_model);
		System.out.println("DCM (baseline):\t"+avg_DCM_baseline);
		System.out.println("DCM (random):\t"+avg_DCM_random);
		
		double [] result_array = {Utils.mean(loss_errors_array), Math.sqrt(Utils.variance(loss_errors_array))};
		return result_array;
	}
	
	public static Classifier getClassifier(Instances data){
		
		/*SMOreg C = new SMOreg();
		PolyKernel K;
		try {
			
			K = new PolyKernel( data,  250007, 2.0, true);
			C.setKernel(K);
			return C;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}*/
		
		
		
		
		/*GaussianProcesses C = new GaussianProcesses();
		return C;*/
		
		//best so far
		/*AdditiveRegression C = new AdditiveRegression();
		C.setClassifier(new REPTree());
		return C;*/
		
		//linear regression
		return new LinearRegression();
		
		//return new M5P();
		
		/*AdditiveRegression C = new AdditiveRegression();
		C.setClassifier(new M5P());
		return C;*/
		
		/*AdditiveRegression C = new AdditiveRegression();
		C.setClassifier(new LinearRegression());
		return C;*/
		
		/*Bagging C = new Bagging();
		C.setBagSizePercent(80);

		C.setClassifier(new LinearRegression());
		return C;*/
		
		/*Stacking C = new Stacking();
		Classifier [] C_s = { new M5P(), new REPTree(), new LinearRegression(), new DecisionTable()}; 
		C.setClassifiers(C_s);
		return C;*/
	}
	
	public static ArrayList<Task> getTasks(){
		ArrayList<String> task_names = getTaskNames();
		ArrayList<int[]> task_params = getTasksParams();
		
		ArrayList<Task> tasks = new  ArrayList<Task>();
		 
		for (int i = 0 ; i < task_names.size(); i++){
			Task T_i = new Task(task_names.get(i));
			int [] params_i = task_params.get(i);
			
			//attributes related to dynamics
			T_i.addAttributeValue("ghost_type", new Double(params_i[1]), "nominal");
			T_i.addAttributeValue("ghost_slowdown", new Double(params_i[2]), "numeric");
			T_i.addAttributeValue("ghost_num", new Double(params_i[3]), "numeric");
			
			//attributes related to graph
			String maze_filename = new String("/home/jsinapov/research/TL-RL/papers/AAMAS_2015/AAMAS2014_data/maze_"+params_i[0]+"_features.txt");
			T_i.addNumericalAttributesFromFile(maze_filename);
		
			tasks.add(T_i);
		}
		
		return tasks;
		
	}

	//DO NOT CHANGE THE ORDER OF THIS LIST
	public static ArrayList<String> getTaskNames(){
		ArrayList<String> source_task_names = new ArrayList<String>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
					}
				}
			}
		}
		
		return source_task_names;
	}
	
	public static String generateDirectoryName(String learner, 
			int mazeNum_i, int ghostType_i, 
			int ghostSlowdown_i, int nGhosts){

		if (learner.startsWith("independent")) {
			return new String(learner+"_maze"+mazeNum_i+"_type"+ghostType_i+"_slow"+ghostSlowdown_i+"_ghosts"+nGhosts+"");
		}
		else if (learner.startsWith("transfer")) { 
			return learner; //this should be something like "transfer_5_to_7"
		}
		else
			return "WTF";
	}
	
	public static ArrayList<int[]> getTasksParams(){
		ArrayList<int[]> source_task_params = new ArrayList<int[]>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						int [] params = new int[4];
						params[0] = maze;
						params[1] = gtype;
						params[2] = slowdown;
						params[3] = num_g;
						
						
						
						source_task_params.add(params);
					}
				}
			}
		}
		
		return source_task_params;
	}
}


