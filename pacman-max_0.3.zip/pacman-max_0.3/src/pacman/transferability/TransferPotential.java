package pacman.transferability;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import pacman.entries.pacman.DepthFeatureSet;


/*
 * This class is used to generate the transfer potential between two Pacman Tasks.
 * 
 * It has been further expanded to include static methods that facilitate the organization of 
 * tasks based on the TransferPotential metric.
 */
public class TransferPotential {
	
	private static boolean DEBUG = true;
	private static double EPSILON = 1;
	
	private Task source;
	private Task target;
	
	public TransferPotential(Task source, Task target){
		if(source.task_num == -1)
			System.out.println(source.name);
		if(target.task_num == -1)
			System.out.println(target.name);
		this.source = source;
		this.target = target;
	}

	/*
	 * Return the Applicability of the source relative to the target task
	 * This is a value that determines the similarity in the feature space of the tasks.
	 * 
	 * Particularly, if the source task was learnt as a potential function, how many instances would this function 
	 * 'fire' when learning the target task?
	 */
	public double getApplicability(){
		double applicability = 0.0;
		/*if(source.features.contains(DepthFeatureSet.REGULAR_PILL) && target.features.contains(DepthFeatureSet.REGULAR_PILL))
			applicability += ((double) target.num_pills / source.num_pills);
		if(source.features.contains(DepthFeatureSet.REGULAR_GHOST) && target.features.contains(DepthFeatureSet.REGULAR_GHOST))
			applicability += ((double) target.num_ghosts / source.num_ghosts);
		if(source.features.contains(DepthFeatureSet.POWER_PILL) && target.features.contains(DepthFeatureSet.POWER_PILL))
			applicability += ((double) target.num_super / source.num_super);
		if(source.features.contains(DepthFeatureSet.EDIBLE_GHOST) && target.features.contains(DepthFeatureSet.EDIBLE_GHOST))
			applicability += ((double) target.num_ghosts / source.num_ghosts);
		//applicability *= Math.pow(target.train_depth, 2) - Math.pow(source.train_depth, 2);
		return applicability;*/
		if(source.features.contains(DepthFeatureSet.REGULAR_PILL) && target.features.contains(DepthFeatureSet.REGULAR_PILL))
			applicability += target.num_junctions * nPermuteAllM(source.train_depth, Math.min(source.train_depth, target.num_pills));
		if(source.features.contains(DepthFeatureSet.REGULAR_GHOST) && target.features.contains(DepthFeatureSet.REGULAR_GHOST))
			applicability += target.num_junctions * nPermuteAllM(source.train_depth, Math.min(source.train_depth, target.num_ghosts));
		if(source.features.contains(DepthFeatureSet.POWER_PILL) && target.features.contains(DepthFeatureSet.POWER_PILL))
			applicability += target.num_super * nPermuteAllM(source.train_depth, Math.min(source.train_depth, target.num_super));
		if(source.features.contains(DepthFeatureSet.EDIBLE_GHOST) && target.features.contains(DepthFeatureSet.EDIBLE_GHOST))
			applicability += target.num_junctions * nPermuteAllM(source.train_depth, Math.min(source.train_depth, target.num_ghosts));
		return applicability;
		
	}
	
	//permutes from m ... 1
	public double nPermuteAllM(int n, int m){
		double sum = 0.0;
		for(int i = 1; i <= m; i++){
			sum += nPermuteM(n, i);
		}
		return sum;
	}
	
	public double nPermuteM(int n, int m){
		double n_collection = 1.0;
		double m_collection = 1.0;
		if(m > n){
			System.out.println("Cannot compute permuation");
			return -1.0;
		}
		for(int i = 1; i <= n; i++)
			n_collection*=i;
		for(int i = 1; i <= (n - m); i++)
			m_collection*=i;
		return n_collection / m_collection;
	}
	
	/*
	 * Return the 'StateSpace' function between tasks which represents the cost
	 * of learning the source relative to the target
	 */
	public double getStateSpace(){
		return (double) target.train_depth - source.train_depth;
	}
	
	public double getTransferPotential(){
		if(DEBUG){
			//System.out.println("App: " + getApplicability());
			//System.out.println("Sspace: " + getStateSpace());
		}
		if(getStateSpace() == 0.0)
			return -1.0;
		return (double) getApplicability() / getStateSpace();
	}
	
	/*
	 * Takes in a vector of Task objects, with their task attributes already resolved.
	 * Returns a vector of vectors, with each vector of tasks being a grouping of tasks with 
	 * identical binary feature distributions
	 * 
	 * Step 1:
	 */
	public static ArrayList<ArrayList<Task>> sortTasksOnFeatures(ArrayList<Task> tasks){
		ArrayList<ArrayList<Task>> result = new ArrayList<ArrayList<Task>>();
		int[] occ = new int[tasks.size()];
		
		
		for(int i = 0; i < tasks.size(); i++){
			ArrayList<Integer> feature = tasks.get(i).features;
			ArrayList<Task> group = new ArrayList<Task>();
			if(occ[i] != 1){
				for(int j = 0; j < tasks.size(); j++){
					if(tasks.get(j).features.equals(feature)){
						group.add(tasks.get(j));
						occ[j] = 1;
					}
				}
				result.add(group);
			}
		}
		
		return result;
	}
	
	/*
	 * This function sorts a vector of task groups internally based on initial transfer value relative to the final target task.
	 * Inter-group transfer is evaluated here.
	 * 
	 * Step 2:
	 */
	public static ArrayList<ArrayList<Tuple<Task, Double, Double>>> sortTaskGroups(ArrayList<ArrayList<Task>> taskGroups, Task target){		
		/*
		 * Assign initial transfer potential values (relative to target task)
		 * TODO: make this happen initially, rather than handing around vectors of tasks.
		 */
		ArrayList<ArrayList<Tuple<Task, Double, Double>>> tupleGroups = new ArrayList<ArrayList<Tuple<Task, Double, Double>>>();
		
		for(ArrayList<Task> group : taskGroups){
			ArrayList<Tuple<Task, Double, Double>> tupleGroup = new ArrayList<Tuple<Task, Double, Double>>();
			
			for(Task t : group){
				TransferPotential tp = new TransferPotential(t, target);
				Tuple<Task, Double, Double> myTuple = new Tuple<Task, Double, Double>(t, tp.getTransferPotential(), 0.);
				if(tp.getTransferPotential() > EPSILON)
					tupleGroup.add(myTuple);
			}
			if(tupleGroup.size() > 0)
				tupleGroups.add(tupleGroup);
		}
		
        /*
         * Sort based on transfer value
         */
        for(ArrayList<Tuple<Task, Double, Double>> group : tupleGroups){
            List<Tuple<Task, Double, Double> > tasks = group;

            Comparator<Tuple<Task,Double, Double>> comparator = new Comparator<Tuple<Task, Double,Double>>(){

                public int compare(Tuple<Task, Double, Double> tupleA, Tuple<Task, Double,Double> tupleB){
                    return tupleB.getY().compareTo(tupleA.getY());
                }
            };
            
            if(DEBUG){
	            //System.out.println(tasks.toString());
	            //System.out.println("After sorting on transfer pot...");
	            Collections.sort(tasks,comparator);
	            System.out.println(tasks.toString());
	            System.out.println();
            }
            else
	            Collections.sort(tasks,comparator);
        }
        		
		return tupleGroups;
	}
	
	// one of many goose chase algorithms attempted
	public static void pairWiseTransfer(ArrayList<Task> tasks){
		double tempval, max = 0, epsilon = 0.0;
		int maxtask = -1;
		for(int i = 0; i < tasks.size(); i++){
			for(int j = 0; j < tasks.size(); j++){
				if(i != j){
					TransferPotential tp = new TransferPotential(tasks.get(j), tasks.get(i));
					tempval = tp.getTransferPotential();
					if(tempval > epsilon && tempval > max){
						max = tempval;
						maxtask = tasks.get(j).task_num;
					}
				}
			}
			System.out.println("Transfered from " + maxtask + " to task " + tasks.get(i).task_num + " due to value " + max);
			max = 0;
			maxtask = -1;
		}
	}
	
	/*
	 * This function facilitates transfer between task groups over the minimal distance between the groups feature descriptors.
	 * This function also builds the overall curriculum tree.
	 */
	public static void intraGroupTransfer(ArrayList<ArrayList<Tuple<Task, Double, Double>>> taskGroups, Task targetTask){
        int[] occ = new int[taskGroups.size()];
		
		TreeNode<Task> root = new TreeNode<Task>(targetTask);
        
        int bumper = 0;
        
	    for(int i = 0; i < taskGroups.size(); i++){
	    	if(occ[i] != 1){	//this group hasn't been considered yet
	    		//occ[i] = 1;
	    		ArrayList<Tuple<Task, Double, Double>> sourceGroup = taskGroups.get(i);
	    		ArrayList< ArrayList<Tuple<Task, Double, Double>>> targetGroups = new ArrayList< ArrayList<Tuple<Task, Double, Double>>>();

	    		//ArrayList<Tuple<Task, Double, Double>> targetGroup;
	    		
	    		//targetGroups.add(minimizeDistance(sourceGroup, taskGroups, occ, false));
	    		targetGroups = minimizeDistance2(sourceGroup, taskGroups, occ, false);
	    		for(ArrayList<Tuple<Task, Double, Double>>  targetGroup : targetGroups){
	    		
		    		if(targetGroup == null){
		                //TreeNode<Task>child = new TreeNode<Task>(sourceGroup.get(0).getX());
	                    //root.addChild(child);
			    		//targetGroup = minimizeDistance(sourceGroup, taskGroups, occ, true);
		    		}
		    		else{
			    		//now compute the actual branches between task groups
			    		double maxVal = Double.MIN_VALUE;
			    		double tempVal = 0.;
			    		int maxIndex = -1;
		
			    		TreeNode<Task> srcChild = makeBranch(sourceGroup, root);
			    		TreeNode<Task> targetChild = makeBranch(targetGroup, root);
			    		
			    		boolean transfered = false;
			    		for(int j = 0; j < sourceGroup.size(); j++){
			    			Tuple<Task, Double, Double> curSource = sourceGroup.get(j);
			    			srcChild = root.findChild(curSource.getX());
			    			bumper = 0;
			    			//System.out.println("srcChild " + srcChild.getData().task_num);
			    			maxIndex = -1;
			    			for(int k = 0; k < targetGroup.size(); k++){
			    				Tuple<Task, Double, Double> curTarget = targetGroup.get(k);
			    				targetChild.findChild(curTarget.getX());
			    				
			    				TransferPotential tp = new TransferPotential(curSource.getX(), curTarget.getX());
			    				tempVal = tp.getTransferPotential();
			    				System.out.println("tempVal: " + tempVal);
			    				
			    				if(tempVal > maxVal && tempVal > EPSILON){
			    					maxVal = tempVal;
			    					maxIndex = k;
			    				}
			    			}
			    			if(maxIndex != -1 && srcChild != null){
			    				bumper = maxIndex;
			    				targetChild.addChild(srcChild);
			    				transfered = true;
			    				System.out.println("Adding");
			                }
			    			else
			    				bumper+=1;
			    		}
			    		if(!transfered)
			    			occ[i] = 0;
			    	}
	    		}
	    		System.out.println("Task group:" + i + " of " + taskGroups.size());
	    	}
        }
	    
	    /*
	     * Enable this if you want a tree rather than a DAG. Its assumed if this is enabled that the mainline branches are not yet children of the root.
	     
	    for(int i = 0; i < taskGroups.size(); i++){

	    	ArrayList<Tuple<Task, Double, Double>> sourceGroup = taskGroups.get(i);
    		TreeNode<Task> srcChild = makeBranch(sourceGroup, root);
	    	if(srcChild.isRoot())
	    		root.addChild(srcChild);
	    }*/

	    System.out.println("PRINTING CURRICULUM TREE. TASKS DENOTED BY THEIR TASK IDs.");
        root.printTree();
	}
	
	/*
	 * Returns an arraylist of groups that contain BFD as a subset of the source
	 */
	public static ArrayList< ArrayList<Tuple<Task, Double, Double>>> minimizeDistance2(ArrayList<Tuple<Task, Double, Double>> targetGroup, ArrayList<ArrayList<Tuple<Task, Double, Double>>> taskGroups, int[] occ, boolean force){
		ArrayList< ArrayList<Tuple<Task, Double, Double>> > result = new ArrayList < ArrayList<Tuple<Task, Double, Double>> >();
		
		int group_vector = 0;

		if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_PILL) )
			group_vector += 1;
		if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_GHOST) )
			group_vector += 1;
		if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.POWER_PILL) )
			group_vector += 1;
		if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.EDIBLE_GHOST) )
			group_vector += 1;
		
		int tempDist = 0;
		boolean disqualified = false;
		for(int i = 0; i < taskGroups.size(); i++){
			tempDist = 0;
			disqualified = false;
			if(!targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_PILL) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.REGULAR_PILL))
				disqualified = true;

			if(!targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_GHOST) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.REGULAR_GHOST))
				disqualified = true;

			if(!targetGroup.get(0).getX().features.contains(DepthFeatureSet.POWER_PILL) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.POWER_PILL))
				disqualified = true;

			if(!targetGroup.get(0).getX().features.contains(DepthFeatureSet.EDIBLE_GHOST) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.EDIBLE_GHOST))
				disqualified = true;

							
			if(!disqualified && taskGroups.get(i) != targetGroup){
				result.add(taskGroups.get(i));
			}
		}

		return result;
	}
	/*
	 * A helper function to compute the distances between feature vector.
	 * This function will return the task group that is the most similar to the targetGroup.
	 * The occupancy bit vector ensures that there are no cyclic dependencies among the groups.
	 * 
	 * In the event of a tie, the first group encountered that gave that score is returned.
	 */
	public static ArrayList<Tuple<Task, Double, Double>> minimizeDistance(ArrayList<Tuple<Task, Double, Double>> targetGroup, ArrayList<ArrayList<Tuple<Task, Double, Double>>> taskGroups, int[] occ, boolean force){
		ArrayList<Tuple<Task, Double, Double>> result = null;
		
		int minDist = 4;
		int tempDist = 0;
		for(int i = 0; i < taskGroups.size(); i++){
			tempDist = 4;
			if((occ[i] != 1 || force)){
				//tempDist = targetGroup.get(0).getX().features.size() - taskGroups.get(i).get(0).getX().features.size();
				
				if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_PILL) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.REGULAR_PILL))
					tempDist -= 1;
				if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.REGULAR_GHOST) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.REGULAR_GHOST))
					tempDist -= 1;
				if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.POWER_PILL) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.POWER_PILL))
					tempDist -= 1;
				if(targetGroup.get(0).getX().features.contains(DepthFeatureSet.EDIBLE_GHOST) && taskGroups.get(i).get(0).getX().features.contains(DepthFeatureSet.EDIBLE_GHOST))
					tempDist -= 1;
								
				if(tempDist < minDist){
					tempDist = minDist;
					result = taskGroups.get(i);
				}
			}
		}
		System.out.println("target grp; " + targetGroup.get(0));
		System.out.println("min dist grp: " + result);
		return result;
	}
	
	/*
	 * This function will do 1 of 2 things:
	 * 	if the taskGroup has already been linked into the root previously (and not necessarily directly), the Node of the 
	 * 		head of taskGroup will be returned
	 *  otherwise, taskGroup has never been constructed into the tree. Then taskGroup will be connected in a chain and the 
	 *  	head of the chain will be returned.
	 *  
	 *  Once this method is called on taskGroup, it enables one to search the root on the task_number of a task in taskGroup.
	 */
	public static TreeNode<Task> makeBranch(ArrayList<Tuple<Task, Double, Double>> taskGroup, TreeNode<Task> root){
		
		TreeNode<Task> result = root.findChild(taskGroup.get(0).getX());
		if(result == null){
			TreeNode<Task> head = new TreeNode<Task>(taskGroup.get(0).getX());
			TreeNode<Task> child;
			result = head;
			for(int i = 1; i < taskGroup.size(); i++){
				child = new TreeNode<Task>(taskGroup.get(i).getX());
				head.addChild(child);
				head = child;
			}
			root.addChild(result);
		}
		
		return result;
	}
	
}
