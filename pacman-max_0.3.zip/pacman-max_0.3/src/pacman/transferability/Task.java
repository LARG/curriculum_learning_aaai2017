package pacman.transferability;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import pacman.entries.pacman.DepthFeatureSet;

public class Task {

	String name;
	
	ArrayList<String> attribute_names;
	ArrayList<Double> values;
	ArrayList<String> attribute_types; //either "numeric" or "nominal"
	
	//these specify the exact task parameters for internal game representation
	public int maze_num;
	public int ghost_type;
	public int ghost_speed;
	public int num_ghosts;
	
	
	//these specify the relevant features, if defined by the task
	ArrayList<Integer> features;
	public boolean regular_pill = false;
	public boolean power_pill = false;
	public boolean regular_ghost = false;
	public boolean edible_ghost = false;
	
	//these specify special parameters that describe the features of a task
	public int num_pills;
	public int num_super;
	public int train_depth;
	public int num_junctions;
	
	//misc
	public String policy_path = null;
	public String prefix = null;
	public int task_num = -1;
	public boolean always_edible = false;
	
	public Task(String name){
		this.name = name;
		
		attribute_names = new ArrayList<String>();
		attribute_types = new ArrayList<String>();
		values = new ArrayList<Double>();
		features = new ArrayList<Integer>();
	}
	
	public String getName(){
		return name;
	}
	
	public ArrayList<String> getAttributeNames(){
		return attribute_names;
	}
	
	public ArrayList<String> getAttributeTypes(){
		return attribute_types;
	}
	
	public ArrayList<Double> getAttributeValues(){
		return values;
	}
	
	/*
	 * This returns all the features that should be included in a transfer experiment (as specified by the task) 
	 * in Integer[] form
	 */
	public Integer[] getFeatureArray(){
		Integer[] result = new Integer[features.size()];
		features.toArray(result);
		return result;
	}
	
	public void printDebug(){
		System.out.println("Task name:\t"+name);
		for (int i = 0; i < attribute_names.size(); i++){
			System.out.println("\t"+attribute_names.get(i)+"\t"+values.get(i).doubleValue()+"\t"+attribute_types.get(i));
		}
	}
	
	public void addAttributeValue(String attribute, Double value, String type){
		attribute_names.add(attribute);
		attribute_types.add(type);
		values.add(value);
	}
	
	/* Note that this function has changed over its previous usage
	 * 
	 * It more or less holds its old form, but certain attribute names trigger a specialized response.
	 * Usually these will be names of attributes that actually define parameters.
	 * 
	 * This does possibly reduce the generality of this class, but contains a whole lot more code in one place.
	 */
	public void addNumericalAttributesFromFile(String filename){
		try {
			BufferedReader BR = new BufferedReader(new FileReader(new File(filename)));
			
			while(true){
				String line = BR.readLine();
				
				if (line == null)
					break;
				
				String [] tokens = line.split("\t");
				if (tokens.length == 2){
					if(tokens[0].equals("maze_num")){
						maze_num = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("ghost_type")){
						ghost_type = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("ghost_speed")){
						ghost_speed = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("num_ghosts")){
						num_ghosts = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("num_pills")){
						num_pills = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("num_super")){
						num_super = new Integer(Integer.parseInt(tokens[1]));
					}	
					else if(tokens[0].equals("train_depth")){
						train_depth = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("num_junctions")){
						num_junctions = new Integer(Integer.parseInt(tokens[1]));
					}
					else if(tokens[0].equals("policy_path")){
						policy_path = tokens[1];
					}
					else if(tokens[0].equals("task_num"))
						task_num = new Integer(Integer.parseInt(tokens[1]));
					else{
						attribute_names.add(tokens[0]);
						attribute_types.add("numeric");
						values.add(new Double(Double.parseDouble(tokens[1])));
					}
				}
				else if(tokens.length == 1){
					if(tokens[0].equals("regular_pill"))
						features.add(DepthFeatureSet.REGULAR_PILL);
					else if(tokens[0].equals("power_pill"))
						features.add(DepthFeatureSet.POWER_PILL);
					else if(tokens[0].equals("regular_ghost"))
						features.add(DepthFeatureSet.REGULAR_GHOST);
					else if(tokens[0].equals("edible_ghost"))
						features.add(DepthFeatureSet.EDIBLE_GHOST);
					else if(tokens[0].equals("always_edible"))
						this.always_edible = true;
				}
			}
			
			BR.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void writePolicyPath(String filepath, String policypath){
		try {
		    Files.write(Paths.get(filepath), policypath.getBytes(), StandardOpenOption.APPEND);
		    this.addNumericalAttributesFromFile(filepath);
		}catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public String toString(){
		return "" + task_num;
	}
	
	public boolean equals(Object j){
		if(j instanceof Task ){
			if(((Task)j).task_num == this.task_num)
				return true;
		}
		
		return false;
	}
}
