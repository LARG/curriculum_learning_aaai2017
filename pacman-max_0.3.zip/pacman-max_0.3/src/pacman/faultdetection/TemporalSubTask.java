package pacman.faultdetection;

import java.util.Random;

public class TemporalSubTask {

	String game_state;
	int num_episodes;
	String tag;
	Random currentR;
	
	public TemporalSubTask(String s, int n, String t, Random r){
		game_state = s;
		num_episodes = n;
		tag=t;
		currentR=r;
	}
	
	public Random getRandomSeed(){
		return currentR;
	}
	
	public String getState(){
		return game_state;
	}
	
	public int getNumEpisodes(){
		return num_episodes;
	}
	
	public String getTag(){
		return tag;
	}
}
