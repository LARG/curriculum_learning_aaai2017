package pacman.faultdetection;

import java.util.ArrayList;
import java.util.Queue;
import java.util.Random;

public class EpisodeResult {

	//used always
	public int total_game_steps;
	
	//used when playing the full game
	public Queue<String> g_states; //game states array
	public Queue<Random> r_states; //game states array
	
	public boolean errorDetected;
	public String error_type;
	
	//used when playing a subtask
	public boolean pass_subtask; //did we succeed (i.e., do not make the fault detection go off) in the subtask
	
	
	public EpisodeResult(Queue<String> q, Queue<Random> r, boolean error, String e_type, int n){
		g_states = q;
		r_states = r;
		errorDetected = error;
		error_type = e_type;
		total_game_steps = n;
	}
	
	public EpisodeResult(boolean pass, int n){
		total_game_steps = n;
		pass_subtask=pass;
	}
}
