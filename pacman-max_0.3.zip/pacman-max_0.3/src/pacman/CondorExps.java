package pacman;

import pacman.game.Constants;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Random;
import java.util.StringTokenizer;


import pacman.entries.ghosts.*;
import pacman.entries.pacman.BasicRLPacMan;
import pacman.entries.pacman.CustomFeatureSet;
import pacman.entries.pacman.CustomFeatureSetV2;
import pacman.entries.pacman.DepthFeatureSet;
import pacman.entries.pacman.FeatureSet;
import pacman.entries.pacman.QPacMan;
import pacman.entries.pacman.RLPacMan;
import pacman.entries.pacman.SarsaPacMan;
import pacman.game.Game;
import pacman.game.GameView;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.teaching.AdviseAtFirst;
import pacman.teaching.AdviseImportantStates;
import pacman.teaching.CorrectImportantMistakes;
import pacman.teaching.PredictImportantMistakes;
import pacman.teaching.Student;
import pacman.teaching.TeachingStrategy;
import pacman.transferability.Task;
import pacman.transferability.TransferabilityMatrix;
import pacman.utils.DataFile;
import pacman.utils.EvaluationMetrics;
import pacman.utils.LearningCurve;
import pacman.utils.Stats;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;

public class CondorExps {
	
// Note on notation:
// custom refers to the CustomFeatureSet (using something else defaults to DepthFeatureSet)
// S refers to SarsaPacMan (using something else defaults to QPacMan)
	
	
/* 	4 options for RLPacMan learner type
 * 		- teacher: teacher RLPacMan loads policy
 * 		- independent: student starts from scratch
 * 		- transfer: student loads policy
 * 		- (baseline, advise, correct, predict): uses teacher+independent and a strategy for teacher 
 * 
 * 	Notes on folder names in mydata
 * 		- mydata/TEACHER/STUDENT/LEARNER-TYPE_MAZE-NUM/
 * 
 * 
 * 
 */	
	
	public static String TEACHER = "customS"; // Teacher feature set and algorithm
	public static String STUDENT = "customS"; // Student feature set and algorithm
	public static String dataDir = "/u/jsinapov/pacman_logs/";
	public static String pathSep = "/";
	public static String DIR = dataDir+TEACHER+pathSep+STUDENT; // Where to store data
	
	public static int BUDGET = 1000; // Advice budget
	public static int REPEATS = 5; //10; //30 // Curves to average
	public static int LENGTH = 500; // 10; // 100; // Points per curve
	public static int SAVE_POLICY_K = 25; //save policy every k train episodes
	public static int TRANSFER_POLICY_K = -1;
	public static int TEST = 1; //30; // Test episodes per point
	public static int TRAIN = 1; //10 // Train episodes per point

	public static Random rng = new Random();
	
	// Ghost "policies"
	public static StandardGhosts ghostsS = new StandardGhosts();
    public static RandomGhosts ghostsR = new RandomGhosts();
    public static ChaserGhosts ghostsC = new ChaserGhosts();
    public static LineGhosts ghostsL = new LineGhosts();
    
    public static int ghostType = 0;		// 0 = RandomGhosts, 1 = StandardGhosts, 2 = ChaserGhosts
    
    // Task parameters
    public static int mazeNum = 0;
    // Controls how fast ghosts move when pacman has eaten power pill. Lower numbers = slower (1 = frozen). 
    public static int ghostSlowdown = 2;
    public static int nGhosts = 4;
    
    public static int eatDistance;
    
    public static String sourceTask = "independent_1";
    
    public static Constants defaultConstants;
    
	/**
	 * Run experiments.
	 */
	public static void main(String[] args) {
		
		
		//generateTransferCondorScript();
		//generateBaselineCondorScript();
		//generateTransferCondorScript2();
		
		if (args[0].equals("--baseline"))
			baselineRun(args);
		else if (args[0].equals("--transfer"))
			transferRun(args);
		else if (args[0].equals("--transfercolumn"))
			transferColumnRun(args);
		else if (args[0].equals("--histogram"))
			histogram(Integer.parseInt(args[1]),Integer.parseInt(args[2]));
		else if (args[0].equals("--matrix"))
			matrix(Integer.parseInt(args[1]));
		else if (args[0].equals("--example")){
			//load transferability matrix
			ArrayList<String> task_names = getTaskNames();
			ArrayList<Task> tasks = getTasksData();
			TransferabilityMatrix M = new TransferabilityMatrix(getTaskNames());
			M.loadFromFile("TL_matrix_js_k30.txt");
			
			int target_task = Integer.parseInt(args[1]);
			
			//Task best_source = M.getBestSource(tasks, tasks.get(target_task));
			Task best_source = M.samplePositiveSource(tasks, tasks.get(target_task));
			int best_source_index = task_names.indexOf(best_source.getName());
			
			//Task worst_source = M.getWorstSource(tasks, tasks.get(target_task));
			Task worst_source = M.sampleNegativeSource(tasks, tasks.get(target_task));
			int worst_source_index = task_names.indexOf(worst_source.getName());
			
			
			System.out.println("Target task:\t"+tasks.get(target_task).getName());
			System.out.println("Best source:\t"+best_source.getName());
			System.out.println("Worst source:\t"+worst_source.getName());
			
			
			String target_baseline_path = DIR+"/baseline/"+task_names.get(target_task);
			LearningCurve baseline_curve = loadLearningCurve(new String(target_baseline_path+"/avg_curve"), 30);
		
			String transfer_path_best =  DIR+"/transfer_"+best_source_index+"_to_"+target_task;
			LearningCurve best_transfer_curve = loadLearningCurve(
					new String(transfer_path_best+"/avg_curve"), 
					30);
			
			String transfer_path_worst =  DIR+"/transfer_"+worst_source_index+"_to_"+target_task;
			LearningCurve worst_transfer_curve = loadLearningCurve(
					new String(transfer_path_worst+"/avg_curve"), 
					30);
			
			for (int i = 0; i < 30; i ++){
				System.out.println(baseline_curve.getScore(i)+","+best_transfer_curve.getScore(i)+","+worst_transfer_curve.getScore(i));
			}
		}
		
		
		
		
		/*ArrayList<String> tasks = getTasks();
		ArrayList<int[]> task_params = getTasksParams();
		
		for (int i = 0; i < tasks.size(); i ++){
			int [] params_i = task_params.get(i);
			
			System.out.println(i+","+tasks.get(i)+","+params_i[0]+","+params_i[1]+","+params_i[2]+","+params_i[3]);
		}*/
	}
	
	public static ArrayList<Task> getTasksData(){
		ArrayList<String> task_names = getTaskNames();
		ArrayList<int[]> task_params = getTasksParams();
		
		ArrayList<Task> tasks = new  ArrayList<Task>();
		 
		for (int i = 0 ; i < task_names.size(); i++){
			Task T_i = new Task(task_names.get(i));
			int [] params_i = task_params.get(i);
			
			//attributes related to dynamics
			T_i.addAttributeValue("ghost_type", new Double(params_i[1]), "nominal");
			T_i.addAttributeValue("ghost_slowdown", new Double(params_i[2]), "numeric");
			T_i.addAttributeValue("ghost_num", new Double(params_i[3]), "numeric");
			
			//attributes related to graph
			//String maze_filename = new String("/home/jsinapov/research/TL-RL/AAMAS2014_data/maze_"+params_i[0]+"_features.txt");
			//T_i.addNumericalAttributesFromFile(maze_filename);
		
			tasks.add(T_i);
		}
		
		return tasks;
		
	}
	
	public static ArrayList<String> getTaskNames(){
		ArrayList<String> source_task_names = new ArrayList<String>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
					}
				}
			}
		}
		
		return source_task_names;
	}
	
	public static void generateBaselineCondorScript(){
		String initial_dir = "/u/jsinapov/pacman_kondor/pacman";
		
		//header
		StringBuffer sb = new StringBuffer();
		
		sb.append("universe = vanilla\n\n");
		sb.append(new String("Initialdir = "+initial_dir+"\n"));
		sb.append("Executable = /usr/bin/java\n");
		sb.append("environment = CLASSPATH=target/classes\n");
		sb.append("Rank = Memory >= 6000\n\n");
		
		sb.append("+Group   = \"GRAD\"\n+Project = \"AI_ROBOTICS\"\n+ProjectDescription = \"Experiments in curriculum learning for reinforcement learning\"\n\n");

		sb.append("Log = condor/logs/experiment$(Process).log\n");
		sb.append("Output = condor/logs/experiment$(Process).out\n");
		sb.append("Error  = condor/logs/experiment$(Process).err\n\n");

		ArrayList<String> source_task_names = new ArrayList<String>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
						
						sb.append(new String("Arguments = pacman.CondorExps "+maze+" "+gtype+" "+slowdown+" "+num_g+"\n"));
						sb.append("Queue 1\n\n");
							
					
					}
				}
			}
		}
		
		//footer
		
		
		
		System.out.println(sb.toString());
		

	}
	
	public static void generateTransferCondorScript2(){
		ArrayList<String> tasks = getTasks();
		
		String initial_dir = "/u/jsinapov/pacman_kondor/pacman";
		
		//header
		StringBuffer sb = new StringBuffer();
		
		sb.append("universe = vanilla\n\n");
		sb.append(new String("Initialdir = "+initial_dir+"\n"));
		sb.append("Executable = /usr/bin/java\n");
		sb.append("environment = CLASSPATH=target/classes\n");
		sb.append("Rank = Memory >= 3000\n\n");
		
		sb.append("+Group   = \"GRAD\"\n+Project = \"AI_ROBOTICS\"\n+ProjectDescription = \"Experiments in curriculum learning for reinforcement learning\"\n\n");

		sb.append("Log = condor/logs_transfer/experiment$(Process).log\n");
		sb.append("Output = condor/logs_transfer/experiment$(Process).out\n");
		sb.append("Error  = condor/logs_transfer/experiment$(Process).err\n\n");
		
		for (int target_j = 0; target_j < tasks.size(); target_j++){
			sb.append(new String("Arguments = pacman.CondorExps --transfercolumn "+target_j+"\n"));
			sb.append("Queue 1\n\n");
		}
		
		System.out.println(sb.toString());
	
	}
	
	public static void generateTransferCondorScript(){
		ArrayList<String> tasks = getTasks();
		
		String initial_dir = "/u/jsinapov/pacman_kondor/pacman";
		
		//header
		StringBuffer sb = new StringBuffer();
		
		sb.append("universe = vanilla\n\n");
		sb.append(new String("Initialdir = "+initial_dir+"\n"));
		sb.append("Executable = /usr/bin/java\n");
		sb.append("environment = CLASSPATH=target/classes\n");
		sb.append("Rank = Memory >= 3000\n\n");
		
		sb.append("+Group   = \"GRAD\"\n+Project = \"AI_ROBOTICS\"\n+ProjectDescription = \"Experiments in curriculum learning for reinforcement learning\"\n\n");

		sb.append("Log = condor/logs_transfer/experiment$(Process).log\n");
		sb.append("Output = condor/logs_transfer/experiment$(Process).out\n");
		sb.append("Error  = condor/logs_transfer/experiment$(Process).err\n\n");
		
		int total_counter = 0;
	
		int k = 20; //we will do 1/20 th of all pairs
		
		int p = 2;//p can be between 0 and 19 inclusive
		
		
		for (int source_i = 0; source_i < tasks.size(); source_i++){
			for (int target_j = 0; target_j < tasks.size(); target_j++){
				if (source_i != target_j){
					if (total_counter % k == p){
			
						sb.append(new String("Arguments = pacman.CondorExps --transfer "+source_i+" "+target_j+"\n"));
						sb.append("Queue 1\n\n");
					}
					
					
					
					total_counter++;
				}
			}
		}
		
		System.out.println(sb.toString());
	}
	
	public static ArrayList<int[]> getTasksParams(){
		ArrayList<int[]> source_task_params = new ArrayList<int[]>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						int [] params = new int[4];
						params[0] = maze;
						params[1] = gtype;
						params[2] = slowdown;
						params[3] = num_g;
						
						
						
						source_task_params.add(params);
					}
				}
			}
		}
		
		return source_task_params;
	}

	public static LearningCurve loadLearningCurve(String filename, int num_episodes){
		
		return new LearningCurve(num_episodes, 0, filename);
		
		/*ArrayList<double[]> curve_data = new ArrayList<double[]>();
		
		try {
			BufferedReader BR = new BufferedReader(new FileReader(new File(filename)));
			
			while (true){
				String next_line = BR.readLine();
				if (next_line == null)
					break;
				
				StringTokenizer st = new StringTokenizer(next_line);
				double [] data_i = new double[n];
				for (int j = 0; j < n; j ++){
					data_i[j]=Double.parseDouble(st.nextToken());
				}
				
				curve_data.add(data_i);
				
				
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		double [][] result = new double[curve_data.size()]
		
		//return curve_data;*/
	}
	
	public static Instances generateHeaderData(){
		
		FastVector attrInfo = new FastVector();
		
		
		//attribute 1 is from maze to maze
		FastVector attr1_values = new FastVector();
		for (int i = 0; i < 4; i ++){
			for (int j = 0; j < 4; j ++){
				if (i!=j)
					attr1_values.add(new String("maze"+i+"_to_maze"+j));
			}
		}
		Attribute a1 = new Attribute("maze_attr",attr1_values);
		
		//atribute 2 is for ghost type
		FastVector attr2_values = new FastVector();
		for (int gtype = 0; gtype < 3; gtype++){
			for (int gtype2 = 0; gtype2 < 3; gtype2++){
				attr2_values.add(new String("gtype"+gtype+"_to_gtype"+gtype2));
			}
		}
		Attribute a2 = new Attribute("gtype_attr",attr2_values);
		
		//attribute 3 is slowdown and is numeric
		Attribute a3 = new Attribute("slowdown_attr");
		
		//attribute 4 is num ghosts, also numeric
		Attribute a4 = new Attribute("nghosts_attr");
		
		//class atrribute is numeric
		Attribute class_attr = new Attribute("class");
		
		attrInfo.add(a1);
		attrInfo.add(a2);
		attrInfo.add(a3);
		attrInfo.add(a4);
		attrInfo.add(class_attr);
		
		Instances header = new Instances("data",attrInfo,0);
		
		return header;
	}
	
	public static void computeArffData(){
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> task_params = getTasksParams();
		
		int num_repeats = 10;
		int baseline_episodes = 2500;
		int target_episodes = 30;
		int jump_start_k = 10;
		
		//where to store the data
		Instances data = generateHeaderData();
		
		//load transferability matrix columns
		for (int target_task = 0; target_task < tasks.size(); target_task ++){
			for (int source_task = 0; source_task < tasks.size(); source_task ++){
				
				
			}
		}
	}
	
	
	public static void regression(int jump_start_k){
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> task_params = getTasksParams();
	
		//load matrix
	}
	
	public static void matrix(int jump_start_k){
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> task_params = getTasksParams();
	
		
		//the entry at [i][j] contains the metric for transfering
		//from task j to task i
		double [][] matrix_js = new double[tasks.size()][tasks.size()];
		
		
		double [][] matrix_js_ratio = new  double[tasks.size()][tasks.size()];
		
		for (int j = 0; j < tasks.size(); j ++){
			double [][] column_j = histogram(j,jump_start_k);
			
			for (int i = 0; i < tasks.size(); i ++){
				matrix_js[j][i]=column_j[i][0];
				matrix_js_ratio[j][i]=column_j[i][1];
			}
		}
		
		saveMatrixToFile(matrix_js,new String("TL_matrix_js_k"+jump_start_k+".txt"));
		saveMatrixToFile(matrix_js_ratio,new String("TL_matrix_js_ratio_k"+jump_start_k+".txt"));
		
	}
	
	public static void loadMatrixFromFile(String filename) {
		ArrayList<double[]> rows = new ArrayList<double[]>();
		
		int n_rows=0; 
		int n_columns;
		
		try {
			BufferedReader BR = new BufferedReader(new FileReader(new File(filename)));
			
			String nextLine;
			while (true){
				nextLine = BR.readLine();
				if (nextLine == null)
					break;
				
				String [] tokens = nextLine.split(",");
				double [] row_i = new double[tokens.length];
				for (int i = 0; i < row_i.length; i ++)
					row_i[i]=Double.parseDouble(tokens[i]);
				
				rows.add(row_i);
				
				n_rows++;
				n_columns = row_i.length;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void saveMatrixToFile(double [][] M, String filename){
		try {
			FileWriter FW = new FileWriter(new File(filename));
			
			for (int j = 0; j < M.length; j ++){
				for (int i = 0; i < M[j].length; i ++){
					FW.write(new String(""+M[j][i]));
					if ( i < M[j].length-1)
						FW.write(",");
					else FW.write("\n");
				}
			}
			
			FW.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static double [][] histogram(int target_task, int jump_start_k){
		
		
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> task_params = getTasksParams();
		
		double [][] result = new double[tasks.size()][2];
		
		
		int num_repeats = 10;
		int baseline_episodes = 2500;
		int target_episodes = 30;

		//Step 1: pick a target task and produce a histogram of transferability
	
		//System.out.println("Target task: "+tasks.get(target_task));
		
		
		String target_path = DIR+"/baseline/"+tasks.get(target_task);
		LearningCurve [] target_baselines = new LearningCurve[num_repeats];
		for (int i = 0; i < target_baselines.length; i++){
			String curve_i = new String(target_path+"/curve"+i);
			target_baselines[i] = loadLearningCurve(curve_i, baseline_episodes);
		}
		
		//System.out.println("Loaded baseline curves");
		
		ArrayList<Double> jumpstarts = new ArrayList<Double>();
		for (int j = 0; j < tasks.size(); j ++){
			
			if (j != target_task){
				
				
				
				String transfer_path_j =  DIR+"/transfer_"+j+"_to_"+target_task;
				
				LearningCurve [] target_transfers_j = new LearningCurve[num_repeats];
				
				//check if transfer has completed
				String final_curve = new String(transfer_path_j+"/curve"+(num_repeats-1));
				File F = new File(final_curve);
				if (F.exists()){
				
					for (int i = 0; i < target_transfers_j.length; i++){
						String curve_i = new String(transfer_path_j+"/curve"+i);
						target_transfers_j[i] = loadLearningCurve(curve_i, target_episodes);
					}
					
					//compute average jump start
					double avg_jumpstart_ratio_j = 0;
					int counter_ratio = 0;
					
					double avg_jumpstart_j = 0;
					
					for (int p = 0; p < num_repeats; p ++){
						for (int q = 0; q < num_repeats; q++){
							
							double reward_baseline = EvaluationMetrics.getAvgReward(target_baselines[p].getScoreArray(), 0, jump_start_k);
							double reward_transfer = EvaluationMetrics.getAvgReward(target_transfers_j[q].getScoreArray(), 0, jump_start_k);
							
							
							double js_pq = EvaluationMetrics.jumpStartRatioK(target_baselines[p].getScoreArray(), 
																				target_transfers_j[q].getScoreArray(), 
																				jump_start_k);
						
							double js_raw_pq = EvaluationMetrics.jumpStartK(target_baselines[p].getScoreArray(), 
																				target_transfers_j[q].getScoreArray(), 
																				jump_start_k);
							
							
							
							if (!Double.isInfinite(js_pq)){
								avg_jumpstart_ratio_j += js_pq;
								avg_jumpstart_j+=js_raw_pq;
								//System.out.println(j+","+reward_baseline+","+reward_transfer+","+js_raw_pq+","+js_pq);
								counter_ratio ++;
							}
							else if (Double.isInfinite(js_pq) && !Double.isNaN(js_raw_pq)){
								avg_jumpstart_j+=js_raw_pq;
								counter_ratio ++;
							}
						}
					}
					avg_jumpstart_ratio_j = avg_jumpstart_ratio_j / (counter_ratio);
					avg_jumpstart_j = avg_jumpstart_j / (counter_ratio);
					
					
					result[j][0]=avg_jumpstart_j;
					result[j][1]=avg_jumpstart_ratio_j;
					
					
					System.out.println(avg_jumpstart_j+","+avg_jumpstart_ratio_j);
					
					jumpstarts.add(new Double(avg_jumpstart_ratio_j));
				}
				else {
					result[j][0]=0;
					result[j][1]=1;
				}
			
			}
			else {
				result[j][0]=0;
				result[j][1]=1;
			}
		}
		
		return result;
		
		//System.out.println(jumpstarts);
	}
	
	public static ArrayList<String> getTasks(){
		ArrayList<String> source_task_names = new ArrayList<String>();
		
		//all taks
		int c = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
					}
				}
			}
		}
		
		return source_task_names;
	}
	
	
	public static void transferColumnRun(String [] args){
		int target_j = Integer.parseInt(args[1]);
		
		
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> params = getTasksParams();
		
		int [] params_j = params.get(target_j);
		
		//training params
		LENGTH = 30; //how many train episodes
				
		REPEATS = 10; 
		SAVE_POLICY_K = 5;
		TEST = 10;
		
		//for each source
		for (int i = 0; i < tasks.size(); i ++){
			if (i != target_j){
				
				
				defaultConstants = new Constants();
				sourceTask = new String("baseline/"+tasks.get(i));
				
				String source_path = new String(DIR +"/" + sourceTask +"/policy"+(REPEATS-1));
				
				File F = new File(source_path);
				if (F.exists()){
					defaultConstants.MAZE_NUM = params_j[0]; //which maze;
					defaultConstants.GHOST_TYPE = params_j[1]; //which of three types of ghosts
					defaultConstants.GHOST_SPEED_REDUCTION = params_j[2]; //ghost speed
					defaultConstants.NUM_GHOSTS = params_j[3]; //how many ghosts

					String transfer_learner = new String("transfer_"+i+"_to_"+target_j);
					train(transfer_learner, 0,false);
				}
			}
		}
	}
	
	public static void transferRun(String [] args){
		int source_i = Integer.parseInt(args[1]);
		int target_j = Integer.parseInt(args[2]);
		
		
		ArrayList<String> tasks = getTasks();
		ArrayList<int[]> params = getTasksParams();
		
		//training params
		LENGTH = 300; //how many train episodes
		
		REPEATS = 10; 
		SAVE_POLICY_K = 1;
		TEST = 10;
		
		defaultConstants = new Constants();
		
		sourceTask = new String(""+tasks.get(source_i));
		int [] target_params = params.get(target_j);
		
		//check if source actually exists
		String source_path = new String(DIR +"/" + sourceTask +"/policy"+(REPEATS-1));
		File F = new File(source_path);
		if (!F.exists())
			return;
	

		defaultConstants.MAZE_NUM = target_params[0]; //which maze;
		defaultConstants.GHOST_TYPE = target_params[1]; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = target_params[2]; //ghost speed
		defaultConstants.NUM_GHOSTS = target_params[3]; //how many ghosts

		String transfer_learner = new String("transfer_"+source_i+"_to_"+target_j);
		train(transfer_learner, 0,false);
	}
	
	public static void baselineRun(String [] args){
		//train params
		LENGTH = 2500; //how many train episodes
		REPEATS = 10; 
		SAVE_POLICY_K = 1;
		TEST = 10;
		
		//parse constants from args
		defaultConstants = new Constants();
		
		mazeNum = Integer.parseInt(args[0]);
		ghostType = Integer.parseInt(args[1]);
		ghostSlowdown = Integer.parseInt(args[2]);
		nGhosts = Integer.parseInt(args[3]);
		
		defaultConstants.MAZE_NUM = mazeNum; //which maze;
		defaultConstants.GHOST_TYPE = ghostType; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = ghostSlowdown; //ghost speed
		defaultConstants.NUM_GHOSTS = nGhosts; //how many ghosts
		
		train("independent", 0,false);
	}
	
	public static void demo(){
		defaultConstants = new Constants();
		
		//train params
		LENGTH = 1500; //how many train episodes
		REPEATS = 1; 
		SAVE_POLICY_K = 1;
		TEST = 10;
				
		mazeNum = 0; //which maze;
		ghostType = 1; //which of three types of ghosts
		ghostSlowdown = 2; //ghost speed
		nGhosts = 4; //how many ghosts
		
		defaultConstants.MAZE_NUM = mazeNum; //which maze;
		defaultConstants.GHOST_TYPE = ghostType; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = ghostSlowdown; //ghost speed
		defaultConstants.NUM_GHOSTS = nGhosts; //how many ghosts
		//defaultConstants.nodeNames[4]="mymaze";
		//defaultConstants.distNames[4]="dmymaze";
	
		
				
		//train
		String demo_name = "independent_test_e10";
		train(demo_name, 0, false);
				
		//transfer and watch
		sourceTask = generateDirectoryName(demo_name,
					mazeNum,ghostType,ghostSlowdown,nGhosts);
			
		//load transfer
				
				
		//test params
		mazeNum = 0; //which maze;
		ghostType = 3; //which of three types of ghosts
		ghostSlowdown = 2; //ghost speed
		nGhosts = 4; //how many ghosts
		
		defaultConstants.MAZE_NUM = mazeNum; //which maze;
		defaultConstants.GHOST_TYPE = ghostType; //which of three types of ghosts
		defaultConstants.GHOST_SPEED_REDUCTION = ghostSlowdown; //ghost speed
		defaultConstants.NUM_GHOSTS = nGhosts; //how many ghosts
		/*
		if (ghostType == 3){
			defaultConstants
		}*/
		
		TRANSFER_POLICY_K = -1; //at what point to transfer (-1 means at the end of the source task)
				
		/*RLPacMan pacman = create("transfer_demo", 0);		
		((SarsaPacMan)pacman).debug=true;
		watch(pacman,false);*/
	}
	
	
	public static void computeTransferEX1(){
		//training params
		LENGTH = 300; //how many train episodes
								
		//experiment params
		REPEATS = 5; 
		SAVE_POLICY_K = 1; 
			
		ArrayList<String> source_tasks_lines = new ArrayList<String>();
		
		ArrayList<String> source_task_names = new ArrayList<String>();
		
		
		//Step 1: generate an index of source tasks
		DataFile task_index_file = new DataFile(new String(DIR+"/task_index.csv"));
		task_index_file.clear();
		task_index_file.append(new String("task_number,directory_name,maze_index,ghost_type,ghost_slowdown,num_ghosts\n"));
		int task_counter = 0;
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 9; slowdown+=2){
					for (int num_g = 1; num_g < 5; num_g++){
						
						String source_task_dir = generateDirectoryName("independent",
								maze,gtype,slowdown,num_g);
						source_task_names.add(source_task_dir);
						
						String csv_line = new String(task_counter+","+source_task_dir+","+
								maze+","+gtype+","+slowdown+","+num_g);
						
						task_index_file.append(csv_line);
						task_index_file.append("\n");
						source_tasks_lines.add(csv_line);
						task_counter++;
					}
				}
			}
		}
		
		task_index_file.close();
		
		//Step 2: randomly pick pairs of tasks, load feature weights from source task and learn on target task
		int pairs_to_sample = 600;
		
		Random R = new Random(1);
		for (int pair = 0; pair < pairs_to_sample; pair++){
			int source_i = R.nextInt(task_counter);
			int target_j = R.nextInt(task_counter);
			
			sourceTask = new String("baseline/"+source_task_names.get(source_i));
			
			String target_task_line = source_tasks_lines.get(target_j);
			String [] tokens = target_task_line.split(",");
	
			defaultConstants.MAZE_NUM = Integer.parseInt(tokens[2]); //which maze;
			defaultConstants.GHOST_TYPE = Integer.parseInt(tokens[3]); //which of three types of ghosts
			defaultConstants.GHOST_SPEED_REDUCTION = Integer.parseInt(tokens[4]); //ghost speed
			defaultConstants.NUM_GHOSTS = Integer.parseInt(tokens[5]); //how many ghosts

		
			String transfer_learner = new String("transfer_"+source_i+"_to_"+target_j);
			train(transfer_learner, 0,false);
		}			
	}
	
	public static void computeBaselineEX1(){
		//training params
		LENGTH = 1500; //how many train episodes
						
		//experiment params
		REPEATS = 10; //10; //30 // Curves to average
		SAVE_POLICY_K = 1; //save policy every k train episodes		
	
		//Step 1: generate baseline curves for all possible tasks
		for (int maze = 0; maze < 4; maze++){
			for (int gtype = 0; gtype < 3; gtype++){
				for (int slowdown = 1; slowdown <= 4; slowdown+=1){
					for (int num_g = 1; num_g < 5; num_g++){
						System.out.println(maze+"\t"+gtype+"\t"+slowdown+"\t"+num_g);
						
						mazeNum = maze; //which maze;
						ghostType = gtype; //which of three types of ghosts
						ghostSlowdown = slowdown; //ghost speed
						nGhosts = num_g; //how many ghosts
						
						defaultConstants = new Constants();
						defaultConstants.MAZE_NUM = maze; //which maze;
						defaultConstants.GHOST_TYPE = gtype; //which of three types of ghosts
						defaultConstants.GHOST_SPEED_REDUCTION = slowdown; //ghost speed
						defaultConstants.NUM_GHOSTS = num_g; //how many ghosts

						train("independent", 0,false);
					}
				}
			}
		}
		
		//Step 2:
		//manually move all the folders that are generated into a "baseline" folder
	}
	
	
	public static String generateDirectoryName(String learner, 
						int mazeNum_i, int ghostType_i, 
						int ghostSlowdown_i, int nGhosts){
		
		if (learner.startsWith("independent")) {
			return new String(learner+"_maze"+mazeNum_i+"_type"+ghostType_i+"_slow"+ghostSlowdown_i+"_ghosts"+nGhosts+"");
		}
		else if (learner.startsWith("transfer")) { 
			return learner; //this should be something like "transfer_5_to_7"
		}
		else
			return "WTF";
	}

	/** Set up a learner. */
	public static RLPacMan create(String learner, int runNum) {
		
		FeatureSet teacherProto = TEACHER.startsWith("custom") ? new CustomFeatureSet() : new DepthFeatureSet();
		FeatureSet studentProto = STUDENT.startsWith("custom") ? new CustomFeatureSet() : new DepthFeatureSet();

		// Lone teacher
		if (learner.startsWith("teacher")) {
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy(dataDir+TEACHER+"/teacher/policy");
			return teacher;
		}
			
		// Lone student
		else if (learner.startsWith("independent")) {
			return STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
		}
		
		// TL: lead policy into student and let it run from there
		else if (learner.startsWith("transfer")) {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			if (TRANSFER_POLICY_K == -1)
				student.loadPolicy(DIR +"/" + sourceTask + "/policy" + runNum);
			else 
				student.loadPolicy(DIR +"/" + sourceTask + "/policy" + runNum+"_train"+TRANSFER_POLICY_K);
			return student;
		}
		
		// Student-teacher pair
		else {
			BasicRLPacMan student = STUDENT.endsWith("S") ? new SarsaPacMan(studentProto) : new QPacMan(studentProto);
			BasicRLPacMan teacher = TEACHER.endsWith("S") ? new SarsaPacMan(teacherProto) : new QPacMan(teacherProto);
			teacher.loadPolicy(dataDir+TEACHER+"/teacher/policy");
			
			// Front-load the advice budget
			if (learner.startsWith("baseline")) {
				TeachingStrategy strategy = new AdviseAtFirst();
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states
			if (learner.startsWith("advise")) {
				int threshold = Integer.parseInt(learner.substring(6));
				TeachingStrategy strategy = new AdviseImportantStates(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Correct important mistakes
			if (learner.startsWith("correct")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new CorrectImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
			
			// Advise in important states with predicted mistakes
			if (learner.startsWith("predict")) {
				int threshold = Integer.parseInt(learner.substring(7));
				TeachingStrategy strategy = new PredictImportantMistakes(threshold);
				return new Student(teacher, student, strategy);
			}
		}
		
		return null;
	}
	
	/** Generate learning curves. */
	public static void train(String learner, int start, boolean watchAtEnd) {
		
		String directory = generateDirectoryName(learner,mazeNum,ghostType,ghostSlowdown,nGhosts);
		
		
		System.out.println("Training directory: "+directory);
		
		/*String directory = learner + "_" + mazeNum;
		
		
		// TODO: Hacks
		if (nGhosts < 4){
			directory += ("_" + nGhosts);
		}*/
		
		//directory = "transfer_1_3";
		
		// Make sure directory exists
		File file = new File(DIR+pathSep+directory);
		if (!file.exists()){
			file.mkdir();
			//System.out.println("Creating directory "+file.toString());
		}
		//else System.out.println("Directory " +file.toString() + " already created.");
		
		
		// Load old curves
// Currently we are passing in 0, so this part will be skipped. Otherwise, the next part would be skipped. 
		LearningCurve[] curves = new LearningCurve[REPEATS];
		for (int i=0; i<start; i++)
			curves[i] = new LearningCurve(LENGTH+1, TRAIN, DIR+pathSep+directory+"/curve"+i);
		
		// Begin new curves
		for (int i=start; i<REPEATS; i++) {
			System.out.print("\tr"+i+"\n");
			if (i == REPEATS-1)
				System.out.println();
			
			
			curves[i] = new LearningCurve(LENGTH+1, TRAIN);
			
			//System.out.println("Training "+DIR+pathSep+directory+" for repeat "+i+"...");
// This just sets up the student or teacher with the specified feature set and learning algorithm
			RLPacMan pacman = create(learner, i);
			
			// First point
			double[] initialData = pacman.episodeData();		// Starts off empty
			
			double [] eval_result =evaluate(pacman, TEST);
			double initialScore = eval_result[0];		// This returns the average score over TEST number of games
			double initialTime = eval_result[1];		// This returns the average score over TEST number of games
			
			
			curves[i].set(0, initialScore, initialData, initialTime);
						
			//make a directory where to save the policies after each episode
			String repeat_path = new String(DIR+pathSep+directory+pathSep+"repeat"+i);
			File repeat_folder = new File(repeat_path);
			if (!repeat_folder.exists()){
				repeat_folder.mkdir();
			}
			
			// Rest of the points
			int num_train_episodes = 0;
			for (int x=1; x<=LENGTH; x++) {
				double[] data = new double[initialData.length];
				
				

			
				
				for (int y=0; y<TRAIN; y++) {
					episode(pacman);	// Does the same thing as evaluate, but doesn't return score
					num_train_episodes++;
					
					
					double[] episodeData = pacman.episodeData();
					for (int d=0; d<data.length; d++)
						data[d] += episodeData[d];
				}
				
				if (x % SAVE_POLICY_K == 0)
					pacman.savePolicy(repeat_path+pathSep+"policy"+i+"_train"+x);
				
				
				double [] eval_result2 =evaluate(pacman, TEST) ;
				double score = eval_result2[0];		// This returns the average score over TEST number of games
				double time = eval_result2[1];		// This returns the average score over TEST number of games
		
				curves[i].set(x, score, data, time);
				
				System.out.print("e"+num_train_episodes+":"+score+" ");
				if (x % 30 == 0)
					System.out.println();
				
				//((SarsaPacMan)pacman).debug=true;
				//watch(pacman,true);
				//((SarsaPacMan)pacman).debug=false;
			}
			//System.out.println("\nTraining finished, saving policies and curves...");
			
			
			// Save new curve and policy
			pacman.savePolicy(DIR+"/"+directory+"/policy"+i);
			curves[i].save(DIR+"/"+directory+"/curve"+i);
			
			// Average all curves
			LearningCurve avgCurve = new LearningCurve(Arrays.copyOf(curves, i+1));
			avgCurve.save(DIR+"/"+directory+"/avg_curve");
			
			// Variance curve
			LearningCurve stdCurve = LearningCurve.getScoreVarianceCurve(Arrays.copyOf(curves, i+1), true);
			stdCurve.save(DIR+"/"+directory+"/stdev_curve");
			
			if (i == REPEATS -1 && watchAtEnd)
				watch(pacman, false);
		}
		
		System.out.println("Done.");
	}
 
	/** Train a learner for one more episode. */
// Basically does the same thing as evaluate but doesn't return the score	
	public static void episode(RLPacMan pacman) {

		Game game = new Game(rng.nextLong(), defaultConstants);
		pacman.startEpisode(game, false);

		while(!game.gameOver()) {
			if (ghostType == 0)
				game.advanceGame(pacman.getMove(game.copy(), -1), ghostsR.getMove(game.copy(), -1));
			else if (ghostType == 1)
				game.advanceGame(pacman.getMove(game.copy(), -1), ghostsS.getMove(game.copy(), -1));
			else if (ghostType == 2)
				game.advanceGame(pacman.getMove(game.copy(), -1), ghostsC.getMove(game.copy(), -1));
			else {
				System.err.println("INVALID GHOST TYPE");
				System.exit(1);
			}
				
			pacman.processStep(game);
		}
	}

	/** Estimate the current performance of a learner. */
// Width is the number of episodes to test for (i.e. variable TEST above)	
	public static double[] evaluate(RLPacMan pacman, int width) {
		
		double[] scoreAndTime = new double[2];		
		double sumScore = 0;
		double sumSteps = 0;
		
// For each test episode		
		for(int i=0; i<width; i++) {
// Create and start a new game			
			Game game = new Game(rng.nextLong(), defaultConstants);
			pacman.startEpisode(game, true);
			while(!game.gameOver()) {
// getMove in pacman learner returns the lastAction	
// This will then recompute the next move to make.
				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));			
				pacman.processStep(game);
			}
			
			sumScore += game.getScore();
			sumSteps += game.getTotalTime();
			//System.out.println("time taken: " + game.getTotalTime());
		}

		scoreAndTime[0] = sumScore/width;
		scoreAndTime[1] = sumSteps/width;
		
		
		return scoreAndTime;
	}

	/** Observe a learner play a game. */
	public static void watch(RLPacMan pacman, boolean destroyWindow) {
		
		Game game=new Game(rng.nextLong(), defaultConstants);
		pacman.startEpisode(game, true);
		GameView gv=new GameView(game).showGame();

		while(!game.gameOver()) {
			
			game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
			pacman.processStep(game);
			
			try{Thread.sleep(defaultConstants.DELAY);}catch(Exception e){}
			gv.repaint();
		}
		
		if (destroyWindow){
			gv.setVisible(false);
			gv.setEnabled(false);
			gv.getFrame().dispose();
		}
	}
		
	
	/** Select a teacher from the independent students. */
	public static void findBestTeacher() {
		
		double[] scores = new double[REPEATS];
		
		for (int i=0; i<REPEATS; i++) {
			BasicRLPacMan pacman = (BasicRLPacMan)create("independent",-1);
			pacman.loadPolicy(DIR+"/independent/policy"+i);
			scores[i] = evaluate(pacman, 500)[0];
			System.out.println(DIR+"/independent/policy"+i+": "+scores[i]);
		}
		
		int bestPolicy = 0;
		for (int i=0; i<REPEATS; i++)
			if (scores[i] > scores[bestPolicy])
				bestPolicy = i;
		
		System.out.println("Best: "+DIR+"/independent/policy"+bestPolicy);
	}
	
	/** Make a plottable file of Q-value gaps over a few episodes. */
	public static void plotGaps() {

		DataFile file = new DataFile(dataDir+TEACHER+"/teacher/gaps");
		file.clear();

		BasicRLPacMan pacman = (BasicRLPacMan)create("teacher", -1);
		int x = 0;

		for (int i=0; i<1; i++) {
			Game game = new Game(rng.nextLong());
			pacman.startEpisode(game, true);

			while(!game.gameOver()) {

				double[] qvalues = pacman.getQValues();
				Arrays.sort(qvalues);
				double gap = qvalues[qvalues.length-1] - qvalues[0];

				file.append(x+"\t"+gap+"\n");
				x++;

				/*if (ghostType == 0)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsR.getMove(game.copy(), -1));
				else if (ghostType == 1)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsS.getMove(game.copy(), -1));
				else if (ghostType == 2)
					game.advanceGame(pacman.getMove(game.copy(), -1), ghostsC.getMove(game.copy(), -1));
				else {
					System.err.println("INVALID GHOST TYPE");
					System.exit(1);
				}*/
				
				game.advanceGame(pacman.getMove(game.copy(), -1), getGhostMove(game, game.constants.GHOST_TYPE));	
				
				
				
				pacman.processStep(game);
			}
		}

		file.close();
	}
	
	/** Test SVM choice prediction. */
	public static void testSVM() {
			
		BasicRLPacMan student = (BasicRLPacMan)create("independent", -1);
		BasicRLPacMan teacher = (BasicRLPacMan)create("teacher", -1);
		PredictImportantMistakes strategy = new PredictImportantMistakes(0);
		
		for (int i=0; i<300; i++) {
			Game game = new Game(rng.nextLong());
			student.startEpisode(game, false);
			teacher.startEpisode(game, true);
			
			strategy.startEpisode();
			int right = 0, wrong = 0, truePos = 0, falseNeg = 0, falsePos = 0;
			
			while(!game.gameOver()) {
				MOVE advice = teacher.getMove(game, -1);
				MOVE choice = student.getMove(game, -1);
				strategy.recordExample(teacher, choice);
				
				if (i > 0) {
					MOVE guess = strategy.predictChoice(teacher);
					boolean predict = (guess != advice);
					boolean mistake = (choice != advice);
					
					if (guess == choice)
						right++;
					else
						wrong++;
					
					if (mistake && predict)
						truePos++;
					else if (mistake && !predict)
						falseNeg++;
					else if (!mistake && predict)
						falsePos++;
				}
				
				if (ghostType == 0)
					game.advanceGame(choice, ghostsR.getMove(game.copy(), -1));
				else if (ghostType == 1)
					game.advanceGame(choice, ghostsS.getMove(game.copy(), -1));
				else if (ghostType == 2)
					game.advanceGame(choice, ghostsC.getMove(game.copy(), -1));
				else {
					System.err.println("INVALID GHOST TYPE");
					System.exit(1);
				}
				student.processStep(game);
				teacher.processStep(game);
			}
			
			if (i > 0) {
				double accuracy = right/(double)(right+wrong);
				double precision = truePos/(double)(truePos+falsePos);
				double recall = truePos/(double)(truePos+falseNeg);
				
				DecimalFormat f = new DecimalFormat("#.##");
				System.out.println("During episode "+i+": a="+f.format(accuracy)+", p="+f.format(precision)+", r="+f.format(recall));
			}
		}
	}
	
	/** Compare areas under two types of learning curves. */
	public static void compare(String dir1, String dir2) {
		
		LearningCurve[] curves1 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves1[i] = new LearningCurve(LENGTH+1, TRAIN, dataDir+dir1+"/curve"+i);
		
		double[] areas1 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas1[i] = curves1[i].area();
		
		LearningCurve[] curves2 = new LearningCurve[REPEATS];
		for (int i=0; i<REPEATS; i++)
			curves2[i] = new LearningCurve(LENGTH+1, TRAIN, dataDir+dir2+"/curve"+i);
		
		double[] areas2 = new double[REPEATS];
		for (int i=0; i<REPEATS; i++)
			areas2[i] = curves2[i].area();
		
		double t0 = Stats.t(areas1, areas2);
		double dof = Stats.dof(areas1, areas2);
		System.out.println(dir1+" > "+dir2+" with 95% confidence if:");
		System.out.println(t0+" > t_0.05_"+dof);
	}
	
	private static EnumMap<GHOST, MOVE> getGhostMove(Game game, int ghostType){
		
		switch(ghostType){
			case 0:
				return ghostsR.getMove(game.copy(), -1);
			case 1:
				return ghostsS.getMove(game.copy(), -1);
			case 2:
				return ghostsC.getMove(game.copy(), -1);
			case 3:
				return ghostsL.getMove(game.copy(), -1);
			default:
				System.err.println("INVALID GHOST TYPE");
				System.exit(1);
				return null;				// Compilier is complaining... 
		}
	}
}