package pacman.entries.pacman;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * An extended QFunction that uses previously learned QFunctions as  
 * advice when evaluating the current scene
 */
public class ShapedQFunction extends QFunction{
	protected ArrayList<QFunction> 		potential; //holds previously learned QFunctions
	protected ArrayList<Integer[]> 		shape_features;	//holds the indicies of the features learned in a given QFunction
	protected Integer[]					feat_depth;		//holds the depth of any given feature under the given featureSet
	/** Initialize with prototype (through parent) **/
	public ShapedQFunction(FeatureSet prototype) {
		super(prototype);
	}

	/** Load initial settings from a file. */
	public ShapedQFunction(FeatureSet prototype, String filename){
		super(prototype, filename);
	}
	
	/** Use many learned QFunctions **/
	public ShapedQFunction(FeatureSet prototype, QFunction[] pot, Integer[][] features, Integer[] feat_depth){
		super(prototype);
		System.out.println("MAKING SHAPED Q. LENGTH OF WEIGHTS " + prototype.depth());
		this.potential = new ArrayList<QFunction>(Arrays.asList(pot));
		this.shape_features = new ArrayList<Integer[]>(Arrays.asList(features));
		this.feat_depth = feat_depth;
	}
	
	/** Use a learned QFunctions **/
	public ShapedQFunction(FeatureSet prototype, ArrayList<QFunction> pot){
		super(prototype);
		potential = new ArrayList<QFunction>(pot);
	}
	
	
	/** Estimate the Q-value given the features for an action. */
	public double evaluate_shape(FeatureSet features) {
		double sum = bias;
		boolean pills = false;
		if(features instanceof DepthFeatureSet){
			int depth = features.depth();
			double[] cumulativeWeights = new double[weights.length];
			//System.out.println("Weights length: " + weights.length);
			for(int j = 0; j < potential.size(); j++)
				for(int d = 0; d < shape_features.get(j).length; d++){
					pills = false;
					int feature_depth = 0;
					if(feat_depth[j] < depth)
						feature_depth = feat_depth[j];
					else
						feature_depth = depth;
					for(int k = 0; k < feature_depth; k++){
						cumulativeWeights[(depth * shape_features.get(j)[d]+k)] += potential.get(j).weights[(feat_depth[j] * shape_features.get(j)[d]+k)];
						//System.out.println(potential.get(j).weights[(feat_depth[j] * shape_features.get(j)[d]+k)] + "");
					}
					if(shape_features.get(j)[d] == 0) //0 -> inclusion of the REGULAR_PILL feature
						cumulativeWeights[weights.length -1] += potential.get(j).weights[potential.get(j).weights.length - 1];
				}
			//System.out.println("FULL WEIGHTS");
			for(int i=0; i < weights.length; i++){
				sum += (features.get(i) * cumulativeWeights[i]);
				//System.out.println(cumulativeWeights[i]);
			}
			//System.out.println();
			return sum;
		}
		else
			return sum;
	}
	
	public double evaluate(FeatureSet features){
		double sum = bias;
		for(int i=0; i < weights.length; i++)
			sum += (features.get(i) * weights[i]); 
		return sum;
	
	}
}
