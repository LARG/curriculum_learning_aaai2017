package pacman.entries.pacman;

import java.util.Random;

import pacman.game.Game;
import pacman.game.Constants.MOVE;

/**
 * Q(lambda) with function approximation.
 */
public class ShapedQPacMan extends BasicRLPacMan {
	
	private Random rng = new Random();
	public FeatureSet prototype; // Class to use
	private ShapedQFunction shapedQ; // Learned policy
	private QFunction Qfunction; // Learned policy
	private MOVE[] actions; // Actions possible in the current state
	private double[] qvalues; // Q-values for actions in the current state
	private double[] shapedqvalues;
	private FeatureSet[] features; // Features for actions in the current state
	
	private int lastScore; // Last known game score
	private double curShaped = 0;
	private double lastShaped = 0;
	private int bestActionIndex; // Index of current best action
	private int bestShapedIndex;
	private int lastActionIndex; // Index of action actually being taken
	private boolean testMode; // Don't explore or learn or take advice?

	public static double EPSILON = 0.05; // Exploration rate
	private double ALPHA = 0.0013; // Learning rate
	private double GAMMA = .999;//0.999; // Discount rate
	private double LAMBDA = 0.7; // Backup weighting

	/** Initialize the policy. */
	public ShapedQPacMan(FeatureSet proto, ShapedQFunction pot) {
		prototype = new DepthFeatureSet(proto.depth());
		Qfunction = new QFunction(prototype);
		shapedQ = pot;
	}

	/** Prepare for the first move. */
	public void startEpisode(Game game, boolean testMode) {
		this.testMode = testMode;
		lastScore = 0;
		Qfunction.clearTraces();
		evaluateMoves(game);
	}
	
	/** Choose a move. */
	public MOVE getMove(Game game, long timeDue) {
		return actions[lastActionIndex];
	}
	
	/** Override the move choice. */
	public void setMove(MOVE move) {
		lastActionIndex = -1;
		for (int i=0; i<actions.length; i++)
			if (actions[i] == move)
				lastActionIndex = i;
	}

	/** Prepare for the next move, and learn if appropriate. */
	public void processStep(Game game) {
		
		// Eligibility traces
		if (lastActionIndex != bestActionIndex)
			Qfunction.clearTraces();
		else
			Qfunction.decayTraces(GAMMA*LAMBDA);
		
		Qfunction.addTraces(features[lastActionIndex]);

		// Q-value correction
		double reward = game.getScore() - lastScore;
		lastScore = game.getScore();
		double delta = reward - qvalues[lastActionIndex];
		//if(reward == 0.0 && lastScore == 0.0)
		//	for(int i = 0; i < qvalues.length; i++)
		//		System.out.println(qvalues[i]);
		if (!game.gameOver()) {
			evaluateMoves(game);
			delta += (GAMMA * qvalues[bestActionIndex]);// + (GAMMA * curShaped - lastShaped);
		}
		
		// Gradient descent update
		if (!testMode)
			Qfunction.updateWeights(ALPHA*delta);
	}

	/** Compute predictions for moves in this state. */
	private void evaluateMoves(Game game) {
		
		actions = game.getPossibleMoves(game.getPacmanCurrentNodeIndex());

		features = new FeatureSet[actions.length];
		for (int i=0; i<actions.length; i++)
			features[i] = prototype.extract(game, actions[i]);	//TODO: extract uses old depth value.
		
		/*
		 * Here, we obtain Qvalues from our learned policy
		 * and that of a shaped function that represents the cumulative transfered policy
		 */
		qvalues = new double[actions.length];
		shapedqvalues = new double[actions.length];
		for (int i=0; i<actions.length; i++){
			qvalues[i] = Qfunction.evaluate(features[i]) + shapedQ.evaluate_shape(features[i]);
			//shapedqvalues[i] = shapedQ.evaluate_shape(features[i]);
		}

		bestActionIndex = 0;
		bestShapedIndex = 0;
		lastShaped = curShaped;
		for (int i=0; i<actions.length; i++){
			if (qvalues[i] > qvalues[bestActionIndex]){//qvalues[i] + shapedqvalues[i] > qvalues[bestActionIndex] + shapedqvalues[bestShapedIndex]){
				bestActionIndex = i;
				bestShapedIndex = i;
				//curShaped = shapedQ.evaluate_shape(features[i]);
			}
			/*if (shapedqvalues[i] > qvalues[bestShapedIndex]){
				bestShapedIndex = i;
				curShaped = shapedQ.evaluate_shape(features[i]);
			}*/
		}

		// Explore or exploit
		if (!testMode && rng.nextDouble() < EPSILON){
			lastActionIndex = rng.nextInt(actions.length);
			//curShaped = shapedqvalues[lastActionIndex];
		}
		else{
			lastActionIndex = bestActionIndex;
		}
	}
	
	/** Get the current possible moves. */
	public MOVE[] getMoves() {
		return actions;
	}
	
	/** Get the current Q-value array. */
	public double[] getQValues() {
		return qvalues;
	}
	
	/** Get the current features for an action. */
	public FeatureSet getFeatures(MOVE move) {
		int actionIndex = -1;
		for (int i=0; i<actions.length; i++)
			if (actions[i] == move)
				actionIndex = i;
		return features[actionIndex];
	}
	
	/** Save the current policy to a file. */
	public void savePolicy(String filename) {
		Qfunction.save(filename);
	}

	/** Return to a policy from a file. */
	public void loadPolicy(String filename) {
		Qfunction = new QFunction(prototype, filename);
	}
	
	public QFunction getQFunction(){
		return Qfunction;
	}
}
