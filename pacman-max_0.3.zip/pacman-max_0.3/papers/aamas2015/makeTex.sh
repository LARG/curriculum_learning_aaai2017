latex main.tex
bibtex main
latex main.tex
latex main.tex
dvips -t letter -Ppdf -G0 main.dvi -o main.ps


# latest and greatest
ps2pdf13 -dCompatibilityLevel=1.3 -dMonoImageResolution=600 -dColorImageResolution=300 -dGrayImageResolution=300 -dMAxSubsetPct=100 -dSubsetFonts=true -dEmbedAllFonts=true  -sPAPERSIZE=letter main.ps
