
import numpy

def main():

  # Editable parameters
  learner = 'independent'
  length = 50

  targetTaskFile = 'targetTask'
  targetFile = 'independent_1'


  targetPolicy = 'subTask1'

  # Task set parameters!

  ghostType = range(1,2)
  numGhosts = range(5)
  ghostSpeedReduction = range(2,3)
  mazeNum = range(0,9)
  edibleTime = [0,1]#[200, 2000] #range(100, 500, 100) + [2000]
  completionBonus = [0,1]#[0, 100]
  featureTransfer = range(0,11)
  repeats = range(1,6)
  task_num = 10
  for gt in ghostType:
    for ng in numGhosts:
      for gsr in ghostSpeedReduction:
        for m in mazeNum:
          for et in edibleTime:
            for cb in completionBonus:
              for ft in featureTransfer:              
		      #taskFile = 'ghostType%dNumGhosts%dSpeedReduction%dMaze%dEdibleTime%dBonus%d' % (gt, ng, gsr, m, et, cb)
		      taskFile = 'task%d' % (task_num)
		      f = open(taskFile, 'w')
		      
		      # Task specific parameters
		      f.write('maze_num\t%d\n'%m)
		      f.write('ghost_type\t%d\n'%gt)
		      f.write('ghost_speed\t%d\n'%gsr)
		      f.write('num_ghosts\t%d\n'%ng)
		      if m is 0:
		      	num_pills = 220
		      	num_super = 4
		      	train_depth = 9
		      	max_depth = 9
		      	num_junctions = 38
		      elif m is 1:
		      	num_pills = 240
		      	num_super = 4
		      	train_depth = 4
		      	max_depth = 9
		      	num_junctions = 36
		      elif m is 2:
		      	num_pills = 238
		      	num_super = 4
		      	train_depth = 10
		      	max_depth = 10
		      	num_junctions = 44
		      elif m is 3:
		      	num_pills = 234
		      	num_super = 4
		      	train_depth = 2
		      	max_depth = 13
		      	num_junctions = 40
		      elif m is 4:
		      	num_pills = 65
		      	num_super = 2
		      	train_depth = 2
		      	max_depth = 2
		      	num_junctions = 2
		      elif m is 5:
		      	num_pills = 53
		      	num_super = 1
		      	train_depth = 2
		      	max_depth = 2
		      	num_junctions = 2
		      elif m is 6:
		      	num_pills = 179
		      	num_super = 4
		      	train_depth = 4
		      	max_depth = 4
		      	num_junctions = 8
		      elif m is 7:
		      	num_pills = 209
		      	num_super = 4
		      	train_depth = 5
		      	max_depth = 5
		      	num_junctions = 13
		      elif m is 8:
		      	num_pills = 231
		      	num_super = 4
		      	train_depth = 8
		      	max_depth = 8
		      	num_junctions = 24
		      if ft is 0:
		      	f.write('regular_pill')
		      elif ft is 1:
		      	f.write('power_pill')
		      elif ft is 2:
		      	f.write('regular_ghost')
		      elif ft is 3:
		      	f.write('edible_ghost')
		      elif ft is 4:
		      	f.write('regular_pill')
		      	f.write('power_pill')
		      elif ft is 5:
		      	f.write('regular_pill')
		      	f.write('power_pill')
		      elif ft is 6:
		      	f.write('regular_pill')
		      	f.write('regular_ghost')
		      elif ft is 7:
		      	f.write('regular_pill')
		      	f.write('edible_ghost')
		      elif ft is 8:
		      	f.write('power_pill')
		      	f.write('regular_ghost')
		      	f.write('edible_ghost')
		      elif ft is 9:
		      	f.write('power_pill')
		      	f.write('edible_ghost')
		      elif ft is 10:
		      	f.write('regular_pill')
		      	f.write('power_pill')
		      	f.write('regular_ghost')
		      	f.write('edible_ghost')

		      f.write('num_pills\t%d\n'%num_pills)
		      f.write('num_super\t%d\n'%num_super)
		      f.write('train_depth\t%d\n'%train_depth)
		      f.write('max_depth\t%d\n'%max_depth)
		      f.write('num_junctions\t%d\n'%num_junctions)
		      f.write('task_num\t%d\n'%task_num)
		      task_num += 1
		      #f.write('EDIBLE_TIME:%d\n'%et)
		      #f.write('BOARD_COMPLETION_BONUS:%d\n'%cb)

		      # Common parameters
		      #f.write('LEARNER:%s\n'%learner)
		      #f.write('LENGTH:%d\n'%length)
		      #f.write('SOURCE_TASK:%s\n'%taskFile)              
		      #f.write('SAVE_DIR:%s\n'%taskFile)

		      f.close()
		      
		      # Condor output
		      for r in repeats:
	#                print 'Arguments = pacman.Experiments tasks/' + taskFile + '.task tasks/' + targetTaskFile + ' ' + targetFile + '/avg_curve ' + str(r)
	#                print 'Queue 1'
	#                print

		        print 'Arguments = pacman.Experiments tasks/' + taskFile + '.task ' + targetPolicy + '/policy' + str(r-1) + ' ' + str(r) 
		        print 'Queue 1'
		        print


		      print 'Saving', taskFile, '.task'
#
  print 'Finished.'



if __name__=="__main__":
  main()

