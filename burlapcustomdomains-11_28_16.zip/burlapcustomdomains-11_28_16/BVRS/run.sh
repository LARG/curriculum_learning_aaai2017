#!/bin/bash
# Runs BVpicker, the kick off class for the BVRS domain.
#requires RSGridWorld exec
java -cp ../lib/burlap.jar:../RSGridWorld/:. BVpicker
