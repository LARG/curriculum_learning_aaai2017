Block Dude Curriculum Learning Experiments
---

An implementation of automated curriculum generation for reinforcement learning on the [Block Dude](http://azich.org/blockdude/) domain. Uses RBF based value function approximation and SARSA(lambda).

## Installation

Ensure that you have JDK 1.8 installed. To get started quickly, we recommend that you run the project in [IntelliJ](https://www.jetbrains.com/idea/). Use the Scala and SBT plugins to quickly pull down dependencies.

## Usage

Several IntelliJ run configurations are tracked with the repo. See CLI usage by passing `-h`.

## Experimental setup

Each experiment runs a curriculum, evaluates its performance, and outputs information into the `results` directory. Depending on the configuration run, the curriculum might be a hand generated one, or it may be automatically generated from a pool of hand generated maps.

The goal of a curriculum is to learn a difficult task quickly by transferring knowledge from smaller tasks. Thus a curriculum can be deemed successful if the total time spent learning it is less than the time it would take to learn just the final target task from scratch. This is called _strong transfer_. The same assessment can be made of every intermediate step in a curriculum. Every experiment will output an assessment of whether or not strong transfer occurred.
