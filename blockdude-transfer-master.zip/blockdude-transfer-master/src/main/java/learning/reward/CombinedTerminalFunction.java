package learning.reward;

import burlap.oomdp.core.TerminalFunction;
import burlap.oomdp.core.states.State;

import java.util.HashMap;
import java.util.Map;

public class CombinedTerminalFunction implements TerminalFunction {
    Map<String, TerminalFunction> terminalFunctions;

    public CombinedTerminalFunction() {
        terminalFunctions = new HashMap<>();
    }

    public void addTerminalFunction(String name, TerminalFunction function) {
        terminalFunctions.put(name, function);
    }

    @Override
    public boolean isTerminal(State s) {
        return terminalFunctions.values().stream().map((tf) -> tf.isTerminal(s)).reduce(false, (a, b) -> a || b);
    }

    public boolean isTerminalForFunction(State s, String name) {
        TerminalFunction tf = terminalFunctions.get(name);
        if (tf != null) {
            return tf.isTerminal(s);
        } else {
            throw new RuntimeException("Terminal function " + name + " doesn't exist");
        }

    }
}
