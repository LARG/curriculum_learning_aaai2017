package learning.reward;

import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.TerminalFunction;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;

import java.awt.*;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TrapBasedTerminalFunction implements TerminalFunction {
    @Override
    public boolean isTerminal(State s) {
        List<ObjectInstance> blocks = s.getObjectsOfClass(BlockDude.CLASSBLOCK);
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);

        int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();

        // Coordinates of all the blocks on map
        Stream<Point> coordinates = blocks.stream().map(block -> {
            int blockX = (int) block.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
            int blockY = (int) block.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();

            return new Point(blockX, blockY);
        });

        // Blocks grouped by x coordinate
        Map<Double, List<Point>> blockGroups = coordinates.collect(Collectors.groupingBy(Point::getX));

        // All columns (2 blocks or more stacked) in map
        Map<Double, List<Point>> columns = blockGroups.entrySet().stream()
                .filter(mapNode -> blockGroups.getOrDefault(mapNode.getKey(), Collections.emptyList()).size() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        // Closest column to agent
        Optional<Double> closestColumn = columns.keySet().stream().filter(xCoordinate -> xCoordinate > agentX).map(xCoordinate -> xCoordinate - agentX).min(Double::compare);
        if (!closestColumn.isPresent()) {
            return false;
        }
        double closestColumnX = closestColumn.get() + agentX;
        int height = columns.get(closestColumnX).size();

        // Total number of blocks to the left of the column
        int blocksAvailable = blockGroups.keySet().stream().filter(xCoordinate -> xCoordinate < closestColumnX)
                .mapToInt(xCoordinate -> blockGroups.get(xCoordinate).size()).sum();

        // Sum of natural numbers up to column height - 1
        int blocksNeeded = (height - 1) * height / 2;

        //System.out.println(blocksAvailable + " " + blocksNeeded);
        return blocksAvailable < blocksNeeded;
    }
}
