package learning.reward;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.common.GoalBasedRF;

import java.util.function.IntSupplier;

public class BlockDudeGoalTrapRF extends GoalBasedRF {

    public static final String GOAL_TF = "goal";
    public static final String TRAP_TF = "trap";

    private final CombinedTerminalFunction ctf;
    private final double trapReward;
    private IntSupplier stepsLeftSupplier;

    public BlockDudeGoalTrapRF(CombinedTerminalFunction tf, double goalReward, double trapReward, double defaultReward) {
        super(tf, goalReward, defaultReward);
        this.ctf = tf;
        this.trapReward = trapReward;
    }

    @Override
	public double reward(State s, GroundedAction a, State sprime) {

		if (ctf.isTerminalForFunction(sprime, GOAL_TF)) {
            return goalReward;
        } else if (ctf.isTerminalForFunction(sprime, TRAP_TF)) {
            double reward = trapReward + -1 * stepsLeftSupplier.getAsInt();
            System.out.println("Was trapped. Reward: " + reward);
            return reward;
        }

		return defaultReward;
	}

    public void setStepsLeftSupplier(IntSupplier stepsLeftSupplier) {
        this.stepsLeftSupplier = stepsLeftSupplier;
    }
}
