package learning;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.IntStream;


public class RunMany {
    /**
     * Repeat a single trial of the input arguments, saving results into indexed folders a la the condor script.
     * Runs until stopped.
     *
     * @param argv
     */
    public static void main(String[] argv) {
        Path outDir = Paths.get(argv[0]);
        IntStream.range(0, 10000).parallel().forEach(trial -> {
            String argString = "";
            for (int i = 0; i < argv.length; i++) {
                if (i == 0) continue;
                String arg = argv[i];
                argString += arg + " ";
            }
            argString = argString.substring(0, argString.length() - 1);
            Path trialOutDir = outDir.resolve("" + trial);
            // Don't repeat a trial
            if (trialOutDir.toFile().exists()) {
                return;
            }
            trialOutDir.toFile().mkdirs();
            argString += " -trials 1 -log " + trialOutDir + " -no-plots -no-map-images -ofs";

            String[] newArgs = argString.split(" ");

            System.out.println("********** " + trial + " ********** ");
            Runner.main(newArgs);
            trial += 1;
        });
    }
}
