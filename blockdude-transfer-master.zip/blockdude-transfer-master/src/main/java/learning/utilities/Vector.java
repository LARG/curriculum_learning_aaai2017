package learning.utilities;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class Vector {
    /**
     * The sum of all elements in the vector
     *
     * @param vector
     * @return
     */
    public static double oneNorm(List<Boolean> vector) {
        return vector.stream().mapToDouble(value -> Math.abs(value ? 1.0 : 0.0)).sum();
    }

    static double magnitude(List<Double> vector) {
        double squaredSum = vector.stream().mapToDouble(i -> Math.pow(i, 2)).sum();
        return Math.sqrt(squaredSum);
    }

    /**
     * Determines whether each element of the first is less than or equal to the corresponding element in the second
     *
     * @param first
     * @param second
     * @return
     */
    public static boolean isSubset(List<Boolean> first, List<Boolean> second) {
        assert first.size() == second.size();
        for (int i = 0; i < first.size(); i++) {
            // If the first is true and the second is false, not a subset
            // All other cases are fine: if the second is true, anything goes
            // If the first is false, anything goes
            if (first.get(i) && !second.get(i)) {
                return false;
            }
        }
        return true;
    }

    public static double euclideanDistanceBool(List<Boolean> source, List<Boolean> target) {
        List<Double> sourceMapped = source.stream()
                .map(bool -> bool ? 1.0 : 0.0)
                .collect(Collectors.toCollection(LinkedList::new));

        List<Double> targetMapped = target.stream()
                .map(bool -> bool ? 1.0 : 0.0)
                .collect(Collectors.toCollection(LinkedList::new));

        return euclideanDistance(sourceMapped, targetMapped);
    }

    static double euclideanDistance(List<Double> source, List<Double> target) {
        double distance = 0.0;
        for (int i = 0; i < source.size(); i++) {
            distance += Math.pow(source.get(i) - target.get(i), 2);
        }
        return Math.sqrt(distance);
    }

    /**
     * Takes the product of all entries of the vector. Entries with a value
     * of zero are ignored.
     *
     * @param vector
     * @return product of all entries
     */
    public static double volume(List<Double> vector) {
        return vector.stream()
                .reduce(1.0, (partial, next) -> partial * (next == 0.0 ? 1.0 : next));
    }

    /**
     *
     * @param first
     * @param second
     * @return
     */
    public static List<Double> elementWiseMin(List<Double> first, List<Double> second) {
        assert first.size() == second.size();
        List<Double> result = new LinkedList<>();
        for (int i = 0; i < first.size(); i++) {
            result.add(Math.min(first.get(i), second.get(i)));
        }
        return result;
    }

    /**
     * Find the maximum index of a particular row in a matrix
     *
     * @param matrix
     * @param row
     * @return
     */
    public static int maxIndexForRowInMatrix(double[][] matrix, int row) {
        assert row < matrix.length;
        double max = Double.NEGATIVE_INFINITY;
        int maxIndex = -1;
        for (int i = 0; i < matrix[0].length; i++) {
            double value = matrix[row][i];
            if (value > max) {
                assert (value != max);
                max = value;
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    /**
     * Finds the maximum index within a range of indices.
     *
     * @param values
     * @param lowIndex lowest index to consider
     * @param maxIndex the upper limit (exclusive) of the range
     * @return
     */
    public static int maxIndexInRange(double[] values, int lowIndex, int maxIndex) {
        assert lowIndex < maxIndex;
        double max = Double.NEGATIVE_INFINITY;
        int indexOfMax = -1;
        for (int i = lowIndex; i < maxIndex; i++) {
            if (values[i] > max) {
                max = values[i];
                indexOfMax = i;
            }
        }
        return indexOfMax;
    }
}
