package learning.utilities;

import javax.swing.*;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class FileUtilities {
    /**
     * Recursively deletes directory
     *
     * @param directory
     * @throws IOException
     */
    public static void deleteDirectory(Path directory) throws IOException {
        if (!directory.toFile().exists()) {
            return;
        }
        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }

        });
    }

    public static void deleteFiles(List<Path> filePaths) {
        filePaths.stream().forEach(p -> {
            try {
                Files.delete(p);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Compresses a file, producing an archive with the same name but with .gz appended.
     *
     * @param f
     */
    public static void compressFile(File f) {
        File parentDir = f.getParentFile();
        File compressed = parentDir.toPath().resolve(f.getName() + ".gz").toFile();

        try (
                InputStream in = new FileInputStream(f);
                FileOutputStream fout = new FileOutputStream(compressed);
                GZIPOutputStream zout = new GZIPOutputStream(fout)
        ) {
            byte[] buffer = new byte[1000];
            int len;
            while ((len = in.read(buffer)) > 0) {
                zout.write(buffer, 0, len);
            }
            zout.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Extracts the first entry of a zip file and places it next to the original archive
     *
     * @param zipFilePath
     */
    public static File unzip(Path zipFilePath) {
        try (
                GZIPInputStream zipIn = new GZIPInputStream(new FileInputStream(zipFilePath.toFile()))
        ) {
            Path path = Paths.get(zipFilePath.toString().replace(".gz", ""));
            extractFile(zipIn, path);

            return path.toFile();

        } catch (IOException e) {

        }
        return null;

    }

    /**
     * Extracts a zip entry (file entry)
     *
     * @param zipIn
     * @param filePath
     * @throws IOException
     */
    private static void extractFile(GZIPInputStream zipIn, Path filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath.toFile()));
        byte[] bytesIn = new byte[4096];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }

    public static Path pickDirectory(File initialPath) {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(initialPath);
        chooser.setDialogTitle("Visualization Data Path");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);

        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile().toPath();
        } else {
            return null;
        }
    }


    public static void deleteFile(Path path) {
        try {
            Files.delete(path);
        } catch (Exception e) {
            System.out.println("Couldn't delete "  + path);
        }
    }
}