package learning.utilities;

import burlap.behavior.singleagent.EpisodeAnalysis;
import learning.experiment.AggregatedTrial;
import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;
import learning.visualization.Plotter;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DataUtilities {
    public static void writeVisualizationData(List<EpisodeAnalysis> analysisList, Path experimentPath, BlockDudeCurriculum.Step step) {

        Path trialPath = experimentPath.resolve(step.index + "");
        File trialDir = trialPath.toFile();
        trialDir.mkdirs();

        for (int i = 0; i < analysisList.size(); i++) {
            Path outFilePath = trialPath.resolve(step + "_" + i);
            analysisList.get(i).writeToFile(outFilePath.toString());
        }
    }

    public static void saveCSVs(Path outPath, Map<BlockDudeCurriculum.Step, AggregatedTrial> trials) {
        List<Path> csvFiles = new LinkedList<>();
        for (Map.Entry<BlockDudeCurriculum.Step, AggregatedTrial> entry : trials.entrySet()) {
            // Write episode-wise data
            String episodefileName = entry.getKey().toString();
            csvFiles.add(writeTrialToCSV(entry.getValue(), outPath.resolve(episodefileName), true));

            // Write step-wise data
            String stepfileName = entry.getKey().toString() + "-stepwise";
            csvFiles.add(writeTrialToCSV(entry.getValue(), outPath.resolve(stepfileName), false));
        }
        for (Path csvPath : csvFiles) {
            FileUtilities.compressFile(csvPath.toFile());
        }
        // Delete uncompressed csv files
        FileUtilities.deleteFiles(csvFiles);
    }

    /**
     * Writes the trial data to a csv file.
     * If the file path does not include the .csv extension, it will automatically be added.
     *
     * @param trial    the trial to write.
     * @param outPath the path to the csv file to write to.
     * @param episodeWise whether the data to write should be the episode-wise data, or step-wise data (i.e. evaluation rewards)
     */
    public static Path writeTrialToCSV(AggregatedTrial trial, Path outPath, boolean episodeWise) {

        if (!outPath.toString().endsWith(".csv")) {
            outPath = Paths.get(outPath.toString() + ".csv");
        }

        //Ensure that the output path exists
        File f = outPath.toFile();
        f.getParentFile().mkdirs();

        try {
            BufferedWriter outEpisode = new BufferedWriter(new FileWriter(f));
            if (episodeWise) {
                writeEpisodeInformation(trial, outEpisode);
            } else {
                writeStepInformation(trial, outEpisode);
            }
            outEpisode.close();
            return outPath;
        } catch (Exception e) {
            System.err.println("Could not write csv file to: " + outPath.toString());
            e.printStackTrace();
        }
        return null;
    }

    private static void writeEpisodeInformation(AggregatedTrial trial, BufferedWriter out) throws IOException {

        // Metadata that's needed for properly offsetting the graph
        out.write(trial.nTrials + "\n");
        out.write(trial.meanStepsTilConvergence.mean + ", " + trial.meanStepsTilConvergence.variance + "\n");
        //create header
        out.write("episode,stepEpisodeMean,stepEpisodeVariance\n");

        for (int i = 0; i < trial.totalEpisodes; i++) {
            AggregatedTrial.StatPair stepPair = trial.stepsPerEpisode.get(i);
            out.write(i + "");
            out.write("," + stepPair.mean);
            out.write("," + stepPair.variance);
            out.write("\n");
        }

    }

    /**
     * Writes step-indexed information.
     *
     * @param trial
     * @param out
     * @throws IOException
     */
    private static void writeStepInformation(AggregatedTrial trial, BufferedWriter out) throws IOException {

        //create header
        out.write("step,evaluationRewardMean,evaluationRewardVariance\n");

        for (Pair<Integer, AggregatedTrial.StatPair> evaluationReward : trial.evaluationReward) {
            int step = evaluationReward.getLeft();
            AggregatedTrial.StatPair stepPair = evaluationReward.getRight();
            out.write(step + "");
            out.write("," + stepPair.mean);
            out.write("," + stepPair.variance);
            out.write("\n");
        }

    }

    public static void saveScratchCSVs(Path outPath, Map<BlockDudeMap, AggregatedTrial> trials) {
        List<Path> csvFiles = new LinkedList<>();
        for (Map.Entry<BlockDudeMap, AggregatedTrial> entry : trials.entrySet()) {
            // Write episode-wise data
            String episodefileName = entry.getKey().index + "";
            csvFiles.add(writeTrialToCSV(entry.getValue(), outPath.resolve(episodefileName), true));

            // Write step-wise data
            String stepfileName = entry.getKey().index + "-stepwise";
            csvFiles.add(writeTrialToCSV(entry.getValue(), outPath.resolve(stepfileName), false));
        }
        for (Path csvPath : csvFiles) {
            FileUtilities.compressFile(csvPath.toFile());
        }
        // Delete uncompressed csv files
        FileUtilities.deleteFiles(csvFiles);
    }

    public static AggregatedTrial readEpisodeInformation(List<String> lines) {
        List<AggregatedTrial.StatPair> episodeSteps = new LinkedList<>();
        int nTrials = Integer.parseInt(lines.get(0));
        String[] stepsToConvergenceItems = lines.get(1).split(",");
        final double meanStepsToConvergence = Double.parseDouble(stepsToConvergenceItems[0]);
        final double varianceStepsToConvergence = Double.parseDouble(stepsToConvergenceItems[1]);
        for (int i = 3; i < lines.size(); i++) {
            String line = lines.get(i);
            String[] items = line.split(",");
            final double episodeStepsMean = Double.parseDouble(items[1]);
            final double episodeStepsVariance = Double.parseDouble(items[2]);
            episodeSteps.add(new AggregatedTrial.StatPair(episodeStepsMean, episodeStepsVariance, nTrials));
        }
        return new AggregatedTrial(episodeSteps, nTrials, meanStepsToConvergence, varianceStepsToConvergence);
    }

    public static void saveExperimentSummary(Path experimentPath, String summary) {
        Path summaryPath = experimentPath.resolve("summary.md");
        try (FileWriter fw = new FileWriter(summaryPath.toFile(), true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.print(summary);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Saves plots comparing scratch and transfer performance
     *
     * @param outPath
     * @param transferTrials
     * @param scratchTrials
     */
    public static void generatePlots(Path outPath, Map<BlockDudeCurriculum.Step, AggregatedTrial> transferTrials, Map<BlockDudeMap, AggregatedTrial> scratchTrials) {
        outPath.toFile().mkdirs();

        // Generate steps across episodes graphs for each step of the curriculum
        for (Map.Entry<BlockDudeCurriculum.Step, AggregatedTrial> entry : transferTrials.entrySet()) {
            AggregatedTrial transferTrial = entry.getValue();
            BlockDudeCurriculum.Step step = entry.getKey();
            // The scratch results we need to compare against are those of the target map for this step
            AggregatedTrial scratch = scratchTrials.get(step.target);

            List<Plotter.Line> lines = new LinkedList<>();
            if (scratch != null) {
                // How did the scratch agent do?
                Plotter.Line scratchLine = new Plotter.Line("Scratch", scratch.stepsPerEpisode, 1);

                lines.add(scratchLine);
            }

            // Only plot the transfer agent if the transfer agent would actually have had any source tasks
            if (step.hasSources()) {
                // How did the transfer agent do?
                Plotter.Line transferLine = new Plotter.Line("Transfer", transferTrial.stepsPerEpisode, 1);
                lines.add(transferLine);
            }

            String graphTitle = "Map " + step.target.index + " mean steps per episode";
            final Plotter stepPlot = new Plotter(graphTitle, "Episode", "Steps", lines, scratch.nTrials, 0.05, true);

            // Save as image
            String plotFileName = step + ".png";
            Path plotPath = outPath.resolve(plotFileName);
            stepPlot.saveAsPNG(plotPath.toFile());

        }

        // Create evaluation graphs
        for (Map.Entry<BlockDudeCurriculum.Step, AggregatedTrial> entry : transferTrials.entrySet()) {
            AggregatedTrial trial = entry.getValue();
            BlockDudeCurriculum.Step step = entry.getKey();
            // The scratch results we need to compare against are those of the target map for this step
            AggregatedTrial scratch = scratchTrials.get(step.target);

            List<Plotter.Line> lines = new LinkedList<>();

            if (scratch != null) {
                Plotter.Line scratchLine = new Plotter.Line("Scratch", scratch.evaluationReward);
                lines.add(scratchLine);
            }


            // Only plot the transfer line if the transfer agent would have had any sources
            if (step.hasSources()) {
                Plotter.Line transferLine = new Plotter.Line("Transfer", trial.evaluationReward);
                transferLine.offset = timeSpentLearningSources(step, transferTrials);
                lines.add(transferLine);
            }
            String graphTitle = "Map " + step.target.index + " mean policy reward for steps spent learning";
            final Plotter evalPlot = new Plotter(graphTitle, "Steps", "Reward", lines, trial.nTrials, 0.05, false);

            // Save as image
            String fileName = step.toString();
            String evalPlotFileName = fileName + "-performance.png";
            Path evalPlotPath = outPath.resolve(evalPlotFileName);
            evalPlot.saveAsPNG(evalPlotPath.toFile());
        }
    }

    /**
     * Calculates how much time was spent learning all sources for a given step in a curricula
     *
     * @param step
     * @param learningTimes
     * @return
     */
    private static int timeSpentLearningSources(BlockDudeCurriculum.Step step, Map<BlockDudeCurriculum.Step, AggregatedTrial> learningTimes) {
        // Note how we don't count the time spent in the passed-in step. We're only interested in the time spent
        // _before_ that step.
        int timeSpentLearningSources = 0;
        for (BlockDudeMap sourceMap : step.sources) {
            BlockDudeCurriculum.Step sourceStep = sourceMap.curriculum.stepWithTarget(sourceMap);
            timeSpentLearningSources += timeSpentLearning(sourceStep, learningTimes);
        }
        return timeSpentLearningSources;
    }

    private static int timeSpentLearning(BlockDudeCurriculum.Step step, Map<BlockDudeCurriculum.Step, AggregatedTrial> learningTimes) {
        // Base case: a step has no sources -> the time spent learning is just the mean time until it converged.
        int timeSpentLearningSources = 0;
        for (BlockDudeMap sourceMap : step.sources) {
            BlockDudeCurriculum.Step sourceStep = sourceMap.curriculum.stepWithTarget(sourceMap);
            timeSpentLearningSources += timeSpentLearning(sourceStep, learningTimes);
        }
        AggregatedTrial trial = learningTimes.get(step);
        // We *are* counting the time spent in this task in the recursive step
        int roundedUp = (int) Math.ceil(trial.meanStepsTilConvergence.mean);
        return timeSpentLearningSources + roundedUp;
    }

    public static int[][] twoDArrayCopy(int[][] array) {
        int[][] copy = new int[array.length][];
        for (int i = 0; i < array.length; i++) {
            int[] row = array[i];
            int rowLength = row.length;
            copy[i] = new int[rowLength];
            System.arraycopy(row, 0, copy[i], 0, rowLength);
        }
        return copy;
    }

    public static double[] copyFromIntArray(int[] source) {
        double[] dest = new double[source.length];
        for (int i = 0; i < source.length; i++) {
            dest[i] = source[i];
        }
        return dest;
    }

    public static List<Pair<Integer, AggregatedTrial.StatPair>> readStepwiseInformation(List<String> lines, int n) {
        List<Pair<Integer, AggregatedTrial.StatPair>> stats = new LinkedList<>();
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i);
            String[] items = line.split(",");
            final int step = Integer.parseInt(items[0]);
            final double episodeStepsMean = Double.parseDouble(items[1]);
            final double episodeStepsVariance = Double.parseDouble(items[2]);
            stats.add(new ImmutablePair<>(step, new AggregatedTrial.StatPair(episodeStepsMean, episodeStepsVariance, n)));
        }
        return stats;
    }
}
