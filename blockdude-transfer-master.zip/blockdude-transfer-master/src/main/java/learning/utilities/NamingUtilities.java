package learning.utilities;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NamingUtilities {

    /**
     * Uniquely identify an episode run while evaluating a curriculum.
     *
     * @param curriculumNum
     * @param source
     * @param target
     * @param currentMap
     * @param episode
     * @return
     */
    public static String episodeName(int curriculumNum, int source, int target, int currentMap, boolean transfer, int episode) {
        return experimentStageName(curriculumNum, source, target, currentMap, transfer) + "_" + episode;
    }

    public static String experimentStageName(int curriculumNum, int source, int target, int currentMap, boolean scratch) {
        return experimentName(curriculumNum, source, target) + "_m" + currentMap + (scratch ? "_s" : "");
    }

    public static String experimentName(int curriculumNum, int source, int target) {
        return String.format("c%d_[%d-%d]", curriculumNum, source, target);
    }

    /**
     @param experimentName
     @return {curriculum, startStep, target, mapnum}
     */
    public static int[] extractExperimentStageParameters(String experimentName) {

        int[] results = extractExperimentParameters(experimentName);
        int[] allResults = new int[4];
        for (int i = 0; i < results.length; i++) {
            allResults[i] = results[i];
        }
        allResults[3] = extractMapNum(experimentName);
        return allResults;
    }

    /**
     @param experimentName
     @return {curriculum, startStep, target, mapnum}
     */
    public static int[] extractExperimentParameters(String experimentName) {
        String pattern = "c(\\d+)_\\[(\\d+)\\-(\\d+)\\]";

        // Create a Pattern object
        Pattern r = Pattern.compile(pattern);

        // Now create matcher object.
        Matcher m = r.matcher(experimentName);
        m.find();
        int[] results = new int[3];
        for (int i = 0; i < results.length; i++) {
            results[i] = Integer.parseInt(m.group(i + 1));
        }

        return results;
    }

    public static int extractMapNum(String name) {
        String pattern = "m(\\d+)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(name);
        m.find();
        return Integer.parseInt(m.group(1));
    }

    public static String durationToString(long duration) {
        long hours = TimeUnit.NANOSECONDS.toHours(duration) - TimeUnit.NANOSECONDS.toHours(TimeUnit.NANOSECONDS.toDays(duration));
        long minute = TimeUnit.NANOSECONDS.toMinutes(duration) - TimeUnit.HOURS.toMinutes(TimeUnit.NANOSECONDS.toHours(duration));
        long second = TimeUnit.NANOSECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.NANOSECONDS.toMinutes(duration));

        return hours + "h " + minute + "m " + second + "s";

    }
}
