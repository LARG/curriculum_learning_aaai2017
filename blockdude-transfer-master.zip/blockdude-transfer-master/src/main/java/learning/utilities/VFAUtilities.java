package learning.utilities;

import burlap.behavior.singleagent.vfa.cmac.CMACFeatureDatabase;
import burlap.behavior.singleagent.vfa.fourier.FourierBasis;
import burlap.behavior.singleagent.vfa.rbf.DistanceMetric;
import burlap.behavior.singleagent.vfa.rbf.RBFFeatureDatabase;
import burlap.behavior.singleagent.vfa.rbf.functions.GaussianRBF;
import burlap.behavior.singleagent.vfa.rbf.metrics.EuclideanDistance;
import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.states.State;
import learning.experiment.WorldComponents;
import learning.transfer.vfa.BlockDudeFeatureVectorGenerator;
import learning.transfer.vfa.BlockDudeRelativeFeatureVectorGenerator;
import learning.transfer.vfa.MockCenterState;

import java.util.LinkedList;
import java.util.List;

public class VFAUtilities {

    public static RBFFeatureDatabase createRBFFeatureDatabase(WorldComponents wc, int perceptionDepth, double bandwidth) {
        RBFFeatureDatabase rbf = new RBFFeatureDatabase(false);
        final int maxColumnHeight = 2;
        BlockDudeFeatureVectorGenerator generator = new BlockDudeRelativeFeatureVectorGenerator(wc.mapWidth(), wc.mapHeight(), perceptionDepth, maxColumnHeight);
        //BlockDudeFeatureVectorGenerator generator = new BlockDudePerceptionFeatureVectorGenerator(wc.mapWidth(), wc.mapHeight(), perceptionDepth);
        List<State> states = generateMockCenterStates(generator);

        //DistanceMetric metric = new AlignmentMetric(new BlockDudePerceptionFeatureVectorGenerator(1, wc.mapWidth()));
        //DistanceMetric metric = new EuclideanDistance(new BlockDudeFeatureVectorGenerator(wc.mapWidth(), wc.mapHeight()));
        DistanceMetric metric = new EuclideanDistance(generator);
        for (State s : states) {
            rbf.addRBF(new GaussianRBF(s, metric, bandwidth));
        }

        return rbf;
    }


    public static CMACFeatureDatabase createCMACFeatureDatabase(WorldComponents wc) {
        CMACFeatureDatabase cfd = new CMACFeatureDatabase(5, CMACFeatureDatabase.TilingArrangement.RANDOMJITTER);
        cfd.addSpecificaitonForTiling(0, BlockDude.CLASSAGENT, wc.domain.getAttribute(BlockDude.ATTX), 2);
        cfd.addSpecificaitonForTiling(1, BlockDude.CLASSAGENT, wc.domain.getAttribute(BlockDude.ATTY), 2);
        cfd.addSpecificaitonForTiling(2, BlockDude.CLASSBRICKS, wc.domain.getAttribute(BlockDude.ATTMAP), 2);
        cfd.addSpecificaitonForTiling(3, BlockDude.CLASSBLOCK, wc.domain.getAttribute(BlockDude.ATTX), 2);
        cfd.addSpecificaitonForTiling(4, BlockDude.CLASSBLOCK, wc.domain.getAttribute(BlockDude.ATTY), 2);
        return cfd;

    }

    public static FourierBasis createFourierFeatureDatabase(WorldComponents wc) {
        // Needs the learning rate to be <.001
        FourierBasis fb = new FourierBasis(new BlockDudeRelativeFeatureVectorGenerator(wc.mapWidth(), wc.mapHeight(), 1, 2), 2, 1000);
        return fb;
    }

    public static List<State> generateMockCenterStates(BlockDudeFeatureVectorGenerator generator) {

        List<int[]> permutations = new LinkedList<>();
        StateUtilities.generatePermutations(generator.getFeatureMin(), generator.getFeatureMax(), 0, permutations);

        List<State> centerStates = new LinkedList<>();
        for (int[] perm : permutations) {
            double[] features = DataUtilities.copyFromIntArray(perm);
            centerStates.add(new MockCenterState(features));
        }
        return centerStates;
    }
}
