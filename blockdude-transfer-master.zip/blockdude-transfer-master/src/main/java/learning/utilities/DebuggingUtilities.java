package learning.utilities;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.rbf.DistanceMetric;
import burlap.behavior.singleagent.vfa.rbf.metrics.EuclideanDistance;
import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.Action;
import burlap.oomdp.singleagent.GroundedAction;
import learning.experiment.WorldComponents;
import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.vfa.BlockDudeRelativeFeatureVectorGenerator;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Tools and helpers meant to be run from the console while execution is paused.
 */
public class DebuggingUtilities {

    public static String mapToString(int[][] map) {
        String out = "";
        final int height = map[0].length;
        final int width = map.length;
        for (int row = height - 1; row >= 0; row--) {
            for (int column = 0; column < width; column++) {
                out += " " + itemToChar(map[column][row]);
            }
            out += "\n";
        }
        return out;
    }

    static Character itemToChar(int item) {
        switch (item) {
            case BlockDudeMap.BRICK:
                return '█';
            case BlockDudeMap.BLOCK:
                return '□';
            case BlockDudeMap.EXIT:
                return 'X';
            case BlockDudeMap.STARTEAST:
            case BlockDudeMap.STARTEASTHOLDING:
                return '▶';
            case BlockDudeMap.STARTWEST:

            case BlockDudeMap.STARTWESTHOLDING:
                            return '◀';
                        default:
                        return ' ';
        }
    }

    /**
     Displays the value of taking every action in a state
     @param vfa
     @param state
     @param d
     @return
     */
    public static String actionValues(DifferentiableStateActionValue vfa, State state, Domain d) {
        String result = "";
        List<Action> actions = d.getActions();
        for (Action ab : actions) {
            GroundedAction a = ab.getAssociatedGroundedAction();
            result += "" + a.actionName() + ": " + vfa.evaluate(state, a) + "\n";
        }

        return result;
    }

    public static String actionValuesForAgentPosition(DifferentiableStateActionValue vfa, State state, Domain d, String actionName, final int mapWidth, final int mapHeight) {
        String result = "";
        Action a = d.getAction(actionName);

        GroundedAction ga = a.getAssociatedGroundedAction();
        for (int j = mapHeight; j > 0; j--) {
            for (int i = 0; i < mapWidth; i++) {
                // The state being queried needs to be unique (by hash) every time.
                // Otherwise the feature extractor cache will just return the same
                // features even though we're modifiying them.
                State scratchState = state.copy();
                scratchState.setObjectsValue(BlockDude.CLASSAGENT, BlockDude.ATTX, i);
                scratchState.setObjectsValue(BlockDude.CLASSAGENT, BlockDude.ATTY, j);
                result += String.format("%.2f ", vfa.evaluate(scratchState,ga));
            }
            result += "\n";
        }
        return result;
    }

    public static double valueOfEast(DifferentiableStateActionValue vfa, State state, WorldComponents wc) {
        return vfa.evaluate(state, wc.domain.getAction("east").getAssociatedGroundedAction());

    }

    public static String describeState(State s, final int width) {
        int[] brickMap = s.getObjectsOfClass(BlockDude.CLASSBRICKS).get(0).getIntArrayValForAttribute(BlockDude.ATTMAP);
        Set<Integer> exceptions = new HashSet<>();
        exceptions.add(BlockDudeMap.EXIT);
        final int map[] = Arrays.copyOf(brickMap, brickMap.length);
        MapUtilities.cleanBrickMap(map, exceptions);

        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        List<ObjectInstance> blocks = s.getObjectsOfClass(BlockDude.CLASSBLOCK);
        int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        int agentY = (int) agentObj.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();

        boolean facingEast = agentObj.getValueForAttribute(BlockDude.ATTDIR).getStringVal().equals("east");

        if(facingEast) {
            map[BlockDude.oneDMapIndex(agentX, agentY, width)] = BlockDudeMap.STARTEAST;
        } else {
            map[BlockDude.oneDMapIndex(agentX, agentY, width)] = BlockDudeMap.STARTWEST;
        }

        for (ObjectInstance block : blocks) {
            int blockX = (int) block.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
            int blockY = (int) block.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();
            map[BlockDude.oneDMapIndex(blockX, blockY, width)] = BlockDudeMap.BLOCK;
        }

        return brickMapToString(map, width);
    }

    static String brickMapToString(int[] brickMap, int mapWidth) {
        final int mapHeight = brickMap.length / mapWidth;
        String rows[] = new String[mapHeight];
        Arrays.fill(rows, "");
        int j = -1;
        for (int i = 0; i < brickMap.length; i++) {
            if (i % mapWidth == 0) {
                j += 1;
            }
            rows[j] += " " + itemToChar(brickMap[i]);
        }
        String s = "";
        for (int i = rows.length - 1; i >= 0; i--) {
            s += rows[i] + "\n";
        }
        return s;
    }

    /**

     @param s
     @param x
     @param y
     @return
     */
    public static boolean agentAt(State s, final int x, final int y) {
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        int agentY = (int) agentObj.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();
        return agentX == x && agentY == y;
    }

    public static double stateDiff(State s1, State s2, int mapWidth, int mapHeight) {
        DistanceMetric metric = new EuclideanDistance(new BlockDudeRelativeFeatureVectorGenerator(mapWidth, mapHeight, 2, 5));
        return metric.distance(s1,s2);
    }
}