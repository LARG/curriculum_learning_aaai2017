package learning.utilities;

import learning.transfer.curriculum.BlockDudeMap;

import java.util.Arrays;
import java.util.Set;

public class MapUtilities {


    /**
     Removes non-brick items from the brick-map.
     @param map
     @param exceptions
     */
    public static void cleanBrickMap(int[][] map, Set<Integer> exceptions) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                int content = map[i][j];
                if (content != BlockDudeMap.BRICK && !exceptions.contains(content)) {
                    map[i][j] = 0;
                }
            }
        }
    }

    public static void cleanBrickMap(int[] map, Set<Integer> exceptions) {
        for (int i = 0; i < map.length; i++) {
            int content = map[i];
            if (content != BlockDudeMap.BRICK && !exceptions.contains(content)) {
                map[i] = 0;
            }
        }
    }

    /**
     Places n blocks in a column of the map

     @param n
     @param column
     @param map     */
    public static void placeBlocks(int n, int column, int[][] map) {
        for (int i = 0; i < map[column].length; i++) {
            boolean empty = map[column][i] == 0;
            if (empty) {
                n--;
                map[column][i] = BlockDudeMap.BLOCK;
            }
            if (n == 0) {
                return;
            }
        }
        throw new RuntimeException("Couldn't place n blocks");
    }

    public static void placeAgent(int column, int[][] map, boolean east) {
        for (int i = 0; i < map[column].length; i++) {
            boolean empty = map[column][i] == 0;
            if (empty) {
                map[column][i] = east ? BlockDudeMap.STARTEAST : BlockDudeMap.STARTWEST;
                return;
            }
        }
        throw new RuntimeException("Couldn't place agent");
    }

    public static boolean placeHoldingAgent(int column, final int[][] map, boolean east) {
        for (int i = 0; i < map[column].length - 1; i++) {
            boolean empty = map[column][i] == 0;
            boolean nextEmpty = map[column][i + 1] == 0;
            if (empty && nextEmpty) {
                map[column][i] = east ? BlockDudeMap.STARTEASTHOLDING : BlockDudeMap.STARTWESTHOLDING;
                map[column][i + 1] = BlockDudeMap.BLOCK;
                return true;
            }
        }
        return false;
    }


    public static void padWithBricks(final int[][] map) {
        final int cols = map[0].length;
        final int rows = map.length;
        assert (rows > 2 && cols > 2);
        // Fill the first and last rows
        Arrays.fill(map[0], BlockDudeMap.BRICK);
        Arrays.fill(map[rows - 1], BlockDudeMap.BRICK);
        // Fill the first and last columns
        for (int r = 0; r < rows; r++) {
            map[r][0] = BlockDudeMap.BRICK;
            map[r][cols - 1] = BlockDudeMap.BRICK;
        }
    }

}
