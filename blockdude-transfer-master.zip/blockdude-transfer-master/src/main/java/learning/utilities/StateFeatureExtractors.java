package learning.utilities;

import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;

import java.util.List;

public class StateFeatureExtractors {
    public static void appendPerceptionShellFeatureVector(State s, List<Double> vector, final int depth, final int mapWidth) {
        List<Integer> perception = StateUtilities.getPerceptionShell(s, depth, mapWidth);
        for (int i = 0; i < perception.size(); i++) {
            vector.add(perception.get(i).doubleValue());
        }
    }

    public static void appendDistanceFromGoalFeatureVector(State s, List<Double> vector) {
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        ObjectInstance goal = s.getObjectsOfClass(BlockDude.CLASSEXIT).get(0);
        int goalX = (int) goal.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();

        double distanceToGoal = goalX - agentX;

        vector.add(distanceToGoal);
    }

    public static void appendYPositionFeatureVector(State s, List<Double> vector) {
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        int agentY = (int) agentObj.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();
        //double normalizedY = normalize(agentY, 1, mapHeight - 1);
        vector.add((double) agentY);
    }

    public static void appendFacingFeatureVector(State s, List<Double> vector) {
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        boolean facingEast = agentObj.getValueForAttribute(BlockDude.ATTDIR).getStringVal().equals("east");
        double normalizedFacingEast = facingEast ? 1 : 0;

        vector.add(normalizedFacingEast);
    }

    public static void appendHoldingFeatureVector(State s, List<Double> vector) {
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        boolean holding = agentObj.getValueForAttribute(BlockDude.ATTHOLD).getBooleanValue();
        double normalizedHolding = holding ? 1 : 0;

        vector.add(normalizedHolding);
    }

    public static void appendColumnHeightFeatureVector(State s, List<Double> vector, final int mapWidth) {
        int[] brickMap = s.getObjectsOfClass(BlockDude.CLASSBRICKS).get(0).getIntArrayValForAttribute(BlockDude.ATTMAP);
        ObjectInstance goal = s.getObjectsOfClass(BlockDude.CLASSEXIT).get(0);
        int goalX = (int) goal.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        int goalY = (int) goal.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();

        // One before goal
        double columnHeight = 0;
        int y = goalY;
        while (brickMap[BlockDude.oneDMapIndex(goalX - 1, y, mapWidth)] == 1) {
            columnHeight++;
            y++;
        }
        //double normalized = normalize((int)columnHeight, 0, mapHeight - 1);

        vector.add(columnHeight);
    }
}