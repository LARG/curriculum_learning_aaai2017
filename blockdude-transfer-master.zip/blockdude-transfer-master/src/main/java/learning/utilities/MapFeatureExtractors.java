package learning.utilities;

import learning.transfer.curriculum.BlockDudeMap;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MapFeatureExtractors {

    /**
     Extracts features describing a map.

     @param map
     @return
     */
    public static List<Double> extract(int[][] map) {
        int moreThanZeroBlocksPresent = numBlocks(map) > 0 ? 0 : 2;
        int mapWidth = map.length;
        int mapHeight = map[0].length;
        List<Double> columnsOfHeights = MapFeatureExtractors.numColumnsOfAHeightUpTo(map, 4);

        List<Double> features = new LinkedList<>();
        features.add((double) mapWidth);
        features.add((double) mapHeight);
        features.add((double) moreThanZeroBlocksPresent);

        // A column of height 3 has a lot in common with a column of height 2
        // as far as increasing the difficulty of the map and increasing the state space.
        // We'll make the feature be the sum of the number of all column heights
        // less than or equal to a particular height
        List<Double> columnsOfHeightsDescriptor = new LinkedList<>();
        for (int i = 0; i < columnsOfHeights.size(); i++) {
            if (columnsOfHeights.get(i) == 0) {
                columnsOfHeightsDescriptor.add(1.0);
                continue;
            }
            columnsOfHeightsDescriptor.add(2.0);
            // We allow this feature to cascade: a column of height 2 will also
            // activate the feature for a column of height 1
            for (int j = 0; j < i; j++) {
                columnsOfHeightsDescriptor.set(j, 2.0);
            }
        }

        features.addAll(columnsOfHeightsDescriptor);
        return features;
    }

    /**
     Counts the number of blocks in the map.

     @param map
     @return the number of blocks in the map
     */
    public static int numBlocks(int[][] map) {
        int count = 0;
        for (int[] column : map) {
            for (int item : column) {
                if (item == BlockDudeMap.BLOCK) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Counts the number of columns of a height.
     *
     * @param map
     * @param heightsUpTo the maximum (inclusive) column height to count
     * @return a list where the first element is the number of columns of height one,
     * and the last element is the number of columns of height `heightsUpTo`
     */
    public static List<Double> numColumnsOfAHeightUpTo(int[][] map, int heightsUpTo) {
        // The list where we'll store the results
        List<Double> heights = new ArrayList<>();
        for (int i = 0; i < heightsUpTo; i++) {
            heights.add(0.0);
        }
        final int mapHeight = map.length;
        final int mapWidth = map[0].length;

        // ignore the first and last space as they are just full of padding bricks
        for (int column = 1; column < mapHeight - 1; column++) {
            double height = 0;
            for (int i = 1; i < mapWidth - 1; i++) {
                // We're only counting bricks. If empty space, an exit, or other
                // things get in the way, we're done counting.
                if (map[column][i] != BlockDudeMap.BRICK) {
                    break;
                }
                height += 1;
            }
            // If we actually had more than zero bricks and the height is
            // in the range that we care about, add it to the count
            if (height > 0 && height <= heightsUpTo) {
                heights.set((int) height, heights.get((int) height) + 1.0);
            }
        }
        return heights;
    }

    /**
     * Old implementation
     *
     * @param map
     * @return
     */
    public static List<Double> extractOldFormulation(int[][] map) {
        int numBlocks = numBlocks(map);
        int mapWidth = map.length;
        int mapHeight = map[0].length;
        int startToGoalDistance = startToGoalDistance(map);
        List<Double> columnHeights = MapFeatureExtractors.numColumnsOfAHeightUpTo(map, 4);

        List<Double> features = new LinkedList<>();
        features.add((double) mapWidth);
        features.add((double) mapHeight);
        features.add((double) numBlocks);
        features.add((double) startToGoalDistance);

        // A column of height 3 has a lot in common with a column of height 2
        // as far as increasing the difficulty of the map and increasing the state space.
        // We'll make the feature be the sum of the number of all column heights
        // less than or equal to a particular height
        for (int i = 0; i < columnHeights.size(); i++) {
            for (int j = 0; j < i; j++) {
                columnHeights.set(j, columnHeights.get(j) + columnHeights.get(i));
            }
        }
        features.addAll(columnHeights);
        return features;
    }

    /**
     * The distance between the agent's start position and the goal.
     *
     * @param map
     * @return
     */
    public static int startToGoalDistance(int[][] map) {
        int goalX = -1;
        int startX = -1;
        for (int column = 1; column < map.length - 1; column++) {
            for (int i = 1; i < map[0].length - 1; i++) {
                int item = map[column][i];
                if (item == BlockDudeMap.STARTEAST || item == BlockDudeMap.STARTWEST) {
                    startX = column;
                } else if (item == BlockDudeMap.EXIT) {
                    goalX = column;
                }
            }
        }
        return goalX - startX;
    }

    /**
     Extracts the binary feature descriptor as a bitfield stored in an int.

     @param map
     @return
     */
    public static int extractBinaryFeatureDescriptorInt(int[][] map) {
        List<Boolean> binary = extractBinaryFeatureDescriptor(map);
        int result = 0;
        for (int i = 0; i < binary.size(); i++) {
            result |= (binary.get(i) ? 1 : 0) << i;
        }
        return result;
    }

    /**
     Extracts a binary representation of a map's feature vector

     @param map
     @return
     */
    public static List<Boolean> extractBinaryFeatureDescriptor(int[][] map) {
        int numBlocks = numBlocks(map);
        int mapWidth = map.length;
        int mapHeight = map[0].length;
        List<Double> columnsOfHeights = MapFeatureExtractors.numColumnsOfAHeightUpTo(map, 4);

        // Because our map features are not simply the presence or absence
        // of a particular mechanic or obstacle, we must set thresholds
        // to obtain the binary feature descriptor.
        List<Boolean> features = new LinkedList<>();
        features.add(numBlocks > 0);
        features.add(mapWidth > 10);
        features.add(mapHeight > 10);

        List<Boolean> columnsOfHeightsDescriptor = new LinkedList<>();
        for (int i = 0; i < columnsOfHeights.size(); i++) {
            if (columnsOfHeights.get(i) == 0) {
                columnsOfHeightsDescriptor.add(false);
                continue;
            }
            columnsOfHeightsDescriptor.add(true);
            // We allow this feature to cascade: a column of height 2 will also
            // activate the feature for a column of height 1
            for (int j = 0; j < i; j++) {
                columnsOfHeightsDescriptor.set(j, true);
            }
        }

        features.addAll(columnsOfHeightsDescriptor);
        return features;
    }

    /**
     * Old formulation based on previous feature descriptors. Extracts a binary representation of a map's feature vector
     *
     * @param map
     * @return
     */
    public static List<Boolean> extractBinaryFeatureDescriptorOldFormulation(int[][] map) {
        int numBlocks = numBlocks(map);
        int mapWidth = map.length;
        int mapHeight = map[0].length;
        int startToGoalDistance = startToGoalDistance(map);
        List<Double> columnHeights = MapFeatureExtractors.numColumnsOfAHeightUpTo(map, 3);

        // Because our map features are not simply the presence or absence
        // of a particular mechanic or obstacle, we must set thresholds
        // to obtain the binary feature descriptor.
        List<Boolean> features = new LinkedList<>();
        features.add(numBlocks > 0);
        features.add(mapWidth > 8);
        features.add(mapHeight > 10);
        features.add(startToGoalDistance > 8);

        for (double height : columnHeights) {
            features.add(height > 0);
        }
        return features;
    }
}
