package learning.utilities;

import java.nio.file.Path;

public class ExperimentOutPaths {
    public final Path visualizationPath;
    public final Path vfaPath;
    public final Path dataPath;
    public final Path plotsPath;
    public final Path base;

    public ExperimentOutPaths(Path base) {
        this.base = base;
        visualizationPath = base.resolve("visualization");
        vfaPath = base.resolve("vfa");
        dataPath = base.resolve("data");
        plotsPath = base.resolve("plots");
    }

}
