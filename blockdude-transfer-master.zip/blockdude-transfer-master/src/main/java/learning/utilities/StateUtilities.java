package learning.utilities;

import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import learning.transfer.curriculum.BlockDudeMap;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class StateUtilities {


    public static int perceptionShellSize(final int depth){
        int shellSideLength = depth * 2 + 1;
        return shellSideLength * shellSideLength;
    }

    public static List<Integer> getPerceptionShell(State s, final int depth, final int mapWidth) {
        List<Integer> perceptions = new ArrayList<>();
        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        List<ObjectInstance> blocks = s.getObjectsOfClass(BlockDude.CLASSBLOCK);
        int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        int agentY = (int) agentObj.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();
        int shellMinX = agentX - depth;
        int shellMinY = agentY - depth;

        int shellSideLength = depth * 2 + 1;

        int[] brickMap = s.getObjectsOfClass(BlockDude.CLASSBRICKS).get(0).getIntArrayValForAttribute(BlockDude.ATTMAP);

        final int mapHeight = brickMap.length / mapWidth;

        // Beginning from the top left of the perceptions,
        // iterate over each cell and check if there's a brick.
        // If the index is out of bounds, just append a brick.
        for (int y = 0; y < shellSideLength; y++) {
            for (int x = 0; x < shellSideLength; x++) {
                int index = brickMapIndexForCoordinates(shellMinX + x, shellMinY + y, mapHeight, mapWidth);
                if (index == -1) {
                    // Out of bounds. Add a brick.
                    perceptions.add(BlockDudeMap.BRICK);
                } else {
                    // If the brickmap has a brick or a goal, add it
                    if (brickMap[index] == BlockDudeMap.BRICK || brickMap[index] == BlockDudeMap.EXIT) {
                        perceptions.add(brickMap[index]);
                    } else {
                        perceptions.add(0);
                    }
                }
            }
        }


        for (ObjectInstance block : blocks) {
            int blockX = (int) block.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
            int blockY = (int) block.getValueForAttribute(BlockDude.ATTY).getNumericRepresentation();


            int index = shellIndexForCoordinates(shellMinX, shellMinY, depth, blockX, blockY);
            if (index != -1) {
                // This space in the index must have an empty space because
                // a space can't have both a brick and a block
                assert (perceptions.get(index) == 0 || perceptions.get(index) == BlockDudeMap.EXIT);
                perceptions.set(index, BlockDudeMap.BLOCK);
            }
        }

        // The index that represents the space where the agent is should only
        // ever be empty, or contain the goal marker
        assert (perceptions.get(perceptions.size() / 2) == 0 || perceptions.get(perceptions.size() / 2) == BlockDudeMap.EXIT);

        return perceptions;
    }

    public static int shellIndexForCoordinates(final int shellOriginX, final int shellOriginY, final int shellDepth, final int x, final int y) {
        int shellSideLength = shellDepth * 2 + 1;
        int shellMaxX = shellOriginX + shellSideLength;
        int shellMaxY = shellOriginY + shellSideLength;
        if (x >= shellOriginX && x < shellMaxX
                && y >= shellOriginY && y < shellMaxY) {
            int shellIndexX = x - shellOriginX;
            int shellIndexY = y - shellOriginY;
            return shellIndexY * shellSideLength + shellIndexX;
        } else {
            return -1;
        }
    }

    private static int brickMapIndexForCoordinates(final int x, final int y, final int mapHeight, final int mapWidth) {
        if (x < 0 || y < 0) {
            return -1;
        } else if (y >= mapHeight || x >= mapWidth) {
            return -1;
        } else {
            return BlockDude.oneDMapIndex(x, y, mapWidth);
        }
    }

    public static List<Integer> getPerceptionShellNoDiagonals(State s, final int depth, final int mapWidth) {
        List<Integer> originalShell = getPerceptionShell(s, depth, mapWidth);
        List<Integer> finalShell = new LinkedList<>();
        final int shellSideLength = depth * 2 + 1;
        final int midIndex = depth;
        for (int row = 0; row < shellSideLength; row++) {
            if (row != midIndex) {
                int oldIndex = shellIndexForCoordinates(0, 0, depth, midIndex, row);
                finalShell.add(originalShell.get(oldIndex));
                continue;
            }
            for (int i = 0; i < shellSideLength; i++) {
                if (i == midIndex) {
                    continue;
                }
                int oldIndex = shellIndexForCoordinates(0, 0, depth, i, midIndex);
                finalShell.add(originalShell.get(oldIndex));
            }
        }
        return finalShell;
    }

    /**
     * Prepare the BlockDude world with a map state
     *
     * @param domain
     * @param nb
     * @param map
     * @return
     */
    public static State initializeState(Domain domain, int nb, int[][] map) {
        boolean exitSeen = false;
        boolean agentSeen = false;
        State s = BlockDude.getUninitializedState(domain, nb);
        int blockNum = 0;
        for (int i = 0; i < map.length; i++) {
            int[] column = map[i];
            for (int j = 0; j < column.length; j++) {
                switch (column[j]) {
                    case BlockDudeMap.BLOCK:
                        BlockDude.setBlock(s, blockNum, i, j);
                        blockNum++;
                        break;
                    case BlockDudeMap.STARTEAST:
                        agentSeen = true;
                        BlockDude.setAgent(s, i, j, 1, false);
                        break;
                    case BlockDudeMap.STARTWEST:
                        agentSeen = true;
                        BlockDude.setAgent(s, i, j, 0, false);
                        break;
                    case BlockDudeMap.STARTEASTHOLDING:
                        agentSeen = true;
                        BlockDude.setAgent(s, i, j, 1, true);
                        break;
                    case BlockDudeMap.STARTWESTHOLDING:
                        agentSeen = true;
                        BlockDude.setAgent(s, i, j, 0, true);
                        break;
                    case BlockDudeMap.EXIT:
                        exitSeen = true;
                        BlockDude.setExit(s, i, j);
                        break;
                    case 0:
                    case BlockDudeMap.BRICK:
                        break;

                    default:
                        System.out.println("Unknown map item");
                }

            }

        }
        assert (agentSeen && exitSeen);
        // This will ignore our special items and just set all the bricks
        BlockDude.setBrickMap(s, map);
        return s;
    }

    /**
     * Generates permutations up to the max array.
     *
     * @param current
     * @param max inclusive
     * @param i
     * @param permutations
     */
    public static void generatePermutations(int[] current, int[] max, int i, List<int[]> permutations) {
        if (i == current.length) {
            permutations.add(current.clone());
            return;
        }
        for (int j = 0; j <= max[i]; j += 1) {
            current[i] = j;
            generatePermutations(current, max, i + 1, permutations);
        }
    }

}
