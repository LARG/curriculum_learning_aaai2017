package learning.experiment;


public class WeightChangeConvergenceCriteria implements ConvergenceCriteria {

    final double weightChangeThreshold;
    final int timesSeenThreshold;

    private int timesSeen;

    WeightChangeConvergenceCriteria(double weightChangeThreshold, int timesSeenThreshold) {
        this.weightChangeThreshold = weightChangeThreshold;
        this.timesSeenThreshold = timesSeenThreshold;
    }

    @Override
    public boolean converged(double maxWeightChange, int steps) {
        if (maxWeightChange < weightChangeThreshold) {
            timesSeen += 1;
        } else {
            timesSeen = 0;
        }
        return timesSeen >= timesSeenThreshold;
    }
}
