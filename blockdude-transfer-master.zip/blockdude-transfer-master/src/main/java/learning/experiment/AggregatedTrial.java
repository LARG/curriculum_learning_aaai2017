package learning.experiment;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.math3.distribution.TDistribution;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class AggregatedTrial {
    /**
     * Stores the number steps taken in a particular episode
     */
    public List<StatPair> stepsPerEpisode = new ArrayList<>();

    public StatPair meanStepsTilConvergence;
    /**
     * A list of all the evaluation agent rewards
     */
    public List<Pair<Integer, StatPair>> evaluationReward = new LinkedList<>();
    /**
     * The total number of episodes in the longest component trial
     */
    public int totalEpisodes = 0;
    public int nTrials = 0;
    private boolean finalized = false;

    public AggregatedTrial() {

    }

    public AggregatedTrial(List<StatPair> stepsPerEpisode, int n, double meanStepsToConvergence, double varianceStepsToConvergence) {
        this.stepsPerEpisode = stepsPerEpisode;
        finalized = true;
        this.nTrials = n;
        this.totalEpisodes = stepsPerEpisode.size();

        this.meanStepsTilConvergence = new StatPair(meanStepsToConvergence, varianceStepsToConvergence, n);
    }

    public static List<List<Double>> getConfidences(List<StatPair> stats, double significanceLevel, int n) {
        TDistribution tdist = new TDistribution(n - 1);
        double crit = tdist.inverseCumulativeProbability(1. - (significanceLevel / 2.));
        List<List<Double>> result = new LinkedList<>();
        for (int i = 0; i < stats.size(); i++) {
            final StatPair pair = stats.get(i);
            double width = crit * Math.sqrt(pair.variance) / Math.sqrt(n);
            double m = pair.mean;
            List<Double> entry = new LinkedList<>();
            entry.add(m);
            entry.add(m - width);
            entry.add(m + width);
            result.add(entry);
        }
        return result;

    }

    public void combineWith(LoggingEnvironmentObserver.Trial trial) {
        assert (!trial.stepsPerEpisode.isEmpty());
        assert (!trial.evaluationRewards.isEmpty());

        if (nTrials == 0) {
            nTrials += 1;
            stepsPerEpisode = toPairs(trial.stepsPerEpisode);
            evaluationReward = evaluationToPairs(trial.evaluationRewards);
            meanStepsTilConvergence = new StatPair((double) trial.totalSteps, 0.0, 1);
            totalEpisodes = stepsPerEpisode.size();
            return;
        }


        nTrials += 1;

        int newN = meanStepsTilConvergence.n + 1;
        double delta = trial.totalSteps - meanStepsTilConvergence.mean;
        final double newMean = meanStepsTilConvergence.mean + delta / (double) newN;
        final double newVariance = meanStepsTilConvergence.variance + delta * (trial.totalSteps - newMean);

        meanStepsTilConvergence = new StatPair(newMean, newVariance, newN);
        combine(trial.stepsPerEpisode, stepsPerEpisode);
        combineEvaluationRewards(trial.evaluationRewards, evaluationReward);

        totalEpisodes = Math.max(totalEpisodes, trial.totalEpisodes);
    }

    private static List<StatPair> toPairs(List<Double> means) {
        List<StatPair> pairs = new LinkedList<>();
        for (int i = 0; i < means.size(); i++) {
            StatPair pair = new StatPair(means.get(i), 0.0, 1);
            pairs.add(pair);
        }
        return pairs;
    }

    private static List<Pair<Integer, StatPair>> evaluationToPairs(List<Pair<Integer, Integer>> evaluations) {
        List<Pair<Integer, StatPair>> pairs = new LinkedList<>();
        for (int i = 0; i < evaluations.size(); i++) {
            final int index = evaluations.get(i).getLeft();
            final int reward = evaluations.get(i).getRight();
            StatPair pair = new StatPair((double) reward, 0.0, 1);
            Pair<Integer, StatPair> newEntry = new ImmutablePair<>(index, pair);
            pairs.add(newEntry);
        }
        return pairs;
    }

    private void combine(List<Double> data, List<StatPair> stats) {
        normalizeListSizes(data, stats);
        // Online mean and variance
        for (int i = 0; i < data.size(); i++) {
            final StatPair pair = stats.get(i);
            final double x = data.get(i);

            final int newN = pair.n + 1;
            final double delta = x - pair.mean;
            final double newMean = pair.mean + delta / (double) newN;
            final double newVariance = pair.variance + delta * (x - newMean);

            stats.set(i, new StatPair(newMean, newVariance, newN));
        }
    }

    private void combineEvaluationRewards(List<Pair<Integer, Integer>> data, List<Pair<Integer, StatPair>> stats) {
        normalizeListSizesExtrapolate(data, stats, data.get(1).getLeft() - data.get(0).getLeft());
        // Online mean and variance
        for (int i = 0; i < data.size(); i++) {
            final StatPair pair = stats.get(i).getRight();
            final double x = data.get(i).getRight();

            final int newN = pair.n + 1;
            final double delta = x - pair.mean;
            final double newMean = pair.mean + delta / (double) newN;
            final double newVariance = pair.variance + delta * (x - newMean);

            int stepNumber = stats.get(i).getLeft();
            stats.set(i, new ImmutablePair<>(stepNumber, new StatPair(newMean, newVariance, newN)));
        }
    }

    private static <T, U> void normalizeListSizes(List<T> data, List<U> stats) {
        if (data.size() == 0 && stats.size() == 0) {
            return;
        }
        final int maxSize = Math.max(data.size(), stats.size());
        final int minSharedIndex = Math.min(data.size(), stats.size());
        T lastDataValid = data.get(data.size() - 1);
        U lastStatsValid = stats.get(stats.size() - 1);
        for (int i = minSharedIndex; i < maxSize; i++) {
            if (i >= data.size()) {
                data.add(lastDataValid);
            } else if (i >= stats.size()) {
                stats.add(lastStatsValid);
            } else {
                assert (false);
            }
        }
        assert (data.size() == stats.size());
    }

    private static void normalizeListSizesExtrapolate(List<Pair<Integer, Integer>> data, List<Pair<Integer, StatPair>> stats, Integer extrapolateBy) {
        if (data.size() == 0 && stats.size() == 0) {
            return;
        }
        final int maxSize = Math.max(data.size(), stats.size());
        final int minSharedIndex = Math.min(data.size(), stats.size());
        Pair<Integer, Integer> lastDataValid = data.get(data.size() - 1);
        Pair<Integer, StatPair> lastStatsValid = stats.get(stats.size() - 1);
        for (int i = minSharedIndex; i < maxSize; i++) {
            if (i >= data.size()) {
                Pair<Integer, Integer> extrapolated = new ImmutablePair<>(lastDataValid.getLeft() + extrapolateBy, lastDataValid.getRight());
                data.add(extrapolated);
            } else if (i >= stats.size()) {
                Pair<Integer, StatPair> extrapolated = new ImmutablePair<>(lastStatsValid.getLeft() + extrapolateBy, lastStatsValid.getRight());
                stats.add(extrapolated);
            } else {
                assert (false);
            }
        }
        assert (data.size() == stats.size());
    }

    public void finalizeVariances() {
        assert !finalized;
        if (nTrials < 2) {
            System.out.println("Note: need more than 2 trials to get non-zero variances");
        }
        for (int i = 0; i < stepsPerEpisode.size(); i++) {
            StatPair pair = stepsPerEpisode.get(i);
            double newVariance = pair.variance / (pair.n - 1);
            stepsPerEpisode.set(i, new StatPair(pair.mean, newVariance, pair.n));

        }

        for (int i = 0; i < evaluationReward.size(); i++) {
            Pair<Integer, StatPair> pair = evaluationReward.get(i);
            final int index = pair.getLeft();
            final StatPair stat = pair.getRight();
            double newVariance = stat.variance / (stat.n - 1);

            StatPair newStat = new StatPair(stat.mean, newVariance, stat.n);
            evaluationReward.set(i, new ImmutablePair<>(index, newStat));
        }

        double newVariance = meanStepsTilConvergence.variance / (meanStepsTilConvergence.n - 1);

        StatPair newStat = new StatPair(meanStepsTilConvergence.mean, newVariance, meanStepsTilConvergence.n);
        meanStepsTilConvergence = newStat;
        finalized = true;
    }

    public static class StatPair {
        public final double mean;
        public final double variance;
        public final int n;

        public StatPair(Double mean, Double variance, int n) {
            this.mean = mean;
            this.variance = variance;
            this.n = n;
        }
    }
}
