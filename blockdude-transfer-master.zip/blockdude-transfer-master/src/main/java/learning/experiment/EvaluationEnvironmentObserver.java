package learning.experiment;

import burlap.behavior.singleagent.learning.LearningAgent;
import burlap.behavior.singleagent.learning.LearningAgentFactory;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.oomdp.auxiliary.stateconditiontest.TFGoalCondition;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.RewardFunction;
import burlap.oomdp.singleagent.common.GoalBasedRF;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;
import burlap.oomdp.singleagent.environment.EnvironmentOutcome;
import burlap.oomdp.singleagent.environment.SimulatedEnvironment;
import learning.transfer.TransferAgentFactories;
import learning.transfer.advice.AdviceFunction;
import learning.transfer.advice.LookAheadAdviceFunction;
import learning.transfer.advice.TransferFAPotentialFunction;
import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.tdmethods.GradientDescentSarsaLamTransfer;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;


public class EvaluationEnvironmentObserver implements EnvironmentObserver {

    private final BlockDudeCurriculum curriculum;
    private final LearningAgent agent;
    private final List<DifferentiableStateActionValue> sourceVfas;
    private final int evaluationPeriod;
    private final int mapNum;
    private final int maxNumSteps;
    private final double gamma;

    /**
     * The evaluation reward at a number of steps of training
     */
    private List<Pair<Integer, Integer>> evaluationRewards;

    /**
     * The current time step of the agent
     */
    private int timeStep = 0;

    public EvaluationEnvironmentObserver(BlockDudeCurriculum curriculum, LearningAgent agent, List<DifferentiableStateActionValue> sourceVfas, int mapNum, int maxNumSteps, int evaluationPeriod, double gamma) {
        this.curriculum = curriculum;
        this.agent = agent;
        this.sourceVfas = sourceVfas;
        this.evaluationPeriod = evaluationPeriod;
        this.mapNum = mapNum;
        this.maxNumSteps = maxNumSteps;
        this.gamma = gamma;

        this.evaluationRewards = new ArrayList<>();
    }

    @Override
    public void observeEnvironmentActionInitiation(State o, GroundedAction action) {
    }

    @Override
    public void observeEnvironmentInteraction(EnvironmentOutcome eo) {
        // Run an evaluation if: we're configured for evaluation and it's time
        if (evaluationPeriod != 0 && timeStep % evaluationPeriod == 0) {
            double reward = runEvaluation();
            System.out.println("Evaluation at " + timeStep + " steps: " + reward);
            evaluationRewards.add(new ImmutablePair<>(timeStep, (int) reward));
        }

        timeStep++;
    }

    @Override
    public void observeEnvironmentReset(Environment resetEnvironment) {
    }

    /**
     * @return reward for the evaluation episode
     */
    private double runEvaluation() {
        WorldComponents worldComponents = new WorldComponents(curriculum, mapNum);
        RewardFunction rf = new GoalBasedRF(new TFGoalCondition(worldComponents.tf), 50.0, -1.0);
        SimulatedEnvironment env = new SimulatedEnvironment(worldComponents.domain, rf, worldComponents.tf, worldComponents.stateGenerator);

        // Pull out the agent's VFA. This value function defines the agent's current policy.
        DifferentiableStateActionValue agentVfa = ((GradientDescentSarsaLamTransfer) agent).getVFA();

        // The evaluation agent won't be learning at all, but its value function is still biased by the potential functions it has been learning on previously.
        // We need to remove this bias in our greedy evaluation.
        AdviceFunction adviceFunction = new AdviceFunction(new LookAheadAdviceFunction(gamma), new TransferFAPotentialFunction(sourceVfas));
        LearningAgentFactory factory = TransferAgentFactories.getEvaluationAgentFactory(worldComponents.domain, agentVfa, adviceFunction, gamma);

        ConvergenceDetectingTrialRunner experimenter = new ConvergenceDetectingTrialRunner(env, null, 1, maxNumSteps, factory.generateAgent());
        LoggingEnvironmentObserver.Trial evaluation = experimenter.runEvaluation();
        double reward = evaluation.cumulativeEpisodeReward.get(0);

        // Printing out the result of the evaluation turns out to be pretty useless. It's always the maximum
        // or the converged value.
        //System.out.println("-- evaluation steps " + evaluation.cumulativeStepEpisode.get(0));

        return reward;
    }

    public void end() {
        // We always want to evaluate the agent once we've deemed it converged. We assume that a converged policy
        // will produce the same evaluation performance for any amount of additional training. With this assumption,
        // it's okay to mark this evaluation for the next planned tick mark
        double reward = runEvaluation();
        // What would have been the next evaluation index?
        int nextEvaluationIndex = (int) Math.ceil((double) timeStep / evaluationPeriod);
        // This index should have been the very next entry in the list, so the index would equal
        // the list size (which is max index + 1)
        assert nextEvaluationIndex == evaluationRewards.size();
        int step = nextEvaluationIndex * evaluationPeriod;
        assert evaluationRewards.get(evaluationRewards.size() - 1).getLeft() < step;
        evaluationRewards.add(new ImmutablePair<>(step, (int) reward));
    }

    public List<Pair<Integer, Integer>> getEvaluationRewards() {
        return evaluationRewards;
    }
}
