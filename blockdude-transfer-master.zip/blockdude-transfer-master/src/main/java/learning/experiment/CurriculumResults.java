package learning.experiment;

import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;

import java.util.Map;

public class CurriculumResults {
    final Map<BlockDudeCurriculum.Step, AggregatedTrial> transfer;
    final Map<BlockDudeMap, AggregatedTrial> scratch;
    private final BlockDudeMap finalTarget;

    public CurriculumResults(Map<BlockDudeCurriculum.Step, AggregatedTrial> transfer, Map<BlockDudeMap, AggregatedTrial> scratch, BlockDudeMap finalTarget) {
        assert (scratch.size() != 0);
        this.transfer = transfer;
        this.scratch = scratch;
        this.finalTarget = finalTarget;

    }

    public String summarize() {
        AggregatedTrial targetScratch = scratch.get(finalTarget);
        double meanTransferSource = meanTimeSpentInSourceTasks();

        AggregatedTrial targetTrial = null;
        for (BlockDudeCurriculum.Step step : transfer.keySet()) {
            if (step.target.equals(finalTarget)) {
                targetTrial = transfer.get(step);
            }
        }
        double transferTargetMean = targetTrial.meanStepsTilConvergence.mean;

        double scratchTarget = targetScratch.meanStepsTilConvergence.mean;

        double totalTransferTime = meanTransferSource + transferTargetMean;
        String description = "Curriculum total: " + totalTransferTime + " (Sources: " + meanTransferSource + ", Target: " + transferTargetMean + ")\n";
        description += "Scratch total: " + scratchTarget + "\n";
        if (scratchTarget > totalTransferTime) {
            description += "Time saved by transfer: " + (scratchTarget - totalTransferTime) + "\n";
        } else {
            description += "Time wasted in curriculum: " + (totalTransferTime - scratchTarget) + "\n";
        }
        if (transferTargetMean > scratchTarget) {
            description += "More time spent learning the target with transferred advice: negative transfer \n";
        } else if (totalTransferTime > scratchTarget) {
            description += "Target performance improved with transferred advice, but time benefit is negative: weak transfer \n";
        } else {
            description += "Curriculum time less than target scratch time: strong transfer\n";
        }
        return description;
    }

    private double meanTimeSpentInSourceTasks() {
        double meanSource = 0.0;
        for (Map.Entry<BlockDudeCurriculum.Step, AggregatedTrial> step : transfer.entrySet()) {
            if (step.getKey().target == finalTarget) {
                continue;
            }
            AggregatedTrial trial = step.getValue();
            double meanCumSteps = trial.meanStepsTilConvergence.mean;
            meanSource += meanCumSteps;
        }
        return meanSource;
    }


    public String meanStepsToConvergenceDescription() {
        String description = "";
        for (Map.Entry<BlockDudeCurriculum.Step, AggregatedTrial> entry : transfer.entrySet()) {
            BlockDudeCurriculum.Step step = entry.getKey();
            AggregatedTrial transferTrial = entry.getValue();
            AggregatedTrial scratchTrial = scratch.get(step.target);

            // If we only want the final evaluation (only-final-scratch option),
            // skip null scratch trials
            if (scratchTrial == null) {
                assert(scratch.size() == 1);
                continue;
            }

            // If we don't have information about a trial from scratch don't do the comparison
            String scratchString = "";
            if (scratchTrial != null) {
                scratchString = "Scratch: " + String.format("%.2f", scratchTrial.meanStepsTilConvergence.mean);
            }

            String transferComparisonString = "";
            if (step.sources.size() > 0) {
                transferComparisonString = " Transfer: " + String.format("%.2f", transferTrial.meanStepsTilConvergence.mean);
                // If we have both trials, give a transfer benefit indicator
                if (scratchTrial != null) {
                    if (transferTrial.meanStepsTilConvergence.mean < scratchTrial.meanStepsTilConvergence.mean) {
                        transferComparisonString += " ✓";
                    } else {
                        transferComparisonString += " X";
                    }
                }
            }

            description += step + " " + scratchString + " " + transferComparisonString + "\n";
        }
        return description;
    }
}
