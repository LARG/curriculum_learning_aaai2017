package learning.experiment;

import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.auxiliary.common.ConstantStateGenerator;
import burlap.oomdp.auxiliary.common.SinglePFTF;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.TerminalFunction;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.Action;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.statehashing.SimpleHashableStateFactory;
import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;
import learning.utilities.MapFeatureExtractors;
import learning.utilities.StateUtilities;

import java.util.List;
import java.util.stream.Collectors;

public class WorldComponents {
    public final BlockDudeCurriculum curriculum;
    public final BlockDudeMap map;
    public final BlockDude bd;
    public final Domain domain;
    public final State initialState;
    public final ConstantStateGenerator stateGenerator;
    public final SimpleHashableStateFactory stateFactory;
    public final TerminalFunction tf;


    public WorldComponents(final BlockDudeCurriculum curriculum, final int mapNum) {
        map = curriculum.mapWithIndex(mapNum);
        this.curriculum = curriculum;
        bd = new BlockDude(map.getWidth(), map.getHeight());

        domain = bd.generateDomain();

        //setup initial state
        initialState = StateUtilities.initializeState(domain, MapFeatureExtractors.numBlocks(map.representation), map.representation);

        //initial state generator
        stateGenerator = new ConstantStateGenerator(initialState);

        //set up the state hashing system for looking up states
        // The stateFactory is only used for tabular learning methods
        stateFactory = new SimpleHashableStateFactory();

        //ends when the agent reaches the exit
        tf = new SinglePFTF(domain.getPropFunction(BlockDude.PFATEXIT));
    }

    public int mapWidth() {
        return bd.getMaxx();
    }

    public int mapHeight() {
        return bd.getMaxy();
    }

    public List<GroundedAction> actions() {
        return domain.getActions().stream().map(Action::getAssociatedGroundedAction).collect(Collectors.toList());
    }
}