package learning.experiment;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.common.LinearVFA;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;
import burlap.oomdp.singleagent.environment.EnvironmentOutcome;
import learning.visualization.MapRenderer;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

public class VFAVisualizingEnvironmentObserver implements EnvironmentObserver {
    MapRenderer renderer;
    private int count;
    private Path outPath;
    private DifferentiableStateActionValue vfa;
    private List<GroundedAction> actions;

    public VFAVisualizingEnvironmentObserver(MapRenderer renderer, LinearVFA vfa, Path outPath, List<GroundedAction> actions) {
        this.renderer = renderer;
        this.outPath = outPath;
        this.actions = actions;
        this.vfa = vfa;
        count = 0;
    }

    @Override
    public void observeEnvironmentActionInitiation(State o, GroundedAction action) {
    }

    @Override
    public void observeEnvironmentInteraction(EnvironmentOutcome eo) {
        File imageOut = outPath.resolve(count + ".png").toFile();
        renderer.saveImage(eo.op, vfa, actions, imageOut);
        count++;
    }

    @Override
    public void observeEnvironmentReset(Environment resetEnvironment) {

    }
}
