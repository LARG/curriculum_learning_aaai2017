package learning.experiment;


import learning.transfer.curriculum.BlockDudeCurriculum;
import org.apache.commons.cli.CommandLine;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.Random;

public class CLIArgs {
    private static final String DEFAULT_DATA_OUT_DIR = Paths.get("results").toString();
    public final Integer curriculum;
    public final Integer episodes;
    public final Integer steps;
    public final Integer trials;
    public final Integer evaluationPeriod;
    public final double gamma;
    public final double epsilon;
    public final double alpha;
    public final double lambda;
    public final int perceptionDepth;
    public final double bandwidth;
    public final double defaultWeightValue;
    public final Advice advice;
    public final Mode mode;
    public final boolean help;
    public final boolean storeMapImages;
    public final boolean storeVisualizationData;
    public final boolean storePlots;
    public final Path logPath;
    public final Integer startStep;
    public final Integer endStep;
    public final boolean intergroupTransferDisabled;
    public final boolean largestGroupOnly;
    public final boolean onlyFinalScratch;
    public final Integer randomSeed;
    public final boolean extendFinalEvaluation;
    public final Integer keepNMapsMax;
    public final boolean largestIntergroupOnly;

    public CLIArgs(CommandLine line) {
        trials = Integer.parseInt(line.getOptionValue("trials", "50"));
        if (trials < 1) {
            throw new RuntimeException("Must specify positive number of trials");
        }
        episodes = Integer.parseInt(line.getOptionValue("episodes", "100"));
        evaluationPeriod = Integer.parseInt(line.getOptionValue("ep", "0"));
        help = line.hasOption("h");
        curriculum = nullableParseInt(line.getOptionValue("curriculum", ""));
        steps = Integer.parseInt(line.getOptionValue("steps", "200"));
        advice = Objects.equals(line.getOptionValue("advice", "ahead"), "ahead") ? Advice.Ahead : Advice.Behind;

        String modeString = line.getArgs()[0];
        switch (modeString) {
            case "visualize-episodes":
                mode = Mode.VisualizeEpisodes;
                break;
            case "curriculum":
                mode = Mode.RunHandCurriculum;
                break;
            case "visualize-maps":
                mode = Mode.SaveMapImages;
                break;
            case "save-episode-images":
                mode = Mode.SaveEpisodeImages;
                break;
            case "generate":
                mode = Mode.GenerateCurriculum;
                break;
            case "generate-with-all-maps":
                mode = Mode.GenerateCurriculumWithAllMaps;
                break;
            default:
                throw new RuntimeException("Invalid mode: " + modeString);
        }
        Integer sourceOrNull = nullableParseInt(line.getOptionValue("start-step", "NaN"));
        Integer targetOrNull = nullableParseInt(line.getOptionValue("end-step", "NaN"));

        if (curriculum != null) {
            // If no transfer startStep or target was provided, run the whole curriculum
            if (sourceOrNull == null && targetOrNull == null) {
                startStep = 0;
                endStep = BlockDudeCurriculum.withIndex(curriculum).numSteps();
            } else if (sourceOrNull != null && sourceOrNull < 0) {
                throw new RuntimeException("Must specify a valid transfer startStep");
            } else {
                startStep = sourceOrNull;
                endStep = targetOrNull;
            }
        } else {
            startStep = null;
            endStep = null;
        }
        extendFinalEvaluation = line.hasOption("efe");
        storePlots = !line.hasOption("np");
        storeMapImages = !line.hasOption("nm");
        storeVisualizationData = line.hasOption("v");

        largestGroupOnly = line.hasOption("lgo");
        intergroupTransferDisabled = line.hasOption("igt");
        largestIntergroupOnly = line.hasOption("ligo");
        keepNMapsMax = nullableParseInt(line.getOptionValue("k"));

        onlyFinalScratch = line.hasOption("ofs");
        logPath = Paths.get(line.getOptionValue("log", DEFAULT_DATA_OUT_DIR));


        alpha = .1;
        epsilon = .1;
        lambda = .9;
        gamma = .99;

        bandwidth = .1;
        defaultWeightValue = 0.0;
        perceptionDepth = 1;

        Random random = new Random();
        randomSeed = nullableParseInt(line.getOptionValue("rs", random.nextInt() + ""));

    }

    private Integer nullableParseInt(String s) {
        Integer number = null;
        try {
            number = Integer.parseInt(s);
        } catch (NumberFormatException e) {

        }
        return number;
    }

    public String toString() {
        String s = "Curriculum: " + curriculum + "\n";
        s += "Start step: " + startStep + "\n";
        s += "End step: " + endStep + "\n";
        s += "Number of trials: " + trials + "\n";
        s += "Number of episodes: " + episodes + "\n";
        s += "Max number of steps per episode: " + steps + "\n";
        s += "Evaluation period (steps): " + evaluationPeriod + "\n";
        s += "Advice mode: " + advice + "\n";
        s += "RBF bandwidth: " + bandwidth + "\n";
        s += "Learning rate: " + alpha + "\n";
        s += "Discount factor: " + gamma + "\n";
        s += "Epsilon: " + epsilon + "\n";
        s += "Lambda: " + lambda + "\n";
        s += "Intergroup transfer: " + !intergroupTransferDisabled + "\n";
        s += "Largest group only: " + largestGroupOnly + "\n";
        s += "Extend final evaluation: " + extendFinalEvaluation + "\n";
        s += "Run only final scratch: " + onlyFinalScratch + "\n";
        s += "Random seed: " + randomSeed;
        return s;

    }

    public enum Mode {
        RunHandCurriculum,
        VisualizeEpisodes,
        SaveMapImages,
        GenerateCurriculum, GenerateCurriculumWithAllMaps, SaveEpisodeImages
    }

    public enum Advice {
        Ahead,
        Behind;

        @Override
        public String toString() {
            return this == Ahead ? "Look ahead" : "Look back";
        }
    }
}
