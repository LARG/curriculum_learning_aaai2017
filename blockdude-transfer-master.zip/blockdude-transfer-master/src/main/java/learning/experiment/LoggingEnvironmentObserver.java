package learning.experiment;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;
import burlap.oomdp.singleagent.environment.EnvironmentOutcome;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;

public class LoggingEnvironmentObserver implements EnvironmentObserver {

    /**
     Contains all the current trial performance data
     */
    public Trial trial;


    /**
     Whether the data from action observations received should be recoreded or not.
     */
    protected boolean collectData = false;


    /**
     The last time step at which the plots' series data was updated
     */
    protected int lastTimeStepUpdate = 0;

    /**
     The last episode at which the plot's series data was updated
     */
    protected int lastEpisode = 0;




    /**
     the current time step that was recorded
     */
    protected int curTimeStep = 0;

    /**
     the current time step that was recorded for the current episode
     */
    protected int curEpisodeTimeStep = 0;

    /**
     the current episode that was recorded
     */
    protected int curEpisode = 0;


    public LoggingEnvironmentObserver() {
        this.trial = new Trial();
    }

    /**
     * Computes the sum of the last entry in list and the value v and adds it to the end of list. Use for maintainly cumulative data.
     *
     * @param list the list to add and append to.
     * @param v    the value to add to the last value of list and append
     */
    protected static void accumulate(List<Double> list, double v) {
        if (list.size() > 0) {
            v += list.get(list.size() - 1);
        }
        list.add(v);
    }

    @Override
    public void observeEnvironmentActionInitiation(State o, GroundedAction action) {
    }

    @Override
    synchronized public void observeEnvironmentInteraction(EnvironmentOutcome eo) {
        if (!this.collectData) {
            return;
        }

        this.trial.stepIncrement(eo.r);
        this.curEpisodeTimeStep++;
        this.curTimeStep++;
    }

    @Override
    public void observeEnvironmentReset(Environment resetEnvironment) {
    }

    /**
     Informs that a new trial of the current agent is beginning.
     */
    synchronized public void start() {
        this.trial = new Trial();
        this.lastTimeStepUpdate = 0;
        this.lastEpisode = 0;
        this.curTimeStep = 0;
        this.curEpisodeTimeStep = 0;
        this.curEpisode = 0;
    }

    /**
     Informs that all data for the current trial as been collected.
     */
    public void end() {
    }

    /**
     Toggle whether performance data collected from the action observation is recorded or not

     @param collectData true if data collected should be plotted; false if not.
     */
    public void toggleDataCollection(boolean collectData) {
        this.collectData = collectData;
    }

    /**
     Informs the plotter that all data for the last episode has been collected.
     */
    synchronized public void endEpisode() {
        this.trial.setupForNewEpisode();
        this.curEpisodeTimeStep = 0;
        this.curEpisode++;
    }

    public int getCurEpisodeTimeStep() {
        return curEpisodeTimeStep;
    }

    /**
     A datastructure for maintaining all the metric stats for a single trial.

     @author James MacGlashan
     */
    public static class Trial {

        /**
         * Stores the cumulative reward by episode
         */
        public List<Double> cumulativeEpisodeReward = new ArrayList<>();


        /**
         Stores the steps by episode
         */
        public List<Double> stepsPerEpisode = new ArrayList<>();


        /**
         The cumulative reward of the episode so far
         */
        public double curEpisodeReward = 0.;

        /**
         The number of steps in the episode so far
         */
        public int curEpisodeSteps = 0;

        /**
         the total number of steps in the trial
         */
        public int totalSteps = 0;

        /**
         The total number of episodes in the trial
         */
        public int totalEpisodes = 0;
        /**
         * A list of all the evaluation agent rewards
         */
        public List<Pair<Integer, Integer>> evaluationRewards = new ArrayList<>();
        /**
         A list of the reward sequence in the current episode
         */
        protected List<Double> curEpisodeRewards = new ArrayList<>();

        /**
         Updates all datastructures with the reward received from the last step

         @param r the last reward received
         */
        public void stepIncrement(double r) {

            this.curEpisodeReward += r;
            this.curEpisodeSteps++;
            this.curEpisodeRewards.add(r);
        }


        /**
         Completes the last episode and sets up the datastructures for the next episode
         */
        public void setupForNewEpisode() {
            accumulate(this.cumulativeEpisodeReward, this.curEpisodeReward);


            this.stepsPerEpisode.add((double) this.curEpisodeSteps);

            this.totalSteps += this.curEpisodeSteps;
            this.totalEpisodes++;

            this.curEpisodeReward = 0.;
            this.curEpisodeSteps = 0;

            this.curEpisodeRewards.clear();

        }


    }

}
