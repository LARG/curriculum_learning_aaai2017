package learning.experiment;

import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.learning.LearningAgent;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;

import java.util.List;

public interface TrialRunner {
    LoggingEnvironmentObserver.Trial run();

    void addEnvironmentObserver(EnvironmentObserver observer);

    LearningAgent getLearnedAgent();

    List<EpisodeAnalysis> getEpisodeAnalysis();

    int numStepsLeft();

}
