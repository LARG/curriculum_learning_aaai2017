package learning.experiment;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;
import burlap.oomdp.singleagent.environment.EnvironmentOutcome;
import learning.transfer.vfa.VFAVersioner;
import learning.transfer.vfa.VersionableLinearVFA;


public class VFAVersioningEnvironmentObserver implements EnvironmentObserver {
    VFAVersioner versioner;
    VersionableLinearVFA vfa;

    public VFAVersioningEnvironmentObserver(VersionableLinearVFA vfa, VFAVersioner versioner) {
        this.vfa = vfa;
        this.versioner = versioner;
        versioner.addBucket();
    }

    @Override
    public void observeEnvironmentActionInitiation(State o, GroundedAction action) {

    }

    @Override
    public void observeEnvironmentInteraction(EnvironmentOutcome eo) {
        versioner.saveSnapshot(vfa);
    }

    @Override
    public void observeEnvironmentReset(Environment resetEnvironment) {
        versioner.addBucket();
    }
}
