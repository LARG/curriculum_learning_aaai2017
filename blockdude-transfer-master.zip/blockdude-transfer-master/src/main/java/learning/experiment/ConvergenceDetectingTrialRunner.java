package learning.experiment;

import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.learning.LearningAgent;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentObserver;
import burlap.oomdp.singleagent.environment.EnvironmentServer;
import learning.transfer.tdmethods.GradientDescentSarsaLamTransfer;

import java.util.ArrayList;
import java.util.List;


public class ConvergenceDetectingTrialRunner implements TrialRunner {

    public ConvergenceCriteria convergenceCriteria;
    /**
     * Whether the experimenter has completed.
     */
    protected boolean completedExperiment = false;
    /**
     * The test {@link Environment} in which experiments will be performed.
     */
    private Environment testEnvironment;
    /**
     * The {@link EnvironmentServer} that wraps the test {@link Environment}
     * and tells a {@link burlap.behavior.singleagent.auxiliary.performance.PerformancePlotter} about the individual interactions.
     */
    private EnvironmentServer environmentSever;
    /**
     *
     */
    private LearningAgent agent;
    /*
     * The environment observer
     */
    private LoggingEnvironmentObserver loggingEnvironmentObserver;
    private EvaluationEnvironmentObserver evaluationEnvironmentObserver;
    /**
     * The maximum number of episodes that the agent will be allowed, in the case that convergence is not detected
     * during training
     */
    private int numberOfEpisodesLimit;
    private int maxNumSteps;
    private LearningAgent learnedAgent = null;
    private List<EpisodeAnalysis> episodeAnalysisList;
    /**
     * Initializes.
     *
     * @param testEnvironment the test {@link Environment} in which experiments will be performed.
     * @param agent    factories to generate the agents to be tested.
     */
    public ConvergenceDetectingTrialRunner(Environment testEnvironment, EvaluationEnvironmentObserver eeo, int numberOfEpisodesLimit, int maxNumSteps, LearningAgent agent) {

        this.numberOfEpisodesLimit = numberOfEpisodesLimit;
        this.testEnvironment = testEnvironment;
        this.agent = agent;
        this.maxNumSteps = maxNumSteps;
        this.loggingEnvironmentObserver = new LoggingEnvironmentObserver();
        this.episodeAnalysisList = new ArrayList<>();
        convergenceCriteria = new TimesSeenConvergenceCriteria(10);
        this.environmentSever = new EnvironmentServer(this.testEnvironment, loggingEnvironmentObserver);
        this.evaluationEnvironmentObserver = eeo;
    }


    /**
     * Starts the experiment.
     */
    public LoggingEnvironmentObserver.Trial run() {

        if (this.completedExperiment) {
            System.out.println("Experiment was already run and has completed. If you want to run a new experiment create a new Experiment object.");
            return null;
        }

        LearningAgent resultingAgent = this.runEpisodeLimitedTrial(this.agent);

        learnedAgent = resultingAgent;


        this.completedExperiment = true;

        return loggingEnvironmentObserver.trial;

    }

    @Override
    public void addEnvironmentObserver(EnvironmentObserver observer) {
        this.environmentSever.addObservers(observer);
    }

    @Override
    public LearningAgent getLearnedAgent() {
        return learnedAgent;
    }

    @Override
    public List<EpisodeAnalysis> getEpisodeAnalysis() {
        return episodeAnalysisList;
    }

    public int numStepsLeft() {
        return maxNumSteps - loggingEnvironmentObserver.getCurEpisodeTimeStep();
    }

    /**
     * Runs a trial with the agent, executing up to maxNumEpisodes episodes.
     * @param agent the agent to use
     * @return the agent after it has finished learning
     */
    protected LearningAgent runEpisodeLimitedTrial(final LearningAgent agent) {

        //temporarily disable plotter data collection to avoid possible contamination for any actions taken by the agent generation
        //(e.g., if there is pre-test training)
        this.loggingEnvironmentObserver.toggleDataCollection(false);


        final GradientDescentSarsaLamTransfer gdAgent = (GradientDescentSarsaLamTransfer) agent;

        this.loggingEnvironmentObserver.toggleDataCollection(true); //turn it back on to begin

        this.loggingEnvironmentObserver.start();

        int episodeNum = 0;

        // Run the episodes
        while (episodeNum < numberOfEpisodesLimit) {
            EpisodeAnalysis ea = agent.runLearningEpisode(this.environmentSever, this.maxNumSteps);
            final double maxWeightChangeInLastEpisode = gdAgent.getMaxWeightChangeInLastEpisode();
            final int numSteps = ea.numTimeSteps();
            this.loggingEnvironmentObserver.endEpisode();
            this.environmentSever.resetEnvironment();
            this.episodeAnalysisList.add(ea);

            if (episodeNum % 10 == 0) {
                System.out.println("episode " + episodeNum + " steps " + numSteps + " max change: " + maxWeightChangeInLastEpisode);
            }

            if (convergenceCriteria.converged(maxWeightChangeInLastEpisode, numSteps)) {
                System.out.println("** convergence at episode " + episodeNum + " with " + numSteps + " steps");
                break;
            }

            episodeNum++;
        }

        this.loggingEnvironmentObserver.end();
        this.evaluationEnvironmentObserver.end();

        return agent;

    }

    public LoggingEnvironmentObserver.Trial runEvaluation() {
        this.loggingEnvironmentObserver.toggleDataCollection(false);

        this.loggingEnvironmentObserver.toggleDataCollection(true); //turn it back on to begin

        this.loggingEnvironmentObserver.start();

        EpisodeAnalysis ea = agent.runLearningEpisode(this.environmentSever, this.maxNumSteps);
        episodeAnalysisList.add(ea);

        this.loggingEnvironmentObserver.endEpisode();
        this.environmentSever.resetEnvironment();
        this.loggingEnvironmentObserver.end();
        return loggingEnvironmentObserver.trial;


    }

}

