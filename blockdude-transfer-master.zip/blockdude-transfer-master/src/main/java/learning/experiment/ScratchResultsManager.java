package learning.experiment;

import learning.transfer.curriculum.BlockDudeMap;
import learning.utilities.DataUtilities;
import learning.utilities.FileUtilities;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

public class ScratchResultsManager {

    /**
     * Saves a trial on the condition that it is better than any data for the same map that exists on disk
     *
     * @param map
     * @param trial
     * @param cacheDir
     * @return
     */
    public static boolean saveResultsIfMoreTrials(BlockDudeMap map, AggregatedTrial trial, Path cacheDir) {
        AggregatedTrial savedTrial = loadResults(map, trial.nTrials, cacheDir);

        if (savedTrial != null) {
            return false;
        } else {
            saveResults(map, trial, cacheDir);
            return true;
        }
    }

    public static AggregatedTrial loadResults(BlockDudeMap map, final int minNumTrials, Path cacheDir) {
        int hash = Arrays.deepHashCode(map.representation);

        File file = cacheDir.resolve("" + hash + ".csv").toFile();
        File stepwise = cacheDir.resolve("" + hash + "-stepwise.csv").toFile();

        if (file != null && stepwise != null) {
            try {
                List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
                List<String> stepwiseLines = Files.readAllLines(stepwise.toPath(), StandardCharsets.UTF_8);
                AggregatedTrial trial = DataUtilities.readEpisodeInformation(lines);
                trial.evaluationReward = DataUtilities.readStepwiseInformation(stepwiseLines, trial.nTrials);
                if (trial.nTrials >= minNumTrials) {
                    return trial;
                } else {
                    return null;
                }
            } catch (IOException e) {
                return null;
            }
        } else {
            return null;
        }
    }

    public static void saveResults(BlockDudeMap map, AggregatedTrial trial, Path cacheDir) {
        int hash = Arrays.deepHashCode(map.representation);
        String fileNameStart = "" + hash;
        Path episodeWiseOutPath = cacheDir.resolve(fileNameStart + ".csv");
        Path stepWiseOutPath = cacheDir.resolve(fileNameStart + "-stepwise.csv");

        if (episodeWiseOutPath.toFile().exists()) {
            // Clear any existing cached
            FileUtilities.deleteFile(episodeWiseOutPath);
            FileUtilities.deleteFile(stepWiseOutPath);
        }

        DataUtilities.writeTrialToCSV(trial, episodeWiseOutPath, true);
        DataUtilities.writeTrialToCSV(trial, stepWiseOutPath, false);
    }
}
