package learning.experiment;

public class TimesSeenConvergenceCriteria implements ConvergenceCriteria {
    final int threshold;

    private int lastSeen;
    private int timesSeen;

    public TimesSeenConvergenceCriteria(int timesSeenThreshold) {
        this.threshold = timesSeenThreshold;
    }

    @Override
    public boolean converged(double maxWeightChange, int steps) {
        // Assumption: Maps require fewer than 50 steps to solve
        if (lastSeen == steps && steps < 50) {
            timesSeen += 1;
        } else {
            timesSeen = 1;
        }
        lastSeen = steps;
        return timesSeen >= threshold;
    }
}
