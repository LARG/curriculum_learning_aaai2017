package learning.experiment;

import org.apache.commons.cli.*;

public class CLI {


    public static CommandLine parseArgs(String args[]) {
        Options options = createOptions();

        CommandLineParser parser = new DefaultParser();
        CommandLine line;
        try {
            line = parser.parse(options, args);
        } catch (Exception e) {
            System.err.println("Unable to parse arguments.");
            System.exit(-1);
            return null; //To satisfy code completions. Exit is noreturn
        }
        return line;
    }

    public static Options createOptions() {
        Options options = new Options();
        options.addOption(new Option("h", "help", false, "print usage information"));
        options.addOption(new Option("m", "mode", true, "visualize, advantage or curriculum"));
        options.addOption(new Option("a", "agents", true, "which agents to use"));
        options.addOption(new Option("ad", "advice", true, "ahead or back, corresponding to look-ahead and look-back advice"));

        options.addOption(new Option("n", "trials", true, "number of trials per agent"));
        options.addOption(new Option("s", "steps", true, "max number of steps per episode"));
        options.addOption(new Option("e", "episodes", true, "number of episodes per trial"));
        options.addOption(new Option("c", "curriculum", true, "Index of the curriculum to run"));
        options.addOption(new Option("v", "visualize", false, "write out visualization data"));
        options.addOption(new Option("s", "start-step", true, "Index of the first step of the curriculum that will run"));
        options.addOption(new Option("t", "end-step", true, "Index of the last step of the curriculum that will run"));
        options.addOption(new Option("ep", "evaluation-period", true, "Number of steps between each evaluation"));

        options.addOption(new Option("l", "log", true, "directory to output results data"));
        options.addOption(new Option("np", "no-plots", false, "disables plot saving"));
        options.addOption(new Option("nm", "no-map-images", false, "disables saving of map images"));
        options.addOption(new Option("rs", "random-seed", true, "set the seed for the random number generator"));

        options.addOption(new Option("ofs", "only-final-scratch", false, "disables scratch for all maps but the final"));
        options.addOption(new Option("efe", "extend-final-evaluation", false, "disables scratch for all maps but the final"));

        options.addOption(new Option("igt", "intergroup-transfer-off", false, "disables inter-group-transfer"));
        options.addOption(new Option("lgo", "largest-group-only", false, "only uses the largest group during curriculum generation"));
        options.addOption(new Option("ligo", "largest-intergroup-only", false, "only uses the edges to the most popular intergroup target during curriculum generation"));
        return options;
    }
}