package learning.experiment;

public interface ConvergenceCriteria {
    boolean converged(double maxWeightChange, int steps);
}
