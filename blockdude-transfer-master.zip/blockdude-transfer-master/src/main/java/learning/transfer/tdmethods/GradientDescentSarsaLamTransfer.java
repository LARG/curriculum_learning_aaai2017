package learning.transfer.tdmethods;

import burlap.behavior.learningrate.ConstantLR;
import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.learning.tdmethods.vfa.GradientDescentSarsaLam;
import burlap.behavior.singleagent.options.Option;
import burlap.behavior.singleagent.options.support.EnvironmentOptionOutcome;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.FunctionGradient;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.environment.Environment;
import burlap.oomdp.singleagent.environment.EnvironmentOutcome;
import learning.transfer.advice.AdviceFunction;
import learning.transfer.policy.BiasedEpsilonGreedy;
import learning.transfer.vfa.VFAVersioner;

import java.util.*;

public class GradientDescentSarsaLamTransfer extends GradientDescentSarsaLam implements NextActionDeducible {

    public GradientDescentSarsaLamTransfer(Domain domain, double gamma, DifferentiableStateActionValue vfa, double learningRate, double lambda, double epsilon, AdviceFunction adviceFunction) {
        super(domain, gamma, vfa, learningRate, lambda);
        this.GDSLInit(domain, gamma, vfa, learningRate, new BiasedEpsilonGreedy(this, epsilon, 0.999, adviceFunction), Integer.MAX_VALUE, lambda);
        this.learningRate = new ConstantLR(learningRate);
        //this.learningRate = new ExponentialDecayLR(learningRate, 1.0, learningRate);
        this.useReplacingTraces = true;
    }

    @Override
    public GroundedAction nextAction(State stateprime) {
        return (GroundedAction) learningPolicy.getAction(stateprime);
    }

    public DifferentiableStateActionValue getVFA() {
        return this.vfa;
    }

    @Override
    public EpisodeAnalysis runLearningEpisode(Environment env, int maxSteps) {

        State initialState = env.getCurrentObservation();

        EpisodeAnalysis ea = new EpisodeAnalysis(initialState);
        maxWeightChangeInLastEpisode = 0.;

        State curState = initialState;
        eStepCounter = 0;
        Map<Integer, EligibilityTraceVector> traces = new HashMap<Integer, EligibilityTraceVector>();

        // Create bucket for every episode
        if (vfa instanceof VFAVersioner) {
            ((VFAVersioner) vfa).addBucket();
        }

        GroundedAction action = (GroundedAction) this.learningPolicy.getAction(curState);
        while (!env.isInTerminalState() && (eStepCounter < maxSteps || maxSteps == -1)) {

            //get Q-value and gradient
            double curQ = this.vfa.evaluate(curState, action);
            FunctionGradient gradient = this.vfa.gradient(curState, action);

            //execute our action choice
            EnvironmentOutcome eo = action.executeIn(env);
            State nextState = eo.op;

            //determine next Q-value for outcome state
            GroundedAction nextAction = (GroundedAction) this.learningPolicy.getAction(nextState);
            double nextQV = 0.;
            if (!eo.terminated) {
                nextQV = this.vfa.evaluate(nextState, nextAction);
            }

            //manage option specifics
            double r = eo.r;
            double discount = eo instanceof EnvironmentOptionOutcome ? ((EnvironmentOptionOutcome) eo).discount : this.gamma;
            int stepInc = eo instanceof EnvironmentOptionOutcome ? ((EnvironmentOptionOutcome) eo).numSteps : 1;
            eStepCounter += stepInc;

            if (action.action.isPrimitive() || !this.shouldAnnotateOptions) {
                ea.recordTransitionTo(action, nextState, r);
            } else {
                ea.appendAndMergeEpisodeAnalysis(((Option) action.action).getLastExecutionResults());
            }

            //compute function delta
            double delta = r + (discount * nextQV) - curQ;


            //manage replacing traces by zeroing out features for actions
            //also zero out selected action, since it will be put back in later code
            if (this.useReplacingTraces) {
                List<GroundedAction> allActions = this.getAllGroundedActions(curState);
                for (GroundedAction oa : allActions) {

                    //get non-zero parameters and zero them
                    this.vfa.evaluate(curState, oa);
                    FunctionGradient ofg = this.vfa.gradient(curState, oa);
                    for (FunctionGradient.PartialDerivative pds : ofg.getNonZeroPartialDerivatives()) {
                        EligibilityTraceVector et = traces.get(pds.parameterId);
                        if (et != null) {
                            et.eligibilityValue = 0.;
                        } else {
                            //no trace for this yet, so add it
                            et = new EligibilityTraceVector(pds.parameterId, this.vfa.getParameter(pds.parameterId), 0.);
                            traces.put(pds.parameterId, et);
                        }
                    }

                }
            } else {
                assert (false);

            }


            //scan through trace elements, update them, and update parameter
            double learningRate = 0.;
            if (!this.useFeatureWiseLearningRate) {
                learningRate = this.learningRate.pollLearningRate(this.totalNumberOfSteps, curState, action);
            }

            Set<Integer> deletedSet = new HashSet<Integer>();
            for (EligibilityTraceVector et : traces.values()) {
                if (this.useFeatureWiseLearningRate) {
                    learningRate = this.learningRate.pollLearningRate(this.totalNumberOfSteps, et.weight);
                }

                et.eligibilityValue += gradient.getPartialDerivative(et.weight);
                double newParam = vfa.getParameter(et.weight) + learningRate * delta * et.eligibilityValue;
                this.vfa.setParameter(et.weight, newParam);

                double deltaW = Math.abs(et.initialWeightValue - newParam);
                if (deltaW > maxWeightChangeInLastEpisode) {
                    maxWeightChangeInLastEpisode = deltaW;
                }

                //now decay and delete from tracking if too small
                et.eligibilityValue *= this.lambda * discount;
                if (et.eligibilityValue < this.minEligibityForUpdate) {
                    deletedSet.add(et.weight);
                }


            }

            //delete traces marked for deletion
            for (Integer t : deletedSet) {
                traces.remove(t);
            }


            //System.out.println(DebuggingUtilities.actionValues(vfa,curState,domain));
            //System.out.println(DebuggingUtilities.describeState(curState,8));
            //System.out.println(DebuggingUtilities.actionValuesForAgentPosition(vfa,curState,domain,"east",8,10));
            //move on
            curState = nextState;
            action = nextAction;

            this.totalNumberOfSteps++;


        }

        if (episodeHistory.size() >= numEpisodesToStore) {
            episodeHistory.poll();
            episodeHistory.offer(ea);
        }

        return ea;
    }

    public double getMaxWeightChangeInLastEpisode() {
        return maxWeightChangeInLastEpisode;
    }
}
