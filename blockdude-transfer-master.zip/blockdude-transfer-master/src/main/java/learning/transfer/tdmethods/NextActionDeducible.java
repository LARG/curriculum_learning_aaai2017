package learning.transfer.tdmethods;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public interface NextActionDeducible {
    public GroundedAction nextAction(State stateprime);
}
