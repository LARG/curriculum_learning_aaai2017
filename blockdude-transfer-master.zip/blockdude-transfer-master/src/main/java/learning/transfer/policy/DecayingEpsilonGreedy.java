package learning.transfer.policy;

import burlap.behavior.policy.EpsilonGreedy;
import burlap.behavior.valuefunction.QFunction;
import burlap.oomdp.core.AbstractGroundedAction;
import burlap.oomdp.core.states.State;


/**
 This class defines a an epsilon-greedy policy over Q-values and requires a QComputable valueFunction to be specified.
 With probability epsilon the policy will return a random action (with uniform distribution over all possible action).
 With probability 1 - epsilon the policy will return the greedy action. If multiple actions tie for the highest Q-value,
 then one of the tied actions is randomly selected.

 @author James MacGlashan */
public class DecayingEpsilonGreedy extends EpsilonGreedy {

    double factor = .99;

    public DecayingEpsilonGreedy(QFunction planner, double epsilon, double decay) {
        super(planner, epsilon);
        factor = decay;
    }

    @Override
    public AbstractGroundedAction getAction(State s) {
        epsilon *= factor;
        return super.getAction(s);
    }


}
