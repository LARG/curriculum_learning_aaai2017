package learning.transfer.policy;

import burlap.behavior.policy.EpsilonGreedy;
import burlap.behavior.valuefunction.QFunction;
import burlap.behavior.valuefunction.QValue;
import burlap.oomdp.core.AbstractGroundedAction;
import burlap.oomdp.core.AbstractObjectParameterizedGroundedAction;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import learning.transfer.advice.AdviceFunction;
import learning.transfer.advice.LookAheadAdviceFunction;

import java.util.ArrayList;
import java.util.List;

/**
 * Selects actions greedily, except with some small epsilon probability. Un-biases
 * its greedy maximization by the passed in potential function
 */
public class BiasedEpsilonGreedy extends EpsilonGreedy {

    private final AdviceFunction adviceFunction;
    private final double decayRate;

    public BiasedEpsilonGreedy(QFunction planner, double epsilon, double decayRate, AdviceFunction adviceFunction) {
        super(planner, epsilon);
        this.decayRate = decayRate;
        this.adviceFunction = adviceFunction;
    }

    @Override
    public AbstractGroundedAction getAction(State s) {
        List<QValue> qValues = this.qplanner.getQs(s);

        double roll = rand.nextDouble();

        if (roll <= epsilon) {
            int selected = rand.nextInt(qValues.size());
            AbstractGroundedAction ga = qValues.get(selected).a;

            return AbstractObjectParameterizedGroundedAction.Helper.translateParameters(ga, qValues.get(selected).s, s);
        }

        List<QValue> maxActions = new ArrayList<>();

        double maxQ = Double.NEGATIVE_INFINITY;

        for (QValue q : qValues) {
            assert (!Double.isNaN(q.q));
            double shapedQ = q.q;

            if (adviceFunction.getShapingFunction() instanceof LookAheadAdviceFunction) {
                double potential = adviceFunction.getPotentialFunction().potential(s, (GroundedAction) q.a);
                shapedQ += potential;
                //System.out.printf("----%s: potential: %.2f, q: %.2f\n", q.a.actionName(), potential, q.q);
            }

            if (shapedQ == maxQ) {
                maxActions.add(q);
            } else if (shapedQ > maxQ) {
                maxActions.clear();
                maxActions.add(q);
                maxQ = shapedQ;
            }
        }
        int selected = rand.nextInt(maxActions.size());
        //return translated action parameters if the action is parameterized with objects in a object identifier indepdent domain
        AbstractGroundedAction ga = maxActions.get(selected).a;
        String maxActionString = "";
        for (QValue q : maxActions) {
            maxActionString += q.a.actionName() + " ";
        }

        //System.out.printf("\nMax Actions: %s\n", maxActionString);
        //System.out.printf("----Action Chosen: %s\n\n", ga.actionName());
        epsilon *= decayRate;
        return ga;
    }
}
