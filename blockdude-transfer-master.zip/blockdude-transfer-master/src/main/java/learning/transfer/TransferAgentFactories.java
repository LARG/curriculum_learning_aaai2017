package learning.transfer;

import burlap.behavior.singleagent.MDPSolverInterface;
import burlap.behavior.singleagent.learning.LearningAgent;
import burlap.behavior.singleagent.learning.LearningAgentFactory;
import burlap.behavior.singleagent.learning.modellearning.rmax.PotentialShapedRMax;
import burlap.behavior.singleagent.learning.tdmethods.vfa.GradientDescentSarsaLam;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.oomdp.core.Domain;
import burlap.oomdp.statehashing.HashableStateFactory;
import burlap.oomdp.statehashing.SimpleHashableStateFactory;
import learning.transfer.advice.AdviceFunction;
import learning.transfer.advice.NextAction;
import learning.transfer.policy.BiasedEpsilonGreedy;
import learning.transfer.tdmethods.GradientDescentSarsaLamTransfer;

public class TransferAgentFactories {

    static public LearningAgentFactory getGradientDescentSarsaLamTransferFactory(final Domain domain, final DifferentiableStateActionValue vfa, final ExtendedShapingRewardFunction rewardFunc, double alpha, double epsilon, double lambda, double gamma) {
        return new LearningAgentFactory() {

            @Override
            public String getAgentName() {
                return "Gradient Descent Sarsa Lam Transfer";
            }

            @Override
            public LearningAgent generateAgent() {
                GradientDescentSarsaLamTransfer gdSarsaLam = new GradientDescentSarsaLamTransfer(domain, gamma, vfa, alpha, lambda, epsilon, rewardFunc.getAdviceFunction());
                rewardFunc.setNextAction(new NextAction(gdSarsaLam));
                return gdSarsaLam;
            }
        };

    }

    /**
     * This agent does not learn. It executes a greedy policy using its value function.
     *
     * @param domain
     * @param vfa
     * @return
     */
    static public LearningAgentFactory getEvaluationAgentFactory(final Domain domain, final DifferentiableStateActionValue vfa, final AdviceFunction adviceFunction, double gamma) {
        return new LearningAgentFactory() {

            @Override
            public String getAgentName() {
                return "Evaluation Agent";
            }

            @Override
            public LearningAgent generateAgent() {

                BiasedEpsilonGreedy policy = new BiasedEpsilonGreedy(null, 0.0, 0.0, adviceFunction);
                LearningAgent agent = new GradientDescentSarsaLam(domain, gamma, vfa, 0.0, policy, Integer.MAX_VALUE, 0.0);
                policy.setSolver((MDPSolverInterface) agent);
                return agent;
            }
        };

    }

    static public LearningAgentFactory getRmaxAgentFactory(final Domain domain, final DifferentiableStateActionValue vfa, double gamma) {
        return new LearningAgentFactory() {
            @Override
            public String getAgentName() {
                return "RMax agent";
            }

            @Override
            public LearningAgent generateAgent() {
                HashableStateFactory hasher = new SimpleHashableStateFactory();
                LearningAgent agent = new PotentialShapedRMax(domain, gamma, hasher, 50.0, 1, 10, 10);
                return agent;
            }
        };
    }


}
