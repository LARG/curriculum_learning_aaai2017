package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public class AdviceFunction {

    private ShapingFunction shapingFunction;
    private PotentialFunction potentialFunction;

    public AdviceFunction(ShapingFunction shapingFunction, PotentialFunction potentialFunction) {
        this.shapingFunction = shapingFunction;
        this.potentialFunction = potentialFunction;
    }

    public double advice(State s, GroundedAction a, State sprime, GroundedAction aprime) {
        return shapingFunction.shaping(potentialFunction, s, a, sprime, aprime);
    }

    public PotentialFunction getPotentialFunction() {
        return potentialFunction;
    }

    public ShapingFunction getShapingFunction() {
        return shapingFunction;
    }

}
