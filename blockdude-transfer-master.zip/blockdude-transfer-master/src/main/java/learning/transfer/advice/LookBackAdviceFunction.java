package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public class LookBackAdviceFunction implements ShapingFunction {

    // Gamma from MDP
    final double inverseGamma;

    private State prevState;
    private GroundedAction prevAction;

    public LookBackAdviceFunction(double gamma) {
        inverseGamma = 1.0 / gamma;
    }

    @Override
    public double shaping(PotentialFunction potential, State s, GroundedAction a, State sprime, GroundedAction aprime) {
        double advice = potential.potential(s, a) - inverseGamma * (prevState != null ? potential.potential(prevState, prevAction) : 0.0);

        prevState = s;
        prevAction = a;

        return advice;
    }

}
