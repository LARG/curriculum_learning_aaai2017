package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import learning.transfer.tdmethods.NextActionDeducible;

public class NextAction {

    private final NextActionDeducible nextActionDeducible;

    public NextAction(NextActionDeducible nextActionDeducible) {
        this.nextActionDeducible = nextActionDeducible;
    }

    public GroundedAction nextAction(State state) {
        return nextActionDeducible.nextAction(state);
    }

}
