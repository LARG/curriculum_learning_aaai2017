package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public class LookAheadAdviceFunction implements ShapingFunction {

    // Gamma from MDP
    final double gamma;

    public LookAheadAdviceFunction(double gamma) {
        this.gamma = gamma;
    }

    @Override
    public double shaping(PotentialFunction potential, State s, GroundedAction a, State sprime, GroundedAction aprime) {
        double prime = potential.potential(sprime, aprime);
        double advice = potential.potential(s, a);
        return gamma * prime - advice;
    }

}
