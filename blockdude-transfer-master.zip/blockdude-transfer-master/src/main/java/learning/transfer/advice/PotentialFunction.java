package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public interface PotentialFunction {

    public abstract double potential(State s, GroundedAction a);

}
