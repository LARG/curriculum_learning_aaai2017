package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public class BlockdudeAdvantageAdvice implements PotentialFunction {

    @Override
    public double potential(State s, GroundedAction a) {
        // Because the goal is always east of the agent, we'll predispose it to
        // go that direction
        if (a.actionName().equals("east")) {
            return 0;
        } else {
            //Advised against
            return -10;
        }
    }

}
