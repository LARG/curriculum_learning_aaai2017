package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public interface ShapingFunction {

    public double shaping(PotentialFunction potential, State s, GroundedAction a, State sprime, GroundedAction aprime);

}
