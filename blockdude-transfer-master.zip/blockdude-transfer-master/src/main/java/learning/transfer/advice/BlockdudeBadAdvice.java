package learning.transfer.advice;

import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

public class BlockdudeBadAdvice implements PotentialFunction {

    @Override
    public double potential(State s, GroundedAction a) {
        // East is typically the best direction to head in,
        // so this is almost certainly bad advice
        if (a.actionName().equals("east") || a.actionName().equals("pickup")) {
            return -10.0;
        } else {
            // No advice
            return 0.0;
        }
    }

}
