package learning.transfer.advice;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;

import java.util.List;

public class TransferFAPotentialFunction implements PotentialFunction {

    protected List<DifferentiableStateActionValue> vfa;

    public TransferFAPotentialFunction(List<DifferentiableStateActionValue> vfa) {
        this.vfa = vfa;
    }

    @Override
    public double potential(State s, GroundedAction a) {
        return vfa.stream()
                .mapToDouble(vfa -> vfa.evaluate(s, a))
                .sum();
    }

}
