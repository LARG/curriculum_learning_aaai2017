package learning.transfer.curriculum.hand;

import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.LinearCurriculum;
import learning.utilities.DataUtilities;
import learning.utilities.MapUtilities;

public class ChangingAgentStartPosition extends LinearCurriculum {

    final static int baseMap[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 1},
            {1, -1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
    private final int stepSize;
    private final int numSteps;

    public ChangingAgentStartPosition(int stepSize, int numSteps) {
        this.stepSize = stepSize;
        this.numSteps = numSteps;
    }

    public BlockDudeMap map(int index) {
        final int agentX = baseMap.length - 3 - (index * stepSize);
        int[][] map = DataUtilities.twoDArrayCopy(baseMap);
        MapUtilities.placeAgent(agentX, map, true);
        return new BlockDudeMap(map, index);
    }

    @Override
    public int numTasks() {
        return numSteps;
    }
}