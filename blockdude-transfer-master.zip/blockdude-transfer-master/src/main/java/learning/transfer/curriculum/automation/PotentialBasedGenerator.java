package learning.transfer.curriculum.automation;

public abstract class PotentialBasedGenerator implements CurriculumGenerator {
    final TransferPotentialFunction potentialFunction;

    public PotentialBasedGenerator(TransferPotentialFunction potentialFunction) {
        this.potentialFunction = potentialFunction;
    }


}
