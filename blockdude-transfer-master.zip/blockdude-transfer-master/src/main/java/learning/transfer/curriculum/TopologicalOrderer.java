package learning.transfer.curriculum;

import java.util.*;

public class TopologicalOrderer {

    public final Set<BlockDudeMap> tasks;
    public final Map<BlockDudeMap, List<BlockDudeMap>> inEdges;
    private final Map<BlockDudeMap, List<BlockDudeMap>> outEdges;
    public List<BlockDudeMap> ordered;
    private Set<BlockDudeMap> temporaryMarked;
    private List<BlockDudeMap> unmarked;

    /**
     * @param edges edges of a DAG
     */
    public TopologicalOrderer(Set<GeneratedCurriculum.Edge> edges) {

        temporaryMarked = new HashSet<>();
        // Let's gather some basics about the edges we've got
        this.tasks = new HashSet<>();
        inEdges = new HashMap<>();
        outEdges = new HashMap<>();
        for (GeneratedCurriculum.Edge edge : edges) {
            assert (edge.source != edge.target);
            BlockDudeMap source = edge.source;
            BlockDudeMap target = edge.target;
            // All verts go into the task set
            this.tasks.add(source);
            this.tasks.add(target);

            // Create a list for the sending vertex, in case it doesn't
            // end up ever having an in edge
            inEdges.putIfAbsent(source, new LinkedList<>());
            // Create the list if there isn't one
            inEdges.putIfAbsent(target, new LinkedList<>());
            List<BlockDudeMap> currentInEdges = inEdges.get(target);
            currentInEdges.add(source);

            // Now the reverse
            outEdges.putIfAbsent(source, new LinkedList<>());
            outEdges.putIfAbsent(target, new LinkedList<>());
            List<BlockDudeMap> currentOutEdges = outEdges.get(source);
            currentOutEdges.add(target);
        }
        assert (inEdges.keySet().size() == tasks.size());

    }

    /**
     * Runs a recursive, DFS-based topological sort
     * @return
     */
    public List<BlockDudeMap> topologicalOrder() {
        unmarked = new LinkedList<>(outEdges.keySet());
        temporaryMarked = new HashSet<>();
        ordered = new LinkedList<>();
        while (!unmarked.isEmpty()) {
            BlockDudeMap node = unmarked.iterator().next();
            visit(node, outEdges.get(node), ordered);
        }
        assert (ordered.size() == tasks.size());
        return ordered;
    }

    /**
     * The recursive method itself.
     * @param node
     * @param nodeOutEdges
     * @param ordered
     */
    private void visit(BlockDudeMap node, List<BlockDudeMap> nodeOutEdges, List<BlockDudeMap> ordered) {
        if (temporaryMarked.contains(node)) {
            throw new RuntimeException("Generated curriculum is not a DAG");
        } else if (unmarked.contains(node)) {
            temporaryMarked.add(node);
            for (BlockDudeMap neighbor : nodeOutEdges) {
                visit(neighbor, outEdges.get(neighbor), ordered);
            }
            temporaryMarked.remove(node);
            unmarked.remove(node);
            ordered.add(0, node);

        }
    }
}
