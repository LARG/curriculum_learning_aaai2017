package learning.transfer.curriculum.hand;

import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.LinearCurriculum;
import learning.utilities.MapUtilities;

public class SameMap extends LinearCurriculum {

    final int width;

    public SameMap(int width) {
        assert (width > 3);
        this.width = width;
    }

    protected BlockDudeMap map(int index) {
        final int rows = 4;

        int[][] map = new int[width][rows];
        map[1][1] = BlockDudeMap.STARTEAST;
        MapUtilities.padWithBricks(map);
        map[width - 2][1] = BlockDudeMap.EXIT;
        return new BlockDudeMap(map, index);
    }

    @Override
    public int numTasks() {
        return 2;
    }

}