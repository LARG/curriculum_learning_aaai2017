package learning.transfer.curriculum.automation;

import learning.transfer.curriculum.BlockDudeMap;
import learning.utilities.MapFeatureExtractors;
import learning.utilities.Vector;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class TransferPotentialFunction {

    /**
     * A weight to balance the applicability and cost functions. It is one for noww
     */
    final double applicabilityWeight;

    public TransferPotentialFunction() {
        this.applicabilityWeight = 1.0;
    }

    /**
     * Calculate potential of source with respect to many targets
     *
     * @param source
     * @param targetPool
     * @return a list of results in order of highest to lowest potential
     */
    List<MapResult> calculatePotentials(BlockDudeMap source, Set<BlockDudeMap> targetPool) {
        LinkedList<MapResult> results = targetPool.stream()
                .map(target -> new MapResult(source, target, calculate(source, target)))
                .collect(Collectors.toCollection(LinkedList::new));
        Collections.sort(results);
        Collections.reverse(results);
        return results;
    }

    /**
     * Calculate the transfer potential
     *
     * @param source
     * @param target
     * @return
     */
    double calculate(BlockDudeMap source, BlockDudeMap target) {
        double a = applicability(source.representation, target.representation);
        double c = cost(source.representation, target.representation);
        // Zero cost is an edge case. We should interpret to mean that
        // transfer is attractive.
        if (c == 0.0) {
            return Double.POSITIVE_INFINITY;
        }
        return applicabilityWeight * a / c;
    }

    /**
     * Estimates the degree to which the source task can inform the target task.
     *
     * @param source
     * @param target
     * @return
     */

    double applicability(int[][] source, int[][] target) {
        List<Double> sourceFeatures = MapFeatureExtractors.extract(source);
        List<Double> targetFeatures = MapFeatureExtractors.extract(target);
        // The map features are used as an estimator for the size of the map's
        // state space. We form a vector from the minimum feature value for each feature
        // then we treat this vector as a volume and measure it.
        return Vector.volume(Vector.elementWiseMin(sourceFeatures, targetFeatures));
    }

    /**
     * Estimates the time it would take to transfer from the source to the target
     *
     * @param source
     * @param target
     * @return
     */
    double cost(int[][] source, int[][] target) {
        List<Double> sourceFeatures = MapFeatureExtractors.extract(source);
        List<Double> targetFeatures = MapFeatureExtractors.extract(target);
        // cost is estimated as the difference in the sizes of the state spaces
        return Vector.volume(targetFeatures) - Vector.volume(sourceFeatures);
    }

    /**
     * Calculate the potential of a number of source tasks with respect to a target task
     *
     * @param sourcePool
     * @param target
     * @return a list of results in order of highest to lowest potential
     */
    List<MapResult> calculatePotentials(Set<BlockDudeMap> sourcePool, BlockDudeMap target) {
        LinkedList<MapResult> results = sourcePool.stream()
                .map(source -> new MapResult(source, target, calculate(source, target)))
                .collect(Collectors.toCollection(LinkedList::new));
        Collections.sort(results);
        Collections.reverse(results);
        return results;
    }


    /**
     * Calculates the potential of a pool of sources with respect to a target
     *
     * @param sourcePool
     * @param target
     * @return an array of potentials in the same order as the sourcepool
     */
    double[] calculatePotentials(List<BlockDudeMap> sourcePool, BlockDudeMap target) {
        double[] potentials = new double[sourcePool.size()];
        for (int i = 0; i < sourcePool.size(); i++) {
            potentials[i] = calculate(sourcePool.get(i), target);
        }
        return potentials;
    }

    /**
     * Calculates the potential of a source task with respect to a pool of different targets
     *
     * @param source
     * @param targetPool
     * @return an array of potentials in the same order as the target pool
     */
    double[] calculatePotentials(BlockDudeMap source, List<BlockDudeMap> targetPool) {
        double[] potentials = new double[targetPool.size()];
        for (int i = 0; i < targetPool.size(); i++) {
            potentials[i] = calculate(source, targetPool.get(i));
        }
        return potentials;
    }

    double[][] calculatePotentialAdjacencyMatrix(List<BlockDudeMap> maps) {
        double[][] adjacency = new double[maps.size()][maps.size()];
        for (int i = 0; i < maps.size(); i++) {
            for (int j = 0; j < maps.size(); j++) {
                adjacency[i][j] = calculate(maps.get(i), maps.get(j));
            }

        }
        return adjacency;
    }

    /**
     * Calculates the potentials between all sources and all targets
     *
     * @param sources
     * @param targets
     * @return a 2D array where the rows are in the same order as the sources, and the elements of a row are in the same order
     * as the targets
     */
    double[][] calculatePotentialAdjacencyMatrix(List<BlockDudeMap> sources, List<BlockDudeMap> targets) {
        double[][] adjacency = new double[sources.size()][targets.size()];
        for (int i = 0; i < sources.size(); i++) {
            for (int j = 0; j < targets.size(); j++) {
                adjacency[i][j] = calculate(sources.get(i), targets.get(j));
            }

        }
        return adjacency;
    }

    /**
     * A container for the results of a potential calculation for a source
     * with respect to a target.
     */
    class MapResult implements Comparable {
        public final BlockDudeMap map;
        public final BlockDudeMap target;
        public final double potential;

        MapResult(BlockDudeMap map, BlockDudeMap target, double potential) {
            this.map = map;
            this.target = target;
            this.potential = potential;
        }

        @Override
        public int compareTo(Object o) {
            if (o instanceof MapResult) {
                return Double.compare(((MapResult) o).potential, potential);
            }
            return -1;
        }
    }
}
