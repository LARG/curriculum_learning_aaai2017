package learning.transfer.curriculum.hand;

import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.LinearCurriculum;
import learning.utilities.MapUtilities;

public class IncreasingMapWidthCurriculum extends LinearCurriculum {

    private final int startWidth;
    private final int stepSize;
    private final int numSteps;

    public IncreasingMapWidthCurriculum(int startWidth, int stepSize, int numSteps) {
        assert (startWidth > 3);
        this.startWidth = startWidth;
        this.stepSize = stepSize;
        this.numSteps = numSteps;
    }

    protected BlockDudeMap map(int index) {
        final int columns = this.startWidth + index * stepSize;
        final int rows = 4;

        int[][] map = new int[columns][rows];
        map[1][1] = BlockDudeMap.STARTEAST;
        MapUtilities.padWithBricks(map);
        map[columns - 2][1] = BlockDudeMap.EXIT;
        return new BlockDudeMap(map, index);
    }

    @Override
    public int numTasks() {
        return numSteps + 1;
    }

}