package learning.transfer.curriculum.automation;

import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;

import java.util.Set;

public interface CurriculumGenerator {

    // Calculates the transfer-potential maximizing path through the sources to the target
    BlockDudeCurriculum generate(Set<BlockDudeMap> sources, BlockDudeMap target);


}
