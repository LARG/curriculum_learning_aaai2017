package learning.transfer.curriculum;

import java.util.ArrayList;
import java.util.List;

public class AllMapPool extends LinearCurriculum {

    private List<BlockDudeMap> maps;

    public AllMapPool() {
        maps = new ArrayList<>();
        int numMaps = 0;
        for (int i = 0; i < BlockDudeCurriculum.numCurricula(); i++) {
            // Avoid 1 because it's all about different arrangements of blocks, which our map feature descriptor doesn't
            // handle.
            // Avoid 3 because it's all about changing the agent start position which is not represented.
            if (i == 1 || i == 3) continue;
            BlockDudeCurriculum c = BlockDudeCurriculum.withIndex(i);
            for (BlockDudeMap map : c.mapsInStepRange(0, c.numSteps())) {
                map.index = numMaps;
                numMaps += 1;
                map.curriculum = this;
                maps.add(map);
            }
        }
    }

    @Override
    protected BlockDudeMap map(int index) {

        return maps.get(index);
    }

    @Override
    public int numTasks() {
        return maps.size();
    }
}
