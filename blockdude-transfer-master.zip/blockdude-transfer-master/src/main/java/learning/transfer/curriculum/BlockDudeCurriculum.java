package learning.transfer.curriculum;

import learning.transfer.curriculum.hand.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public abstract class BlockDudeCurriculum {

    private static BlockDudeCurriculum curricula[] = {
            new BlockDudeStairCurriculum(),
            new BlockDudeFixedHeightStairConstruction(),
            new IncreasingMapWidthCurriculum(5, 3, 4),
            new ChangingAgentStartPosition(2, 5),
            new BaseGenerationPool(),
            new BlockDudeCompositeCurriculum(),
            new SameMap(6),
            new IncreasingMapWidthCurriculum(5, 1, 12),
            new IncreasingMapWidthCurriculum(5, 2, 6),
            new IncreasingMapWidthCurriculum(5, 3, 4),
            new IncreasingMapWidthCurriculum(5, 4, 3),
            new IncreasingMapWidthCurriculum(5, 6, 2),
            new ExtendedGenerationPool(),
            new SmallGenerationPool()
    };
    public int index = -1;

    public static BlockDudeCurriculum withIndex(int index) {
        BlockDudeCurriculum curriculum = curricula[index];
        curriculum.index = index;
        return curriculum;
    }

    public static int numCurricula() {
        return curricula.length;
    }

    public Step stepWithTarget(BlockDudeMap map) {
        for (int i = 0; i < numSteps(); i++) {
            Step step = step(i);
            if (step.target.equals(map)) {
                return step;
            }
        }
        return null;
    }

    public abstract int numSteps();

    public abstract Step step(int i);

    public final BlockDudeMap mapWithIndex(int index) {
        BlockDudeMap map = map(index);
        map.curriculum = this;
        return map;
    }

    protected abstract BlockDudeMap map(int index);

    public abstract int numTasks();

    public Set<BlockDudeMap> mapsInStepRange(int startStep, int endStep) {
        Set<BlockDudeMap> maps = new HashSet<>();
        for (int i = startStep; i < endStep; i++) {
            Step step = step(i);
            maps.add(step.target);
        }
        return maps;
    }

    public class Step {
        public final List<BlockDudeMap> sources;
        public final BlockDudeMap target;
        public final int index;

        Step(List<BlockDudeMap> sources, BlockDudeMap target, int index) {
            this.sources = sources;
            this.target = target;
            this.index = index;
        }

        @Override
        public boolean equals(Object o) {
            if (o instanceof Step) {
                Step other = (Step) o;
                return sources.equals(other.sources) &&
                        target.equals(other.target) &&
                        index == other.index;
            }
            return false;
        }

        public String toString() {
            String sourcesString = "";
            Set<Integer> orderedSources = new TreeSet<>();
            List<Integer> unorderedSources = sources.stream().map(map -> map.index).collect(Collectors.toList());
            orderedSources.addAll(unorderedSources);
            for (Integer sourceIndex : orderedSources) {
                sourcesString += sourceIndex + ", ";
            }
            return "{" + sourcesString + "} -> " + target.index;
        }

        public boolean hasSources() {
            return this.sources.size() > 0;
        }
    }

    public String toString() {
        String result = "";
        for (int i = 0; i < numSteps(); i++) {
            Step step = step(i);
            result += step + "\n";
        }
        return result;
    }


}
