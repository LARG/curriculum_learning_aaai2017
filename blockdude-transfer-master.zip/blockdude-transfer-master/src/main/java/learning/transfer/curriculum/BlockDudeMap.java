package learning.transfer.curriculum;

import learning.utilities.DebuggingUtilities;

import java.util.Arrays;

public class BlockDudeMap {
    public static final int EXIT = -1;
    public static final int BRICK = 1;
    public static final int BLOCK = 2;
    public static final int STARTEAST = 3;
    public static final int STARTWEST = 4;
    public static final int STARTEASTHOLDING = 5;
    public static final int STARTWESTHOLDING = 6;

    public final int[][] representation;
    public BlockDudeCurriculum curriculum = null;
    public int index = -1;

    public BlockDudeMap(int[][] representation) {
        this.representation = representation;
    }

    public BlockDudeMap(int[][] representation, int curriculumIndex) {
        this.representation = representation;
        this.index = curriculumIndex;
    }

    public int getWidth() {
        return this.representation.length;
    }

    public int getHeight() {
        return this.representation[0].length;
    }

    @Override
    public int hashCode() {
        return Arrays.deepHashCode(representation);
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof BlockDudeMap) {
            BlockDudeMap other = (BlockDudeMap) o;
            return Arrays.deepEquals(other.representation, representation);
        }
        return false;
    }

    public String toString() {
        return "c" + curriculum.index + "m" + index;
    }

    public String describe() {
        return DebuggingUtilities.mapToString(representation);
    }
}
