package learning.transfer.curriculum.hand;

import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.LinearCurriculum;

/**
 A five brick high pillar. Maps are named after the number of vertical slices of the staircase that the agent must create. Each slice is contains one more block than the last.
 */
public class BlockDudeFixedHeightStairConstruction extends LinearCurriculum {


    final static int one[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 3, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 2, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 2, 2, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
            {1, -1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    final static int two[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 3, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 2, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 2, 2, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
            {1, -1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
    final static int three[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 3, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 2, 2, 2, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
            {1, -1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    final static int four[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 3, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
            {1, -1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    final static int[][] mapsByDifficulty[] = {
            one, two, three, four
    };


    protected BlockDudeMap map(int difficulty) {
        if (difficulty < 0) {
            return new BlockDudeMap(mapsByDifficulty[0], 0);
        } else if (difficulty > mapsByDifficulty.length) {
            return new BlockDudeMap(mapsByDifficulty[mapsByDifficulty.length - 1], mapsByDifficulty.length - 1);
        } else {
            return new BlockDudeMap(mapsByDifficulty[difficulty], difficulty);
        }
    }

    @Override
    public int numTasks() {
        return mapsByDifficulty.length;
    }

}