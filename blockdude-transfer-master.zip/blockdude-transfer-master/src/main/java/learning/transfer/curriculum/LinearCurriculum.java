package learning.transfer.curriculum;

import java.util.LinkedList;
import java.util.List;

/**
 * Curricula where transfer happens from exactly one startStep to one target at each step, and where
 * one step's target becomes the next step's startStep.
 */
public abstract class LinearCurriculum extends BlockDudeCurriculum {

    @Override
    public Step step(int i) {
        assert (i < numSteps());
        BlockDudeMap source;
        BlockDudeMap target;
        if (i == 0) {
            source = null;
            target = mapWithIndex(0);
        } else {
            source = mapWithIndex(i - 1);
            target = mapWithIndex(i);
        }
        List<BlockDudeMap> sources = new LinkedList<>();
        if (source != null) {
            sources.add(source);
        }
        return new Step(sources, target, i);
    }

    @Override
    public int numSteps() {
        return numTasks();
    }
}
