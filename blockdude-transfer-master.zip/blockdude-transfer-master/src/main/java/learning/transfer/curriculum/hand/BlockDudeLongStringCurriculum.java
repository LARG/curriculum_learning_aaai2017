package learning.transfer.curriculum.hand;

import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.LinearCurriculum;
import learning.utilities.MapUtilities;

public class BlockDudeLongStringCurriculum extends LinearCurriculum {
    private int heightOfObstacle;
    private int curriculumLength;
    private int numBlocks;
    private int mapWidth;
    private int mapHeight;

    BlockDudeLongStringCurriculum(int heightOfObstacle) {
        this.heightOfObstacle = heightOfObstacle;
        this.curriculumLength = heightOfObstacle + 1;
        this.numBlocks = (heightOfObstacle - 1 * heightOfObstacle) / 2;
        // One space for the agent, one for the obstacle, one for the goal
        // Two for the brick paddding of the map. One for each block, laid
        // out in a long row.
        this.mapWidth = numBlocks + 3 + 2;
        this.mapHeight = heightOfObstacle + 3;

    }

    protected BlockDudeMap map(int index) {
        assert (index <= heightOfObstacle);
        int[][] map = new int[mapWidth][mapHeight];
        MapUtilities.padWithBricks(map);
        // Insert all blocks
        for (int b = 0; b < numBlocks; b++) {
            // First block appears at row 1, column 2
            map[1][2 + b] = BlockDudeMap.BLOCK;
        }
        // Insert obstacle
        for (int o = 0; o < index; o++) {
            // Obstacle begins at height at row 1, third column from the end
            map[1 + o][mapWidth - 3] = BlockDudeMap.BRICK;
        }
        return new BlockDudeMap(map, index);
    }

    @Override
    public int numTasks() {
        return curriculumLength;
    }
}
