package learning.transfer.curriculum.automation;

import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.GeneratedCurriculum;
import learning.utilities.MapFeatureExtractors;
import learning.utilities.Vector;

import java.util.*;
import java.util.stream.Collectors;


public class CurriculumGraphGenerator extends PotentialBasedGenerator {

    /**
     * The minimum necessary potential for transfer to be considered useful
     */
    final double MINIMUM_POTENTIAL_THRESHOLD = 0.01;

    /**
     * Controls whether the generated curriculum use the intergroup transfer algorithm.
     * Intergroup transfer increases the reuse of already learned information, so it's
     * instructive to compare the performance of curricula with and without it.
     */
    public boolean useInterGroupTransfer = true;

    /**
     * A simpler (typically just a tree) subset of the curriculum, formed by only considering maps
     * that are a part of the largest group of maps. Useful for benchmarking.
     */
    public boolean onlyUseLargestGroup = false;

    /**
     * Takes a subset of the intergroup edges, keeping only the edges to the most popular single target map.
     * This allows you to benchmark the effect of a small amount of intergroup transfer (though perhaps the most
     * important intergroup transfer)
     */
    public boolean largestInterGroupTargetOnly = false;

    public CurriculumGraphGenerator(TransferPotentialFunction potentialFunction) {
        super(potentialFunction);
    }

    /**
     * Algorithm 3 from the paper, the core of the generation logic
     *
     * @param sources
     * @param target
     * @return
     */
    @Override
    public BlockDudeCurriculum generate(Set<BlockDudeMap> sources, BlockDudeMap target) {
        sources.forEach(map -> {
            assert (map != target);
        });
        // If some tasks have a negative transfer potential, go ahead and leave them out
        Set<BlockDudeMap> pruned = prune(sources, target);
        // Group tasks based on their binary feature descriptors
        Set<Group> groups = generateGroups(pruned);

        if (onlyUseLargestGroup) {
            Group largestGroup = takeLargestGroup(groups);
            groups = new HashSet<>();
            groups.add(largestGroup);
        }

        // Run all of the sub-algorithms to figure out how to create the edges
        // in the curricula
        List<List<GeneratedCurriculum.Edge>> intraGroupEdges = allIntraGroupEdges(new LinkedList<>(groups), target);
        List<GeneratedCurriculum.Edge> interGroupEdges = interGroupTransfer(groups);
        List<GeneratedCurriculum.Edge> toTargetSteps = targetEdges(groups, target);

        // Collect all the edges in a set
        Set<GeneratedCurriculum.Edge> finishedGraph = new HashSet<>();
        intraGroupEdges.forEach(finishedGraph::addAll);
        if (useInterGroupTransfer) {
            if (largestInterGroupTargetOnly) {
                interGroupEdges = takeLargestTargetOnly(interGroupEdges);
            }
            finishedGraph.addAll(interGroupEdges);
        }
        finishedGraph.addAll(toTargetSteps);

        // GeneratedCurriculum takes care of ensuring that the edges
        // form a valid transfer graph (no cycles), and will take
        // care of the details needed to actually run the curriculum.
        return new GeneratedCurriculum(finishedGraph);
    }

    /**
     * Discards source tasks that have a low transfer potential relative to the final target
     *
     * @param sources
     * @param target
     * @return
     */
    private Set<BlockDudeMap> prune(Set<BlockDudeMap> sources, BlockDudeMap target) {
        Set<BlockDudeMap> pruned = new HashSet<>();
        List<TransferPotentialFunction.MapResult> potentials = potentialFunction.calculatePotentials(sources, target);
        potentials.stream()
                .filter(result -> result.potential > MINIMUM_POTENTIAL_THRESHOLD)
                .forEach(result -> pruned.add(result.map));

        if (pruned.size() < 1) {
            throw new RuntimeException("Not enough useful source maps!");
        }
        return pruned;
    }

    /**
     * Implements grouping methodology from section 5.1 of the paper.
     *
     * @param sources
     * @return
     */
    private Set<Group> generateGroups(Set<BlockDudeMap> sources) {
        // Map each task with the compact representation of its binary feature descriptor
        Map<BlockDudeMap, Integer> withFeatures = new HashMap<>();
        sources.forEach(map -> {
            int features = MapFeatureExtractors.extractBinaryFeatureDescriptorInt(map.representation);
            withFeatures.put(map, features);
        });
        // Now map each compact BFD to a set of maps, and insert every map into the correct set based on its BFD
        Map<Integer, Set<BlockDudeMap>> groups = new HashMap<>();
        for (Map.Entry<BlockDudeMap, Integer> entry : withFeatures.entrySet()) {
            groups.putIfAbsent(entry.getValue(), new HashSet<>());
            Set<BlockDudeMap> group = groups.get(entry.getValue());
            group.add(entry.getKey());
        }
        // Wrap the sets into group objects
        Set<Group> finalGroups = groups.values().stream()
                .map(Group::new)
                .collect(Collectors.toSet());
        return finalGroups;

    }

    private static Group takeLargestGroup(Set<Group> groups) {
        List<Group> groupsList = new LinkedList<>(groups);
        Collections.sort(groupsList);
        return groupsList.get(0);
    }

    /**
     * Generates all intra group edges.
     *
     * @param groups      an arbitrarily ordered list of groups
     * @param finalTarget
     * @return a list of lists of edges, where each individual list is ordered by the the sequence the algorithm generated the edge,
     * and the overall list is in the same order as the list of groups passed in
     */
    private List<List<GeneratedCurriculum.Edge>> allIntraGroupEdges(List<Group> groups, BlockDudeMap finalTarget) {
        List<List<GeneratedCurriculum.Edge>> sequences = groups.stream()
                .map(group -> {
                    group.sequenceRelativeTo(finalTarget);
                    return infraGroupTransfer(group);
                }).collect(Collectors.toCollection(LinkedList::new));
        return sequences;
    }

    /**
     * Assigns edges between groups
     *
     * @param groups
     * @return
     */
    private List<GeneratedCurriculum.Edge> interGroupTransfer(final Set<Group> groups) {
        List<GeneratedCurriculum.Edge> edges = new LinkedList<>();
        // If there's only one group, no need to make edges.
        if (groups.size() == 1) {
            return edges;
        }
        // Every group will be considered as a target at least once here
        for (Group targetGroup : groups) {
            Set<Group> subsetGroups = new HashSet<>();
            // Find all other groups where the descriptor is a subset of this groups' descriptor
            subsetGroups.addAll(groups.stream()
                    .filter(candidate -> Vector.isSubset(candidate.binaryFeatureDescriptor, targetGroup.binaryFeatureDescriptor) && candidate != targetGroup)
                    .collect(Collectors.toList()));

            for (Group sourceGroup : subsetGroups) {
                edges.addAll(assignInterGroupEdges(sourceGroup, targetGroup));
            }

        }
        return edges;
    }

    /**
     * Generates edges between groups and the final target task.
     *
     * @param groups
     * @param finalTarget
     * @return
     */
    private List<GeneratedCurriculum.Edge> targetEdges(Set<Group> groups, BlockDudeMap finalTarget) {
        List<GeneratedCurriculum.Edge> edges = new LinkedList<>();
        for (Group group : groups) {
            // Groups are sequenced by their transfer potential to the final target,
            // so all we need to do is create an edge between the last in the group
            // and the final target.
            BlockDudeMap last = group.sequenced.get(group.sequenced.size() - 1);
            edges.add(new GeneratedCurriculum.Edge(last, finalTarget));
        }
        return edges;
    }

    private List<GeneratedCurriculum.Edge> takeLargestTargetOnly(List<GeneratedCurriculum.Edge> interGroupEdges) {
        Map<BlockDudeMap, List<GeneratedCurriculum.Edge>> inEdges = new HashMap<>();
        for (GeneratedCurriculum.Edge edge : interGroupEdges) {
            List<GeneratedCurriculum.Edge> targetIn = inEdges.getOrDefault(edge.target, new LinkedList<>());
            targetIn.add(edge);
            inEdges.put(edge.target, targetIn);
        }

        int max = Integer.MIN_VALUE;
        BlockDudeMap maxMap = null;
        for (Map.Entry<BlockDudeMap, List<GeneratedCurriculum.Edge>> entry : inEdges.entrySet()) {
            if (entry.getValue().size() > max) {
                max = entry.getValue().size();
                maxMap = entry.getKey();
            } else if (entry.getValue().size() == max) {
                // Break ties here
            }
        }
        if (maxMap == null) {
            return new LinkedList<>();
        }
        return inEdges.get(maxMap);
    }

    /**
     * Algorithm 1 from the paper. Assigns edges between maps in a group
     *
     * @param group
     * @return
     */
    private List<GeneratedCurriculum.Edge> infraGroupTransfer(Group group) {
        List<GeneratedCurriculum.Edge> edges = new LinkedList<>();
        // The fact that the group is sequenced by transfer potential to the final
        // target is very important here.
        // For every task in the group, find the best target _amongst the tasks that come after it in the ordered group_.
        // The last map in the sequenced group will not be assigned a target here, because its target is implicitly
        // the final target.
        for (int i = 0; i < group.sequenced.size() - 1; i++) {

            final BlockDudeMap map = group.sequenced.get(i);
            // Calculate the current task's potential with respect to all the other maps in the group
            double[] potentials = potentialFunction.calculatePotentials(map, group.sequenced);
            // Find the best target amongst the tasks that follow it in the sequenced group
            int maxIndex = Vector.maxIndexInRange(potentials, i + 1, potentials.length);
            edges.add(new GeneratedCurriculum.Edge(map, group.sequenced.get(maxIndex)));
        }

        assert edges.size() == group.sequenced.size() - 1;
        return edges;
    }

    /**
     * Algorithm 2 from the paper. Assigns edges between every source in the source pool to its best target in the target
     * pool.
     *
     * @param sourcePool
     * @param targetPool
     * @return a list of edges
     */
    private List<GeneratedCurriculum.Edge> assignInterGroupEdges(Group sourcePool, Group targetPool) {
        List<GeneratedCurriculum.Edge> edges = new LinkedList<>();
        double[][] potentials = potentialFunction.calculatePotentialAdjacencyMatrix(sourcePool.sequenced, targetPool.sequenced);
        // For each source task, find the best target from the target pool
        for (int i = 0; i < sourcePool.sequenced.size(); i++) {
            final BlockDudeMap source = sourcePool.sequenced.get(i);
            final int maxTargetIndex = Vector.maxIndexForRowInMatrix(potentials, i);
            // If the potential is not good enough, don't create the edge.
            if (potentials[i][maxTargetIndex] < MINIMUM_POTENTIAL_THRESHOLD) {
                continue;
            }
            final BlockDudeMap bestTarget = targetPool.sequenced.get(maxTargetIndex);
            edges.add(new GeneratedCurriculum.Edge(source, bestTarget));
        }
        return edges;
    }

    /**
     * Runs the curriculum generation process and logs the outputs of the various component algorithms to a string
     *
     * @param sources
     * @param target
     * @return
     */
    public String describeIntermediateSteps(Set<BlockDudeMap> sources, BlockDudeMap target) {
        String description = "Groups: \n";

        Set<BlockDudeMap> pruned = prune(sources, target);
        List<Group> groups = new LinkedList<>(generateGroups(pruned));

        for (int i = 0; i < groups.size(); i++) {
            Group group = groups.get(i);
            description += "Group " + i + ": " + group + "\n";
        }

        description += "Intragroup Edges: \n";

        List<List<GeneratedCurriculum.Edge>> intraGroupEdges = allIntraGroupEdges(new LinkedList<>(groups), target);

        for (int i = 0; i < intraGroupEdges.size(); i++) {
            List<GeneratedCurriculum.Edge> groupEdges = intraGroupEdges.get(i);
            description += "Group " + i + ": " + groupEdges + "\n";
        }

        List<GeneratedCurriculum.Edge> interGroupEdges = interGroupTransfer(new HashSet<>(groups));

        description += "Intergroup edges: \n";
        for (GeneratedCurriculum.Edge edge : interGroupEdges) {
            description += edge + "\n";
        }
        return description;
    }

    /**
     * A group is a set of maps that share the same binary feature descriptor.
     */
    private class Group implements Comparable<Group> {
        final int featureDescriptorInt;
        List<Boolean> binaryFeatureDescriptor;
        List<BlockDudeMap> sequenced;

        Group(Set<BlockDudeMap> maps) {
            sequenced = new LinkedList<>(maps);
            binaryFeatureDescriptor = MapFeatureExtractors.extractBinaryFeatureDescriptor(maps.iterator().next().representation);
            featureDescriptorInt = MapFeatureExtractors.extractBinaryFeatureDescriptorInt(maps.iterator().next().representation);
            // Verify that all passed in maps have the correct binary features
            for (BlockDudeMap map : maps) {
                assert (MapFeatureExtractors.extractBinaryFeatureDescriptor(map.representation).equals(binaryFeatureDescriptor));
            }
        }

        /**
         * Orders the groups task from least to greatest potential relative to a target task.
         * In the paper's usage of this, the target is always the final target.
         *
         * @param target
         */
        void sequenceRelativeTo(BlockDudeMap target) {
            List<TransferPotentialFunction.MapResult> potentials = potentialFunction.calculatePotentials(new HashSet<>(sequenced), target);
            List<BlockDudeMap> newSequence = new LinkedList<>();
            // Doing a map + collect will not preserve order here for some reason. Sticking with a for loop.
            for (TransferPotentialFunction.MapResult potential : potentials) {
                newSequence.add(potential.map);
            }
            sequenced = newSequence;
        }

        @Override
        public String toString() {
            String description = "[";
            for (BlockDudeMap map : sequenced) {
                description += map.index + ", ";
            }
            description = description.substring(0, description.length() - 2) + "]";
            return description;
        }

        @Override
        public int compareTo(Group group) {
            // First, order by size of the group
            if (group.sequenced.size() != sequenced.size()) {
                return Integer.compare(sequenced.size(), group.sequenced.size());
            } else {
                // Fallback lexical ordering.
                // Feature descriptors are unique to each group. So one should be larger or smaller.
                return Integer.compare(featureDescriptorInt, group.featureDescriptorInt);
            }
        }
    }
}
