package learning.transfer.curriculum;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class GeneratedCurriculum extends BlockDudeCurriculum {

    List<Step> steps;
    private Set<BlockDudeMap> tasks;
    private List<BlockDudeMap> orderedTasks;
    /**
     * @param edges Edges of a DAG
     */
    public GeneratedCurriculum(Set<Edge> edges) {
        // We need to decide the order to run the edges in. Because
        // the edges are from a DAG, we can take a topological ordering
        // telling us which maps need to be learned first.
        TopologicalOrderer orderer = new TopologicalOrderer(edges);
        List<BlockDudeMap> topologicalOrdering = orderer.topologicalOrder();
        relabelMaps(topologicalOrdering);
        tasks = orderer.tasks;
        orderedTasks = topologicalOrdering;

        // Now that we have a sequence of maps such that every map in the sequence depends only on maps before it,
        // we can construct the learning steps. For every task in sequence, we combine its inedges to form a step.
        this.steps = new LinkedList<>();
        int i = 0;
        for (BlockDudeMap map : topologicalOrdering) {
            // The first few maps will have no in-edges. That's fine, it just means they have no sources to transfer
            // from.
            List<BlockDudeMap> in = orderer.inEdges.get(map);
            Step step = new Step(in, map, i);
            steps.add(step);
            i++;
        }
        this.index = steps.hashCode();
    }

    /**
     * Makes sure maps belong to this curriculum object.

     */
    private void relabelMaps(List<BlockDudeMap> tasks) {
        int i = 0;
        for (BlockDudeMap map : tasks) {
            map.curriculum = this;
            map.index = i;
            i++;
        }
    }

    @Override
    public int numSteps() {
        return steps.size();
    }

    @Override
    public Step step(int i) {
        return steps.get(i);
    }

    @Override
    public BlockDudeMap map(int index) {
        return orderedTasks.get(index);
    }

    @Override
    public int numTasks() {
        return tasks.size();
    }

    public static class Edge {
        public final BlockDudeMap source;
        public final BlockDudeMap target;

        public Edge(BlockDudeMap source, BlockDudeMap target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public String toString() {
            return source.index + " -> " + target.index;
        }
    }

}
