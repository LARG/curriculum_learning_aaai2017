package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.*;
import burlap.oomdp.core.AbstractGroundedAction;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import com.github.andrewoma.dexx.collection.HashMap;

import java.util.Arrays;
import java.util.List;

public class VersionableLinearVFA implements DifferentiableStateValue, DifferentiableStateActionValue {


    /**
     * A feature database for which a unique function weight will be associated
     */
    protected FeatureDatabase featureDatabase;

    /**
     * A default weight for the functions
     */
    protected double defaultWeight = 0.0;

    /**
     * A map from feature identifiers to function weights
     */
    private HashMap<Integer, Double> weights;

    private List<StateFeature> currentFeatures;
    private double currentValue;
    private FunctionGradient currentGradient = null;

    private State lastState = null;
    private AbstractGroundedAction lastAction = null;


    public VersionableLinearVFA(FeatureDatabase featureDatabase) {
        this(featureDatabase, 0.0);
    }

    public VersionableLinearVFA(FeatureDatabase featureDatabase, HashMap<Integer, Double> weights) {
        this(featureDatabase);
        this.weights = weights;
    }

    public VersionableLinearVFA(FeatureDatabase featureDatabase, double defaultWeight) {
        this.featureDatabase = featureDatabase;
        this.defaultWeight = defaultWeight;
        this.weights = new HashMap<>();
    }

    /**
     * Returns the gradient of this function.
     *
     * @param s the input {@link State}
     * @param a the input {@link AbstractGroundedAction}
     * @return the {@link FunctionGradient} of this function at the input
     */
    @Override
    public FunctionGradient gradient(State s, AbstractGroundedAction a) {

        List<StateFeature> features;

        if (this.lastState == s && this.lastAction == a) {
            if (this.currentGradient != null) {
                return this.currentGradient;
            }
            features = this.currentFeatures;
        } else {
            features = this.featureDatabase.getActionFeaturesSets(s, Arrays.asList((GroundedAction) a)).get(0).features;
        }

        FunctionGradient gd = new FunctionGradient.SparseGradient(features.size());
        for (StateFeature sf : features) {
            gd.put(sf.id, sf.value);
        }
        this.currentGradient = gd;
        this.lastState = s;
        this.lastAction = a;
        this.currentFeatures = features;

        return gd;
    }


    /**
     * Returns the gradient of this function
     *
     * @param s the input state
     * @return the gradient
     */
    @Override
    public FunctionGradient gradient(State s) {

        List<StateFeature> features;

        if (this.lastState == s && this.lastAction == null) {
            if (this.currentGradient != null) {
                return this.currentGradient;
            }
            features = this.currentFeatures;
        } else {
            features = this.featureDatabase.getStateFeatures(s);
        }

        FunctionGradient gd = new FunctionGradient.SparseGradient(features.size());
        for (StateFeature sf : features) {
            gd.put(sf.id, sf.value);
        }
        this.currentGradient = gd;
        this.lastState = s;
        this.lastAction = null;
        this.currentFeatures = features;

        return gd;
    }

    /**
     * Sets the input of this function to the given {@link State} and returns
     * the value of it.
     *
     * @param s the {@link State} to input to the function
     * @return the value of this function evaluated on the input {@link State}
     */
    @Override
    public double evaluate(State s) {
        List<StateFeature> features = this.featureDatabase.getStateFeatures(s);
        double val = 0.;
        for (StateFeature sf : features) {
            double prod = sf.value * this.getWeight(sf.id);
            val += prod;
        }
        this.currentValue = val;
        this.currentGradient = null;
        this.currentFeatures = features;
        this.lastState = s;
        this.lastAction = null;
        return this.currentValue;
    }

    /**
     * Sets the input of this function to the given {@link State} and
     * {@link AbstractGroundedAction} and returns the value of it.
     *
     * @param s the input {@link State}
     * @param a the input action
     * @return the value of this function evaluated on the {@link State} and {@link AbstractGroundedAction}
     */
    @Override
    public double evaluate(State s, AbstractGroundedAction a) {

        List<StateFeature> features = this.featureDatabase.getActionFeaturesSets(s, Arrays.asList((GroundedAction) a)).get(0).features;
        double val = 0.;
        for (StateFeature sf : features) {
            double prod = sf.value * this.getWeight(sf.id);
            val += prod;
        }
        this.currentValue = val;
        this.currentGradient = null;
        this.currentFeatures = features;
        this.lastState = s;
        this.lastAction = a;
        return val;
    }

    /**
     * Returns the number of parameters defining this function. Note that some
     * implementations my have a dynamic number of parameters that grows or shrinks
     * over time. Consult the documentation for the specific implementation
     * for more information.
     *
     * @return the number of parameters defining this function.
     */
    @Override
    public int numParameters() {
        return this.weights.size();
    }

    /**
     * Returns the value of the ith parameter value
     *
     * @param i the parameter index
     * @return the double value of the ith parameter
     */
    @Override
    public double getParameter(int i) {
        return this.getWeight(i);
    }


    /**
     * Sets the value of the ith parameter to given value
     *
     * @param i the index of the parameter to set
     * @param p the parameter value to which it should be set
     */
    @Override
    public void setParameter(int i, double p) {
        this.weights = this.weights.put(i, p);
    }

    private double getWeight(int weightId) {
        Double stored = this.weights.get(weightId);
        if (stored == null) {
            this.weights = this.weights.put(weightId, this.defaultWeight);
            return this.defaultWeight;
        }
        return stored;
    }

    /**
     * Resets the parameters of this function to default values.
     */
    @Override
    public void resetParameters() {
        this.weights = new HashMap<>();
    }


    public HashMap<Integer, Double> getWeights() {
        return weights;
    }

    /**
     * Returns a copy of this {@link ParametricFunction}.
     *
     * @return a copy of this {@link ParametricFunction}.
     */
    @Override
    public VersionableLinearVFA copy() {
        VersionableLinearVFA vfa = new VersionableLinearVFA(this.featureDatabase.copy(), this.defaultWeight);
        vfa.weights = this.weights; // Purely functional, so no need to copy
        return vfa;
    }
}
