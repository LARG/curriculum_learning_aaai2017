package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.StateToFeatureVectorGenerator;
import burlap.behavior.singleagent.vfa.rbf.DistanceMetric;
import burlap.oomdp.core.states.State;

public class AlignmentMetric implements DistanceMetric {
    StateToFeatureVectorGenerator vectorGenerator;

    public AlignmentMetric(StateToFeatureVectorGenerator vectorGenerator) {
        this.vectorGenerator = vectorGenerator;
    }

    @Override
    public double distance(State s0, State s1) {
        double[] shell0 = vectorGenerator.generateFeatureVectorFrom(s0);
        double[] shell1 = vectorGenerator.generateFeatureVectorFrom(s1);

        int count = 0;
        for (int i = 0; i < shell0.length; i++) {
            count += shell1[i] == shell0[i] ? 1 : 0;
        }
        return (double)count / (double)shell0.length;
    }
}
