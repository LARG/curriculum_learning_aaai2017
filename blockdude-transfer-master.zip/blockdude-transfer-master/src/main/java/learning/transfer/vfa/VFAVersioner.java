package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.FeatureDatabase;
import burlap.oomdp.singleagent.GroundedAction;
import com.github.andrewoma.dexx.collection.HashMap;
import com.github.andrewoma.dexx.collection.Pair;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Maintains persistent snapshots of LinearVFAs
 * <p>
 * This is made space-efficient by using purely functional maps (hash array mapped tries)
 */
public class VFAVersioner {

    private FeatureDatabase featureDatabase;

    /**
     * Snapshots of weights
     */
    private List<HashMap<Integer, Double>> weightsSnapshots;

    /**
     * Buckets are an optional way to group snapshots together
     * <p>
     * List of weightsSnapshots indices that mark the end of a bucket
     */
    private List<Integer> buckets;


    public VFAVersioner(FeatureDatabase featureDatabase) {
        this.featureDatabase = featureDatabase;
        this.weightsSnapshots = new ArrayList<>();
        this.buckets = new ArrayList<>();
    }


    public void setFeatureDatabase(FeatureDatabase featureDatabase) {
        this.featureDatabase = featureDatabase;
    }

    /**
     * Save snapshot of weights
     */
    public void saveSnapshot(VersionableLinearVFA vfa) {
        this.weightsSnapshots.add(vfa.getWeights());

    }

    public DifferentiableStateActionValue functionForSnapshot(int i) {
        return new VersionableLinearVFA(featureDatabase, weightsSnapshots.get(i));
    }
    public DifferentiableStateActionValue functionForSnapshot(int bucket, int i) {
        int baseIndex = buckets.get(bucket);
        return functionForSnapshot(baseIndex + i);
    }

    /**
     * Buckets are an optional way to group snapshots together
     * <p>
     * This will mark the current snapshots as part of the same bucket
     * (not included previous snapshots of a different bucket)
     */
    public void addBucket() {
        if (weightsSnapshots.size() > 0) {
            buckets.add(weightsSnapshots.size() - 1);
        } else {
            buckets.add(0);
        }
    }

    public int numSnapshots() {
        return weightsSnapshots.size();
    }

    public int numBuckets() {
        return buckets.size();
    }

    public int sizeOfBucket(int i) {
        if (i == numBuckets() - 1) {
            return buckets.get(i) - numSnapshots();
        } else {
            return buckets.get(i + 1) - buckets.get(i);
        }

    }


    /**
     * Serialize VersionableLinearVFA
     * (n.b. not using Java serialization due to more complex deserialization logic)
     * <p>
     * Schema:
     * - Object: actionFeatureMultipliers
     * - k,v pairs of changes:
     * - int, double (n times)
     * - n (k,v pairs count)
     *
     * @param os
     * @throws IOException
     */
    public void serialize(ObjectOutputStream os) throws IOException {
        // Write out actionFeatureMultipliers
        Map<String, Integer> actionFeatureMultiplier = null;
        try {
            Field f = this.featureDatabase.getClass().getDeclaredField("actionFeatureMultiplier");
            f.setAccessible(true);
            actionFeatureMultiplier = ((Map<GroundedAction, Integer>) f.get(this.featureDatabase)).entrySet().stream().collect(Collectors.toMap(
                    e -> e.getKey().actionName(),
                    Map.Entry::getValue
            ));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
            throw new IOException("Could not serialize actionFeatureMultipliers");
        }
        os.writeObject(actionFeatureMultiplier);

        // Write out buckets
        os.writeObject(this.buckets);

        // Construct history of changes in snapshots
        com.github.andrewoma.dexx.collection.HashMap<Integer, Double> newerMap = this.weightsSnapshots.get(this.weightsSnapshots.size() - 1);
        ListIterator<com.github.andrewoma.dexx.collection.HashMap<Integer, Double>> rit = weightsSnapshots.listIterator(weightsSnapshots.size() - 1);
        List<List<Pair<Integer, Double>>> allChanges = new ArrayList<>(weightsSnapshots.size());
        while (rit.hasPrevious()) {
            com.github.andrewoma.dexx.collection.HashMap<Integer, Double> olderMap = rit.previous();
            allChanges.add(diffMap(newerMap, olderMap));

            newerMap = olderMap;
        }

        // Write number of snapshots + newerMap
        os.writeInt(weightsSnapshots.size());

        // At this point, newerMap is the first snapshot (initial weights), so write that out
        os.writeInt(newerMap.size()); // Write size
        for (Pair<Integer, Double> entry : newerMap) {
            os.writeInt(entry.component1());
            os.writeDouble(entry.component2());
        }

        // Now write all the changes (in reverse order)
        ListIterator<List<Pair<Integer, Double>>> rci = allChanges.listIterator(allChanges.size());
        while (rci.hasPrevious()) {
            List<Pair<Integer, Double>> changes = rci.previous();

            // Write number of changes
            os.writeInt(changes.size());

            for (Pair<Integer, Double> change : changes) {
                os.writeInt(change.component1());
                os.writeDouble(change.component2());
            }
        }
    }

    /**
     * Deserializes VersionableLinearVFA
     *
     * @param ois ObjectInputStream of data
     * @throws ClassNotFoundException
     * @throws IOException
     */
    public void deserialize(ObjectInputStream ois, List<GroundedAction> actions) throws ReflectiveOperationException, IOException {
        // Read actionFeatureMultipliers
        Map<GroundedAction, Double> actionFeatureMultipliers = ((Map<String, Double>) ois.readObject()).entrySet().stream().collect(Collectors.toMap(
                e -> actions.stream().filter(a -> a.actionName().equals(e.getKey())).findFirst().get(),
                Map.Entry::getValue
        ));

        Field f = this.featureDatabase.getClass().getDeclaredField("actionFeatureMultiplier");
        f.setAccessible(true);
        f.set(this.featureDatabase, actionFeatureMultipliers);

        // Read in buckets
        this.buckets = (List<Integer>) ois.readObject();

        // Read total size of snapshots
        int snapshotsSize = ois.readInt();
        List<com.github.andrewoma.dexx.collection.HashMap<Integer, Double>> snapshots = new ArrayList<>(snapshotsSize);

        // Read Snapshots
        com.github.andrewoma.dexx.collection.HashMap<Integer, Double> cWeights = new com.github.andrewoma.dexx.collection.HashMap<>();
        for (int s = 0; s < snapshotsSize; s++) {
            int changesSize = ois.readInt();

            for (int c = 0; c < changesSize; c++) {
                // Read k,v
                int k = ois.readInt();
                double v = ois.readDouble();

                cWeights = cWeights.put(k, v);
            }

            snapshots.add(cWeights);
        }
        this.weightsSnapshots = snapshots;
    }

    /**
     * Creates list of different pairs between two versions of a map
     *
     * @param newer newer map
     * @param older older map
     * @return list of changes
     */
    private List<Pair<Integer, Double>> diffMap(com.github.andrewoma.dexx.collection.HashMap<Integer, Double> newer, com.github.andrewoma.dexx.collection.HashMap<Integer, Double> older) {
        Iterator<Pair<Integer, Double>> it = newer.iterator();
        List<Pair<Integer, Double>> changes = new ArrayList<>();

        while (it.hasNext()) {
            Pair<Integer, Double> kv = it.next();
            Integer newerKey = kv.component1();
            Double newerVal = kv.component2();

            Double olderVal = older.get(newerKey);
            // Using object comparison, because as persistent data structures, these values should be shared if same
            if (olderVal != newerVal) {
                changes.add(kv);
            }
        }

        return changes;
    }
}
