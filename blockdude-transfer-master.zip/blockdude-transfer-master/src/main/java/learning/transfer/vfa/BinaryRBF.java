package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.rbf.DistanceMetric;
import burlap.behavior.singleagent.vfa.rbf.RBF;
import burlap.oomdp.core.states.State;

/**
 For debugging purposes. Permits no partial responses.
 */
public class BinaryRBF extends RBF {

    public BinaryRBF(State centeredState, DistanceMetric metric) {
        super(centeredState, metric);
    }

    @Override
    public double responseFor(State input) {
        double distance = metric.distance(centeredState, input);
        return distance == 0.0 ? 1.0 : 0.0;
    }
}
