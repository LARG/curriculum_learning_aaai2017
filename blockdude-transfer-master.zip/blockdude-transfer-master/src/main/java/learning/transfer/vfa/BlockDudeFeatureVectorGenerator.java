package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.StateToFeatureVectorGenerator;

public interface BlockDudeFeatureVectorGenerator extends StateToFeatureVectorGenerator {

    int[] getFeatureMin();

    int[] getFeatureMax();

    int numFeatures();
}
