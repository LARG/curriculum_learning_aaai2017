package learning.transfer.vfa;

import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import learning.utilities.StateFeatureExtractors;
import org.apache.commons.lang3.ArrayUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BlockDudeRelativeFeatureVectorGenerator implements BlockDudeFeatureVectorGenerator {

    private static Map<State, double[]> cache = new ConcurrentHashMap<>();
    private final int mapWidth;
    private final int mapHeight;
    private final int perceptionSize;
    private final int[] featureMin;
    private final int[] featureMax;

    public BlockDudeRelativeFeatureVectorGenerator(int mapWidth, int mapHeight, int perceptionSize, int maxColumnHeight) {
        this.mapWidth = mapWidth;
        this.mapHeight = mapHeight;
        this.perceptionSize = perceptionSize;
        featureMin = new int[numFeatures()];
        featureMax = new int[numFeatures()];

        // Column height
        featureMin[0] = 0;
        featureMax[0] = maxColumnHeight;

        // Distance to goal
        featureMin[1] = 0;
        featureMax[1] = mapWidth;

        // Y position
        featureMin[2] = 1;
        // TODO: Explore removing center states to make learning more difficult
        // Making y position max value as maxColumnHeight (instead of maxColumnHeight + 1)
        // simulates this in a very simple manner
        featureMax[2] = maxColumnHeight;

        // Facing
        featureMin[3] = 0;
        featureMax[3] = 1;

        // Holding
        featureMin[4] = 0;
        featureMax[4] = 1;

        for (int i = 0; i < perceptionSize * 2; i++) {
            featureMin[5 + i] = 0;
            featureMax[5 + i] = maxColumnHeight;
        }
    }

    private static double normalize(Double value, Double min, Double max) {
        return (value - min) / (max - min);
    }

    private static double normalize(int value, int min, int max) {
        return normalize((double) value, (double) min, (double) max);
    }

    @Override
    public double[] generateFeatureVectorFrom(State s) {
        if (s instanceof MockCenterState) {
            return ((MockCenterState) s).features;
        }
        if (cache.containsKey(s)) {
            return cache.get(s);
        }

        List<Double> featureVector = new ArrayList<>();

        StateFeatureExtractors.appendColumnHeightFeatureVector(s, featureVector, mapWidth);
        StateFeatureExtractors.appendDistanceFromGoalFeatureVector(s, featureVector);
        StateFeatureExtractors.appendYPositionFeatureVector(s, featureVector);
        StateFeatureExtractors.appendFacingFeatureVector(s, featureVector);
        StateFeatureExtractors.appendHoldingFeatureVector(s, featureVector);
        generateBlockHeightFeatureVector(s, featureVector, perceptionSize);
        double[] result = ArrayUtils.toPrimitive(featureVector.toArray(new Double[featureVector.size()]));
        cache.putIfAbsent(s, result);

        for (int i = 0; i < result.length; i++) {
            //assert (result[i] <= featureMax[i]);
            //assert (result[i] >= featureMin[i]);
        }
        /*
        if (cache.containsKey(s)) {
            double[] cached = cache.get(s);
            for (int i = 0; i < cached.length; i++) {
                assert(cached[i] == result[i]);
            }
            return cache.get(s);
        }*/
        return result;
    }

    public int numFeatures() {
        return 2 * perceptionSize + 5;
    }

    private void generateBlockHeightFeatureVector(State s, List<Double> vector, int perceptionSize) {
        List<ObjectInstance> blocks = s.getObjectsOfClass(BlockDude.CLASSBLOCK);

        ObjectInstance agentObj = s.getObjectsOfClass(BlockDude.CLASSAGENT).get(0);
        final int agentX = (int) agentObj.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
        double[] blockHeights = new double[perceptionSize * 2];

        for (ObjectInstance block : blocks) {
            int blockX = (int) block.getValueForAttribute(BlockDude.ATTX).getNumericRepresentation();
            final int blockDiff = blockX - agentX;
            if (-perceptionSize <= blockDiff && blockDiff <= perceptionSize && blockDiff != 0) {
                final int index = (blockDiff > 0) ? blockDiff + perceptionSize - 1 : blockDiff + perceptionSize;
                // Since min blockX is 1
                blockHeights[index]++;
            }
        }

        for (double blockHeight : blockHeights) {
            vector.add(blockHeight);
        }
    }

    @Override
    public int[] getFeatureMax() {
        return featureMax.clone();
    }

    @Override
    public int[] getFeatureMin() {
        return featureMin.clone();
    }
}
