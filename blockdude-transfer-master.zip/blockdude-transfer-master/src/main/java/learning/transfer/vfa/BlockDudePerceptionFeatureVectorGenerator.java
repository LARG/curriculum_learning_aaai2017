package learning.transfer.vfa;

import burlap.oomdp.core.states.State;
import learning.utilities.StateFeatureExtractors;
import learning.utilities.StateUtilities;
import org.apache.commons.lang3.ArrayUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BlockDudePerceptionFeatureVectorGenerator implements BlockDudeFeatureVectorGenerator {
    private static Map<State, double[]> cache = new ConcurrentHashMap<>();
    public final int[] featureMin;
    public final int[] featureMax;
    private final int mapWidth;
    private final int mapHeight;
    private final int depth;

    public BlockDudePerceptionFeatureVectorGenerator(int mapWidth, int mapHeight, int depth) {
        this.mapHeight = mapHeight;
        this.mapWidth = mapWidth;
        this.depth = depth;

        featureMin = new int[numFeatures()];
        featureMax = new int[numFeatures()];

        // Column height
        featureMin[0] = 0;
        featureMax[0] = 0;

        // Distance to goal
        featureMin[1] = 0;
        featureMax[1] = mapWidth;

        // Y position
        featureMin[2] = 0;
        featureMax[2] = mapHeight - 1;

        // Facing
        featureMin[3] = 0;
        featureMax[3] = 1;

        // Holding
        featureMin[4] = 0;
        featureMax[4] = 1;

        for (int i = 0; i < StateUtilities.perceptionShellSize(depth); i++) {
            featureMin[5 + i] = 0;
            featureMax[5 + i] = 1;
        }
    }

    public int numFeatures() {
        return 5 + StateUtilities.perceptionShellSize(depth);
    }

    @Override
    public double[] generateFeatureVectorFrom(State s) {
        if (s instanceof MockCenterState) {
            return ((MockCenterState) s).features;
        }
        if (cache.containsKey(s)) {
            return cache.get(s);
        }
        List<Double> featureVector = new ArrayList<>();
        StateFeatureExtractors.appendColumnHeightFeatureVector(s, featureVector, mapWidth);
        StateFeatureExtractors.appendDistanceFromGoalFeatureVector(s, featureVector);
        StateFeatureExtractors.appendYPositionFeatureVector(s, featureVector);
        StateFeatureExtractors.appendFacingFeatureVector(s, featureVector);
        StateFeatureExtractors.appendHoldingFeatureVector(s, featureVector);
        StateFeatureExtractors.appendPerceptionShellFeatureVector(s, featureVector, depth, mapWidth);
        double[] result = ArrayUtils.toPrimitive(featureVector.toArray(new Double[featureVector.size()]));

        cache.putIfAbsent(s, result);
        return result;
    }

    @Override
    public int[] getFeatureMin() {
        return featureMin;
    }

    @Override
    public int[] getFeatureMax() {
        return featureMax;
    }
}
