package learning.transfer.vfa;

import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MockCenterState implements State {
    public double[] features;

    public MockCenterState(double[] features) {
        this.features = features;
    }

    @Override
    public State copy() {
        return null;
    }

    @Override
    public State addObject(ObjectInstance o) {
        return null;
    }

    @Override
    public State addAllObjects(Collection<ObjectInstance> objects) {
        return null;
    }

    @Override
    public State removeObject(String oname) {
        return null;
    }

    @Override
    public <T> State setObjectsValue(String objectName, String attName, T value) {
        return null;
    }

    @Override
    public State removeObject(ObjectInstance o) {
        return null;
    }

    @Override
    public State removeAllObjects(Collection<ObjectInstance> objects) {
        return null;
    }

    @Override
    public State renameObject(String originalName, String newName) {
        return null;
    }

    @Override
    public State renameObject(ObjectInstance o, String newName) {
        return null;
    }

    @Override
    public Map<String, String> getObjectMatchingTo(State so, boolean enforceStateExactness) {
        return null;
    }

    @Override
    public int numTotalObjects() {
        return 0;
    }

    @Override
    public ObjectInstance getObject(String oname) {
        return null;
    }

    @Override
    public List<ObjectInstance> getAllObjects() {
        return null;
    }

    @Override
    public List<ObjectInstance> getObjectsOfClass(String oclass) {
        return null;
    }

    @Override
    public ObjectInstance getFirstObjectOfClass(String oclass) {
        return null;
    }

    @Override
    public Set<String> getObjectClassesPresent() {
        return null;
    }

    @Override
    public List<List<ObjectInstance>> getAllObjectsByClass() {
        return null;
    }

    @Override
    public String getCompleteStateDescription() {
        return null;
    }

    @Override
    public Map<String, List<String>> getAllUnsetAttributes() {
        return null;
    }

    @Override
    public String getCompleteStateDescriptionWithUnsetAttributesAsNull() {
        return null;
    }

    @Override
    public List<List<String>> getPossibleBindingsGivenParamOrderGroups(String[] paramClasses, String[] paramOrderGroups) {
        return null;
    }
}
