package learning.transfer;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.RewardFunction;
import learning.transfer.advice.*;

import java.util.List;
import java.util.logging.Logger;

public class ExtendedShapingRewardFunction implements RewardFunction {
    private static final Logger log = Logger.getLogger(ExtendedShapingRewardFunction.class.getName());

    private final RewardFunction baseFunction;
    private final AdviceFunction adviceFunction;

    private NextAction nextAction;

    public ExtendedShapingRewardFunction(RewardFunction baseFunction, AdviceFunction adviceFunction) {
        this.baseFunction = baseFunction;
        this.adviceFunction = adviceFunction;
    }

    public static ExtendedShapingRewardFunction create(RewardFunction baseRF, List<DifferentiableStateActionValue> sources, boolean lookback, double gamma) {
        ShapingFunction shapingFunction;
        if (lookback) {
            shapingFunction = new LookBackAdviceFunction(gamma);
        } else {
            shapingFunction = new LookAheadAdviceFunction(gamma);
        }
        final ExtendedShapingRewardFunction rf =
                new ExtendedShapingRewardFunction(baseRF, new AdviceFunction(shapingFunction, new TransferFAPotentialFunction(sources)));
        return rf;
    }

    public void setNextAction(NextAction nextAction) {
        this.nextAction = nextAction;
    }

    public AdviceFunction getAdviceFunction() {
        return adviceFunction;
    }

    @Override
    public double reward(State s, GroundedAction a, State sprime) {
        double reward = baseFunction.reward(s, a, sprime);

        if (nextAction == null) {
            log.fine("No advice function provided; going with base reward.");
        } else {
//            System.out.printf("a: %s, aprime: %s\n", a.actionName(), nextAction.nextAction(sprime).actionName());
//            System.out.println(adviceFunction.advice(s, a, sprime, nextAction.nextAction(sprime)));
            GroundedAction aprime = nextAction.nextAction(sprime);
            double advice = adviceFunction.advice(s, a, sprime, aprime);
            reward += advice;
        }

        return reward;
    }
}
