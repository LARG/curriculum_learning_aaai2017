package learning.visualization;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.visualizer.ObjectPainter;
import burlap.oomdp.visualizer.StateRenderLayer;
import burlap.oomdp.visualizer.Visualizer;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.List;

/**
 A state visualizer for Block Dude. It is faithful to the original game's pixel art, and has an option to enable color.

 */
public class TastefulBlockDudeVisualizer {

    /**
     Returns a {@link burlap.oomdp.visualizer.Visualizer} for {@link burlap.domain.singleagent.blockdude.BlockDude}.

     @param maxx the max x dimensionality of the world
     @param maxy the max y dimensionality of the world
     @return a {@link burlap.oomdp.visualizer.Visualizer} for {@link burlap.domain.singleagent.blockdude.BlockDude}
     */
    public static Visualizer getVisualizer(HeatmapRenderLayer layer, int maxx, int maxy) {

        return new Visualizer(prepareRenderLayer(layer, maxx, maxy, true));
    }

    private static StateRenderLayer prepareRenderLayer(StateRenderLayer srl, int maxx, int maxy, boolean blackAndWhite) {
        srl.addObjectClassPainter(BlockDude.CLASSBRICKS, new TastefulBricksPainter(maxx, maxy, blackAndWhite));
        srl.addObjectClassPainter(BlockDude.CLASSAGENT, new TastefulAgentPainter(maxx, maxy, blackAndWhite));
        srl.addObjectClassPainter(BlockDude.CLASSEXIT, new TastefulExitPainter(maxx, maxy, blackAndWhite));
        srl.addObjectClassPainter(BlockDude.CLASSBLOCK, new TastefulBlockPainter(maxx, maxy, blackAndWhite));

        return srl;
    }

    public static Visualizer getVisualizer(int maxx, int maxy) {
        Visualizer v = new Visualizer(getStateRenderLayer(maxx, maxy));
        return v;
    }

    /**
     Returns a {@link burlap.oomdp.visualizer.StateRenderLayer} for {@link burlap.domain.singleagent.blockdude.BlockDudeVisualizer}.

     @param maxx the max x dimensionality of the world
     @param maxy the max y dimensionality of the world
     @return a {@link burlap.oomdp.visualizer.StateRenderLayer} for {@link burlap.domain.singleagent.blockdude.BlockDudeVisualizer}.
     */
    public static StateRenderLayer getStateRenderLayer(int maxx, int maxy) {

        StateRenderLayer srl = new StateRenderLayer();
        return prepareRenderLayer(srl, maxx, maxy, false);
    }

    public static StateRenderLayer getStateRenderLayer(DifferentiableStateActionValue vfa, List<GroundedAction> actions, int maxx, int maxy) {
        StateRenderLayer srl = new HeatmapRenderLayer(vfa, actions, maxx, maxy);
        return prepareRenderLayer(srl, maxx, maxy, true);
    }

    /**
     A class for rendering the agent as a blue square with a gold eye indicating the direction its facing.
     */
    public static class TastefulAgentPainter implements ObjectPainter {

        public int minx = 0;
        public int miny = 0;

        public int maxx;
        public int maxy;

        boolean blackAndWhite;

        /**
         Initializes.

         @param maxx the max x dimensionality of the world
         @param maxy the max y dimensionality of the world
         */
        public TastefulAgentPainter(int maxx, int maxy, boolean blackAndWhite) {
            this.maxx = maxx;
            this.maxy = maxy;
            this.blackAndWhite = blackAndWhite;
        }

        @Override
        public void paintObject(Graphics2D g2, State s, ObjectInstance ob,
                                float cWidth, float cHeight) {

            if (!blackAndWhite) {
                // Solarized blue
                g2.setColor(new Color(0x26, 0x8b, 0xd2));
            } else {
                g2.setColor(Color.BLACK);
            }

            float domainXScale = (maxx) - minx;
            float domainYScale = (maxy) - miny;

            //determine the normalized width
            float width = (1.0f / domainXScale) * cWidth;
            float height = (1.0f / domainYScale) * cHeight;

            float rx = ob.getIntValForAttribute(BlockDude.ATTX) * width;
            float ry = cHeight - height - ob.getIntValForAttribute(BlockDude.ATTY) * height;


            float pixelWidth = width / 8.0f;
            float pixelHeight = height / 8.0f;

            g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry + 7 * pixelHeight, pixelWidth * 2, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 4 * pixelWidth, ry + 7 * pixelHeight, pixelWidth * 2, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 3 * pixelWidth, ry + 5 * pixelHeight, pixelWidth, 2 * pixelHeight));

            g2.fill(new Rectangle2D.Float(rx + 1 * pixelWidth, ry + 5 * pixelHeight, pixelWidth, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 5 * pixelWidth, ry + 5 * pixelHeight, pixelWidth, pixelHeight));

            g2.fill(new Rectangle2D.Float(rx + 2 * pixelWidth, ry + 4 * pixelHeight, pixelWidth, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 4 * pixelWidth, ry + 4 * pixelHeight, pixelWidth, pixelHeight));

            if (ob.getIntValForAttribute(BlockDude.ATTDIR) == 1) {
                g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry + 1 * pixelHeight, pixelWidth, 3 * pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 5 * pixelWidth, ry + 3 * pixelHeight, pixelWidth, pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 4 * pixelWidth, ry + 2 * pixelHeight, pixelWidth, pixelHeight));
                // Solarized green
                if (!blackAndWhite) {
                    g2.setColor(new Color(0x85, 0x99, 0x00));
                } else {
                    g2.setColor(Color.BLACK);
                }
                g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry + 1 * pixelHeight, 6 * pixelWidth, pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 2 * pixelWidth, ry, 3 * pixelWidth, pixelHeight));
            } else {
                g2.fill(new Rectangle2D.Float(rx + 5 * pixelWidth, ry + 1 * pixelHeight, pixelWidth, 3 * pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 1 * pixelWidth, ry + 3 * pixelHeight, pixelWidth, pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 2 * pixelWidth, ry + 2 * pixelHeight, pixelWidth, pixelHeight));
                // Solarized green
                if (!blackAndWhite) {
                    g2.setColor(new Color(0x85, 0x99, 0x00));
                } else {
                    g2.setColor(Color.BLACK);
                }
                g2.fill(new Rectangle2D.Float(rx, ry + 1 * pixelHeight, 6 * pixelWidth, pixelHeight));
                g2.fill(new Rectangle2D.Float(rx + 2 * pixelWidth, ry, 3 * pixelWidth, pixelHeight));
            }



        }


    }


    /**
     A class for rendering a block as a grey square
     */
    public static class TastefulBlockPainter implements ObjectPainter {

        public int minx = 0;
        public int miny = 0;

        public int maxx;
        public int maxy;

        boolean blackAndWhite;

        /**
         Initializes.

         @param maxx the max x dimensionality of the world
         @param maxy the max y dimensionality of the world
         */
        public TastefulBlockPainter(int maxx, int maxy, boolean blackAndWhite) {
            this.maxx = maxx;
            this.maxy = maxy;
            this.blackAndWhite = blackAndWhite;
        }


        @Override
        public void paintObject(Graphics2D g2, State s, ObjectInstance ob,
                                float cWidth, float cHeight) {

            if (!blackAndWhite) {
                // Solarized base00
                g2.setColor(new Color(0x65, 0x7b, 0x83));
            } else {
                g2.setColor(Color.BLACK);
            }

            float domainXScale = (maxx) - minx;
            float domainYScale = (maxy) - miny;

            //determine then normalized width
            float width = (1.0f / domainXScale) * cWidth;
            float height = (1.0f / domainYScale) * cHeight;

            float rx = ob.getIntValForAttribute(BlockDude.ATTX) * width;
            float ry = cHeight - height - ob.getIntValForAttribute(BlockDude.ATTY) * height;

            float pixelWidth = width / 8.0f;
            float pixelHeight = height / 8.0f;

            g2.fill(new Rectangle2D.Float(rx, ry, pixelWidth, height));
            g2.fill(new Rectangle2D.Float(rx + 7 * pixelWidth, ry, pixelWidth, height));

            g2.fill(new Rectangle2D.Float(rx, ry, width, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx, ry + 7 * pixelHeight, width, pixelHeight));

        }


    }


    /**
     A class for rendering an exit with a black square
     */
    public static class TastefulExitPainter implements ObjectPainter {


        public int minx = 0;
        public int miny = 0;

        public int maxx;
        public int maxy;

        boolean blackAndWhite;

        /**
         Initializes.

         @param maxx the max x dimensionality of the world
         @param maxy the max y dimensionality of the world
         */
        public TastefulExitPainter(int maxx, int maxy, boolean blackAndWhite) {

            this.maxx = maxx;
            this.maxy = maxy;
            this.blackAndWhite = blackAndWhite;
        }

        @Override
        public void paintObject(Graphics2D g2, State s, ObjectInstance ob,
                                float cWidth, float cHeight) {

            g2.setColor(Color.black);

            float domainXScale = (maxx) - minx;
            float domainYScale = (maxy) - miny;

            //determine then normalized width
            float width = (1.0f / domainXScale) * cWidth;
            float height = (1.0f / domainYScale) * cHeight;

            float rx = ob.getIntValForAttribute(BlockDude.ATTX) * width;
            float ry = cHeight - height - ob.getIntValForAttribute(BlockDude.ATTY) * height;

            float pixelWidth = width / 8.0f;
            float pixelHeight = height / 8.0f;

            g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry, pixelWidth, height));
            g2.fill(new Rectangle2D.Float(rx + 7 * pixelWidth, ry, pixelWidth, height));

            g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry, 7 * pixelWidth, pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + pixelWidth, ry + 7 * pixelHeight, 7 * pixelWidth, pixelHeight));
            // Door knob
            g2.fill(new Rectangle2D.Float(rx + 6 * pixelWidth, ry + 3 * pixelHeight, pixelWidth, pixelHeight));

        }


    }


    /**
     A class for rendering bricks as green squares. Since all bricks are specified in a single 1D array, rather than
     a separate object for each, this class will iterate through the array and paint each brick.
     */
    public static class TastefulBricksPainter implements ObjectPainter {

        public int minx = 0;
        public int miny = 0;

        public int maxx;
        public int maxy;

        boolean blackAndWhite;
        /**
         Initializes.

         @param maxx the max x dimensionality of the world
         @param maxy the max y dimensionality of the world
         */
        public TastefulBricksPainter(int maxx, int maxy, boolean blackAndWhite) {
            this.maxx = maxx;
            this.maxy = maxy;
            this.blackAndWhite = blackAndWhite;
        }


        @Override
        public void paintObject(Graphics2D g2, State s, ObjectInstance ob, float cWidth, float cHeight) {

            float domainXScale = (maxx) - minx;
            float domainYScale = (maxy) - miny;

            //determine then normalized width
            float width = (1.0f / domainXScale) * cWidth;
            float height = (1.0f / domainYScale) * cHeight;

            int[] map = ob.getIntArrayValForAttribute(BlockDude.ATTMAP);

            for (int i = 0; i < map.length; i++) {

                int x = i % this.maxx;
                int y = i / this.maxx;

                float rx = x * width;
                float ry = cHeight - height - y * height;
                if (!blackAndWhite) {
                    g2.setColor(new Color(0xfd, 0xf6, 0xe3));
                    g2.fill(new Rectangle2D.Float(rx, ry, width, height));
                }
                if (map[i] == 1) {
                    if (!blackAndWhite) {
                        // Solarized red
                        g2.setColor(new Color(0xdc, 0x32, 0x2f));
                    } else {
                        g2.setColor(Color.BLACK);
                    }
                    paintBrickPattern(g2, rx, ry, width, height);

                }

            }

        }

        private void paintBrickPattern(Graphics2D g2, float rx, float ry, float width, float height) {
            float pixelHeight = height / 8.0f;
            float pixelWidth = width / 8.0f;

            // The pattern of filled pixels
            // ***** **
            // ***** **
            //
            // *******
            // *******
            //
            // ***** **
            // ***** **

            // Top row
            g2.fill(new Rectangle2D.Float(rx, ry, 5 * pixelWidth, 2 * pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 6 * pixelWidth, ry, 2 * pixelWidth, 2 * pixelHeight));

            // Middle row
            g2.fill(new Rectangle2D.Float(rx, ry + 3 * pixelHeight, 7 * pixelWidth, 2 * pixelHeight));

            // Bottom Row
            g2.fill(new Rectangle2D.Float(rx, ry + 6 * pixelHeight, 5 * pixelWidth, 2 * pixelHeight));
            g2.fill(new Rectangle2D.Float(rx + 6 * pixelWidth, ry + 6 * pixelHeight, 2 * pixelWidth, 2 * pixelHeight));

        }
    }

}
