package learning.visualization;

import learning.experiment.AggregatedTrial;
import org.apache.commons.lang3.tuple.Pair;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;
import org.jfree.ui.ApplicationFrame;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Plotter extends ApplicationFrame {

    public boolean confidences = true;
    public boolean filledError = true;
    int n;
    private JFreeChart chart;


    public Plotter(final String title, final String xLabel, final String yLabel, List<Line> lines, int n, Double pValue, boolean filledError) {
        super(title);
        this.filledError = filledError;
        configure(title, xLabel, yLabel, lines, n, pValue);
    }

    private void configure(final String title, final String xLabel, final String yLabel, List<Line> lines, int n, Double pValue) {
        this.n = n;

        final YIntervalSeriesCollection linesSet = new YIntervalSeriesCollection();
        // For each line, calculate confidences
        for (Line line : lines) {
            YIntervalSeries lineSet = new YIntervalSeries(line.name);
            List<AggregatedTrial.StatPair> ySeries = line.ySeries;
            List<Integer> xSeries = line.xSeries;

            int offset = line.offset;
            List<List<Double>> confidenceSet = AggregatedTrial.getConfidences(ySeries, pValue, n);
            for (int i = 0; i < confidenceSet.size(); i++) {
                List<Double> interval = confidenceSet.get(i);
                lineSet.add(xSeries.get(i) + offset, interval.get(0), interval.get(1), interval.get(2));
            }
            linesSet.addSeries(lineSet);
        }


        chart = createChart(linesSet, appendStatInformation(title, pValue, n), xLabel, yLabel);

        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(2000, 1320));
        setContentPane(chartPanel);

    }

    private JFreeChart createChart(final YIntervalSeriesCollection errorSet, String title, String xLabel, String yLabel) {

        // create the chart...
        JFreeChart chart = ChartFactory.createXYLineChart(title, xLabel, yLabel, errorSet);

        // get a reference to the plot for further customisation...
        final XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.lightGray);

        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        if (this.confidences) {
            if (filledError) {
                plot.setRenderer(createFilledErrorRenderer());
            } else {
                plot.setRenderer(createErrorBarRenderer());
            }
        }

        // Tick marks on integers only
        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        final NumberAxis domainAxis = (NumberAxis) plot.getDomainAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

        return chart;

    }

    private String appendStatInformation(String title, Double pValue, int n) {
        return title + " p=" + pValue + ", n=" + n;
    }

    protected XYErrorRenderer createErrorBarRenderer() {
        XYErrorRenderer renderer = new XYErrorRenderer();
        // Turn on lines
        renderer.setBaseLinesVisible(true);
        return renderer;
    }

    /**
     * Creates a DeviationRenderer to use for the trial average plots
     *
     * @return a DeviationRenderer
     */
    protected DeviationRenderer createFilledErrorRenderer() {
        DeviationRenderer renderer = new DeviationRenderer(true, false);

        for (int i = 0; i < DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE.length; i++) {
            Color c = (Color) DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE[i];
            Color nc = new Color(c.getRed(), c.getGreen(), c.getBlue(), 100);
            renderer.setSeriesFillPaint(i, nc);
        }

        return renderer;
    }

    public void saveAsPNG(File file) {
        try {
            ChartUtilities.saveChartAsPNG(file, chart, 2000 / 2, 1320 / 2);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Represents a labeled line to be plotted.
     */
    public static class Line {
        public final String name;
        public final List<Integer> xSeries;
        public final List<AggregatedTrial.StatPair> ySeries;
        public int offset = 0;

        /**
         * Takes a y series and generates the x series based on the space parameter
         * @param name
         * @param ySeries
         * @param xSpace
         */
        public Line(String name, List<AggregatedTrial.StatPair> ySeries, int xSpace) {
            this.name = name;
            this.ySeries = ySeries;
            this.xSeries = new LinkedList<>();
            for (int i = 0; i < ySeries.size(); i += xSpace) {
                this.xSeries.add(i);
            }
        }

        public Line(String name, List<Pair<Integer, AggregatedTrial.StatPair>> combinedSeries) {
            this.name = name;
            xSeries = new LinkedList<>();
            ySeries = new LinkedList<>();
            for (Pair<Integer, AggregatedTrial.StatPair> entry : combinedSeries) {
                xSeries.add(entry.getKey());
                ySeries.add(entry.getValue());
            }
        }
    }
}
