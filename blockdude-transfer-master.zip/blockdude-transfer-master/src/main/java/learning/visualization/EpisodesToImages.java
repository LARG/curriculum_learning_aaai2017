package learning.visualization;

import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.datastructures.AlphanumericSorting;
import burlap.oomdp.core.states.State;
import learning.experiment.WorldComponents;
import learning.transfer.vfa.VFAVersioner;

import java.io.FilenameFilter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class EpisodesToImages {

    public static void process(Path inDirectory, Path outDirectory, WorldComponents wc, VFAVersioner versioner) {
        List<String> files = EpisodesToImages.parseEpisodeFiles(inDirectory);
        MapRenderer mr = new MapRenderer(wc.mapWidth(), wc.mapHeight());
        IntStream.range(0, files.size()).parallel().forEach((e) -> {
            EpisodeAnalysis ea = EpisodeAnalysis.parseFileIntoEA(files.get(e), wc.domain);
            List<State> states = ea.stateSequence;
            for (int s = 0; s < ea.numTimeSteps(); s++) {
                State state = states.get(s);
                String fileName = "" + e + "-" + s + ".png";
                Path path = outDirectory.resolve(fileName);
                DifferentiableStateActionValue vfa = null;
                if (versioner != null) {
                    vfa = versioner.functionForSnapshot(e, s);
                }
                path.toFile().mkdirs();
                if (vfa != null) {
                    mr.saveImage(state, vfa, wc.actions(), path.toFile());
                } else {
                    mr.saveImage(state, path.toFile());
                }
            }
        });

    }

    private static List<String> parseEpisodeFiles(Path directory) {
        final String ext = ".episode";

        FilenameFilter filter = (dir, name) -> {
            return name.endsWith(ext);
        };
        String[] children = directory.toFile().list(filter);
        Arrays.sort(children, new AlphanumericSorting());

        List<String> episodeFiles = new ArrayList<>(children.length);

        for (int i = 0; i < children.length; i++) {
            episodeFiles.add(directory + "/" + children[i]);
        }
        return episodeFiles;
    }


}
