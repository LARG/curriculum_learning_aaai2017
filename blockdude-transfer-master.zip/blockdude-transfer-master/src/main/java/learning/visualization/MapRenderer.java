package learning.visualization;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.visualizer.StateRenderLayer;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class MapRenderer {

    private int maxX;
    private int maxY;

    public MapRenderer(int maxX, int maxY) {
        this.maxX = maxX;
        this.maxY = maxY;
    }

    public void saveImage(State state, File outFile) {
        StateRenderLayer renderLayer = TastefulBlockDudeVisualizer.getStateRenderLayer(maxX, maxY);
        saveImage(state, renderLayer, outFile);
    }

    private void saveImage(State state, StateRenderLayer renderLayer, File outFile) {
        double height = 800.0 * (double)maxY / (double)maxX;
        BufferedImage bi = new BufferedImage(800, (int)height, BufferedImage.TYPE_INT_ARGB);

        Graphics2D ig2 = bi.createGraphics();
        renderLayer.updateState(state);
        renderLayer.render(ig2,800,(float)height);

        try {
            ImageIO.write(bi, "PNG", outFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveImage(State state, DifferentiableStateActionValue vfa, List<GroundedAction> actions, File outFile) {
        StateRenderLayer renderLayer = TastefulBlockDudeVisualizer.getStateRenderLayer(vfa, actions, maxX, maxY);
        saveImage(state, renderLayer, outFile);
    }
}
