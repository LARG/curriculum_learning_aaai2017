package learning.visualization;

import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.domain.singleagent.blockdude.BlockDude;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.visualizer.StateRenderLayer;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.List;

public class HeatmapRenderLayer extends StateRenderLayer {

    private static final int HEATMAP_TRANSPARENCY = 230;

    // (HS)B Colors
    // All values between 0-1
    private static final float[][] COLORS = {
            {0.555f, 1.0f},
            {0.333f, 1.0f},
            {0.1666f, 1.0f},
            {0.0f, 1.0f},
            {0.8333f, 1.0f}
    };
    private static final double GLOBAL_REWARD_MAX = 50.0;
    private static final double GLOBAL_REWARD_MIN = -50.0;
    private final List<GroundedAction> actions;
    private DifferentiableStateActionValue vfa;
    private int minx = 0;
    private int miny = 0;
    private int maxx;
    private int maxy;

    /**
     Initializes.

     @param maxx the max x dimensionality of the world
     @param maxy the max y dimensionality of the world
     */
    public HeatmapRenderLayer(DifferentiableStateActionValue vfa, List<GroundedAction> actions, int maxx, int maxy) {
        super();
        this.maxx = maxx;
        this.maxy = maxy;

        this.vfa = vfa;
        this.actions = actions;
    }

    public void setVFA(DifferentiableStateActionValue vfa) {
        this.vfa = vfa;
    }

    @Override
    public void render(Graphics2D g2, float cWidth, float cHeight) {
        super.render(g2, cWidth, cHeight);

        // State can be empty
        if (this.curState == null || this.curState.getObjectsOfClass(BlockDude.CLASSBRICKS).size() <= 0) {
			return; //don't render anything if there is no state to render
		}

        float domainXScale = (maxx) - minx;
        float domainYScale = (maxy) - miny;

        //determine then normalized width
        float width = (1.0f / domainXScale) * cWidth;
        float height = (1.0f / domainYScale) * cHeight;

        double[][] values = new double[(int) domainYScale + 1][(int) domainXScale + 1];
        int[][] actionIndices = new int[(int) domainYScale + 1][(int) domainXScale + 1];

        Pair<Double, Double> globalMinMax = valuesToPlot(values, actionIndices);
        final double globalMin = globalMinMax.getLeft();
        final double globalMax = globalMinMax.getRight();

        final Color[][] colors = generateHeatMap(values, actionIndices, GLOBAL_REWARD_MIN, GLOBAL_REWARD_MAX);

        for (int agentY = miny; agentY <= maxy; agentY++) {
            for (int agentX = minx; agentX <= maxx; agentX++) {
                float rx = agentX * width;
                float ry = cHeight - height - agentY * height;
                g2.setColor(colors[agentY][agentX]);
                g2.fill(new Rectangle2D.Float(rx, ry, width, height));

                // Draw first letter of action
                g2.setColor(new Color(255, 255, 255, HEATMAP_TRANSPARENCY));
                String label;
                if (actionIndices[agentY][agentX] == -1) {
                    label = "t";
                } else {
                    label = actions.get(actionIndices[agentY][agentX]).actionName().substring(0, 1);
                }
                g2.drawString(label, rx + width / 2, ry + height / 2);
            }
        }
        renderLegend(g2);
    }

    void renderLegend(Graphics2D g2) {
        // Render legend
        int ascent = g2.getFontMetrics(g2.getFont()).getAscent();
        int descent = g2.getFontMetrics(g2.getFont()).getDescent();
        for (int i = 0; i < actions.size(); i++) {
            int y = 5 + 15 * i;
            Color max = Color.getHSBColor(COLORS[i][0], COLORS[i][1], 1.0f);
            Color min = Color.getHSBColor(COLORS[i][0], COLORS[i][1], 0.5f);
            GradientPaint gradient = new GradientPaint(0.0f, 0.0f, min, 30.0f, 0.0f, max);
            g2.setPaint(gradient);
            g2.fill(new Rectangle2D.Float(0.0f, y, 30.0f, 10.0f));
            g2.setColor(Color.BLACK);
            g2.drawString(actions.get(i).actionName(), 35, y + ascent - descent);
        }
    }

    Pair<Double, Double> valuesToPlot(double[][] values, int[][] actionIndices) {
        double global_max = Double.NEGATIVE_INFINITY;
        double global_min = Double.MAX_VALUE;
        for (int agentY = miny; agentY <= maxy; agentY++) {
            for (int agentX = minx; agentX <= maxx; agentX++) {
                // The state being queried needs to be unique (by hash) every time.
                // Otherwise the feature extractor cache will just return the same
                // features even though we're modifiying them.
                State copy = this.curState.copy();
                copy.setObjectsValue(BlockDude.CLASSAGENT, BlockDude.ATTX, agentX);
                copy.setObjectsValue(BlockDude.CLASSAGENT, BlockDude.ATTY, agentY);

                // Pick max action
                double max = Double.NEGATIVE_INFINITY;
                int idx = 0;
                for (int i = 0; i < actions.size(); i++) {
                    double val = vfa.evaluate(copy, actions.get(i));
                    if (val > max) {
                        max = val;
                        idx = i;
                    } else if (val == max) {
                        idx = -1;
                    }
                }

                values[agentY][agentX] = max;
                actionIndices[agentY][agentX] = idx;

                if (max > global_max) {
                    global_max = max;
                }

                if (max < global_min) {
                    global_min = max;
                }
            }
        }
        return new ImmutablePair<>(global_min, global_max);
    }

    Color[][] generateHeatMap(double[][] values, int[][] actionIndices, double globalMin, double globalMax) {
        Color[][] colors = new Color[values.length][values[0].length];
        for (int i = 0; i < values.length; i++) {
            for (int j = 0; j < values[0].length; j++) {
                float[] color;
                if (actionIndices[i][j] == -1) {
                    color = new float[3];
                } else {
                    color = COLORS[actionIndices[i][j]];
                }
                double val = values[i][j];

                // Scale between 0.0 - 0.5
                double normalized_val = (0.5 * (val - globalMin)) / (globalMax - globalMin);

                // Brightness should be between 0.3 to 1.0
                // The higher the value, the lower the brightness
                Color baseCol = Color.getHSBColor(color[0], color[1], 0.5f + (float) normalized_val);
                colors[i][j] = new Color(baseCol.getRed(), baseCol.getGreen(), baseCol.getBlue(), HEATMAP_TRANSPARENCY);
            }
        }

        return colors;
    }

}
