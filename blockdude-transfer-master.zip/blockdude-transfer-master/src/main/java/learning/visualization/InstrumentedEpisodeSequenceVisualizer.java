package learning.visualization;

import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.auxiliary.EpisodeSequenceVisualizer;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.states.MutableState;
import burlap.oomdp.core.states.State;
import burlap.oomdp.visualizer.Visualizer;

import javax.swing.event.ListSelectionEvent;
import java.util.List;
import java.util.function.BiConsumer;

public class InstrumentedEpisodeSequenceVisualizer extends EpisodeSequenceVisualizer {

    // Current episode number (0 indexed)
    private int curEN = 0;

    private BiConsumer<Integer, Integer> selectionDidChange = null;

    public InstrumentedEpisodeSequenceVisualizer(Visualizer v, Domain d, String experimentDirectory) {
        super(v, d, experimentDirectory);
    }

    public InstrumentedEpisodeSequenceVisualizer(Visualizer v, Domain d, String experimentDirectory, int w, int h) {
        super(v, d, experimentDirectory, w, h);
    }

    public InstrumentedEpisodeSequenceVisualizer(Visualizer v, Domain d, List<EpisodeAnalysis> episodes) {
        super(v, d, episodes);
    }

    public InstrumentedEpisodeSequenceVisualizer(Visualizer v, Domain d, List<EpisodeAnalysis> episodes, int w, int h) {
        super(v, d, episodes, w, h);
    }

    /**
     * Set callback for when a new iteration selection happens
     *
     * @param callback Function that takes episode number and step number
     */
    public void setSelectionDidChange(BiConsumer<Integer, Integer> callback) {
        this.selectionDidChange = callback;
    }

    @Override
    protected void handleIterationSelection(ListSelectionEvent e) {

        if (!e.getValueIsAdjusting()) {

            if (iterationList.getSelectedIndex() != -1) {
                //System.out.println("Changing visualization...");
                int index = iterationList.getSelectedIndex();

                State curState = curEA.getState(index);

                // Call callback
                if (selectionDidChange != null) {
                    selectionDidChange.accept(curEN, index);
                }

                //draw it and update prop list
                //System.out.println(curState.getCompleteStateDescription()); //uncomment to print to terminal
                painter.updateState(curState);
                this.updatePropTextArea(curState);

                //System.out.println("Finished updating visualization.");
            } else {
                //System.out.println("canceled selection");
            }

        }

    }

    @Override
    protected void handleEpisodeSelection(ListSelectionEvent e) {

        if (!e.getValueIsAdjusting()) {

            int ind = episodeList.getSelectedIndex();
            //System.out.println("epsidoe id: " + ind);
            if (ind != -1) {

                //System.out.println("Loading Episode File...");
                if (this.directEpisodes == null) {
                    curEA = EpisodeAnalysis.parseFileIntoEA(episodeFiles.get(ind), domain);
                    curEN = ind;
                } else {
                    curEA = this.directEpisodes.get(ind);
                    curEN = ind;
                }
                //curEA = EpisodeAnalysis.readEpisodeFromFile(episodeFiles.get(ind));
                //System.out.println("Finished Loading Episode File.");

                painter.updateState(new MutableState()); //clear screen
                this.setIterationListData();

            } else {
                //System.out.println("canceled selection");
            }

        }


    }
}
