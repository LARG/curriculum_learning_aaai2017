package learning;


import burlap.behavior.singleagent.auxiliary.EpisodeSequenceVisualizer;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.FeatureDatabase;
import burlap.debugtools.RandomFactory;
import burlap.oomdp.visualizer.Visualizer;
import learning.experiment.*;
import learning.transfer.curriculum.AllMapPool;
import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.curriculum.automation.CurriculumGraphGenerator;
import learning.transfer.curriculum.automation.TransferPotentialFunction;
import learning.transfer.curriculum.hand.BlockDudeCompositeCurriculum;
import learning.transfer.vfa.VFAVersioner;
import learning.utilities.*;
import learning.visualization.*;
import org.apache.commons.cli.HelpFormatter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class Runner {
    private static CLIArgs args;

    /**
     * The entry point for the CLI
     *
     * @param argv
     */
    public static void main(String[] argv) {
        args = new CLIArgs(CLI.parseArgs(argv));

        if (args.randomSeed != null) {
            // This helps with debugging, but note that
            // it has no impact unless the curriculum streams are
            // deparallelized.
            RandomFactory.seedMapped(0, args.randomSeed);
        }

        if (args.help) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp(80, "Block Dude curriculum learning", "", CLI.createOptions(), "", true);
            return;
        }

        CLIArgs.Mode mode = args.mode;
        Integer curriculumNum = args.curriculum;

        switch (mode) {
            case GenerateCurriculumWithAllMaps: {
                BlockDudeExperiment.args = args;
                System.out.println("Generating curriculum...");
                BlockDudeCurriculum curriculum = generateCurriculumWithAllMaps();
                String experimentName = NamingUtilities.experimentName(curriculum.index, 0, curriculum.numSteps());
                BlockDudeExperiment.paths = new ExperimentOutPaths(args.logPath.resolve(experimentName));
                BlockDudeExperiment.clearPreviousResults();
                // Save images of all maps that we're going to be using to disk
                if (args.storeMapImages) {
                    Set<BlockDudeMap> maps = curriculum.mapsInStepRange(args.startStep, curriculum.numSteps());
                    for (BlockDudeMap map : maps) {
                        saveMapImage(map, BlockDudeExperiment.paths.base);
                    }
                }
                assessCurriculum(curriculum, 0, curriculum.numSteps() - 1, args.trials);

            }
            case GenerateCurriculum: {
                BlockDudeExperiment.args = args;
                System.out.println("Generating curriculum...");
                BlockDudeCurriculum curriculum = generateCurriculumWithSourcePool(curriculumNum);
                System.out.println(curriculum);
                String experimentName = NamingUtilities.experimentName(curriculum.index, 0, curriculum.numSteps());
                BlockDudeExperiment.paths = new ExperimentOutPaths(args.logPath.resolve(experimentName));
                // Save images of all maps that we're going to be using to disk
                BlockDudeExperiment.clearPreviousResults();
                if (args.storeMapImages) {
                    Set<BlockDudeMap> maps = curriculum.mapsInStepRange(args.startStep, curriculum.numSteps());
                    for (BlockDudeMap map : maps) {
                        saveMapImage(map, BlockDudeExperiment.paths.base);
                    }
                }
                assessCurriculum(curriculum, 0, curriculum.numSteps() - 1, args.trials);
                break;
            }
            case RunHandCurriculum: {

                String experimentName = NamingUtilities.experimentName(curriculumNum, args.startStep, args.endStep);
                BlockDudeExperiment.paths = new ExperimentOutPaths(args.logPath.resolve(experimentName));
                BlockDudeExperiment.args = args;
                BlockDudeCurriculum curriculum = BlockDudeCurriculum.withIndex(curriculumNum);
                BlockDudeExperiment.clearPreviousResults();
                // Save images of all maps that we're going to be using to disk
                if (args.storeMapImages) {
                    Set<BlockDudeMap> maps = curriculum.mapsInStepRange(args.startStep, args.endStep);
                    for (BlockDudeMap map : maps) {
                        saveMapImage(map, BlockDudeExperiment.paths.base);
                    }
                }
                BlockDudeExperiment.clearPreviousResults();
                assessCurriculum(curriculum, args.startStep, args.endStep, args.trials);

                break;
            }
            case VisualizeEpisodes: {
                BlockDudeCurriculum curriculum = generateCurriculumWithSourcePool(curriculumNum);
                Path path = FileUtilities.pickDirectory(args.logPath.toFile());
                if (path != null) {
                    // Is there a serialized VFA?
                    Path vfaPath = path.resolve("vfa.ser");
                    if (vfaPath.toFile().isFile()) {
                        visualizeSavedEpisodesWithVFA(curriculum, path, vfaPath);
                    } else {
                        visualizeSavedEpisodes(curriculum, path);
                    }
                }
                break;
            }
            case SaveMapImages: {
                Path outPath = args.logPath.resolve(Paths.get("maps"));
                try {
                    FileUtilities.deleteDirectory(outPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < BlockDudeCurriculum.numCurricula(); i++) {
                    saveCurriculumImages(BlockDudeCurriculum.withIndex(i), outPath);
                }
                break;
            }
            case SaveEpisodeImages: {
                BlockDudeCurriculum curriculum = generateCurriculumWithSourcePool(curriculumNum);
                Path path = FileUtilities.pickDirectory(args.logPath.toFile());
                String newName = path.getFileName().toString() + "_images";
                Path outPath = path.getParent().resolve(newName);
                outPath.toFile().mkdirs();
                saveEpisodeImagesToDisk(curriculum, path, outPath);
            }


        }

    }

    private static BlockDudeCurriculum generateCurriculumWithAllMaps() {
        CurriculumGraphGenerator generator = new CurriculumGraphGenerator(new TransferPotentialFunction());
        generator.useInterGroupTransfer = !args.intergroupTransferDisabled;
        generator.onlyUseLargestGroup = args.largestGroupOnly;
        Set<BlockDudeMap> sources = new HashSet<>();
        BlockDudeCurriculum sourceMapCurriculum;
        BlockDudeMap finalTarget;

        sourceMapCurriculum = new AllMapPool();
        // Subjectively, the hardest map we've got
        finalTarget = new BlockDudeCompositeCurriculum().mapWithIndex(5);

        sources.addAll(sourceMapCurriculum.mapsInStepRange(0, sourceMapCurriculum.numSteps()));

        sources.remove(finalTarget);

        BlockDudeCurriculum curriculum = generator.generate(sources, finalTarget);
        System.out.println(generator.describeIntermediateSteps(curriculum.mapsInStepRange(0, curriculum.numSteps() - 1), curriculum.mapWithIndex(curriculum.numTasks() - 1)));
        return curriculum;
    }

    private static void saveMapImage(BlockDudeMap map, Path outDir) {
        WorldComponents wc = new WorldComponents(map.curriculum, map.index);
        MapRenderer mr = new MapRenderer(wc.mapWidth(), wc.mapHeight());
        String fileName = map.index + ".png";
        Path path = outDir.resolve(fileName);
        path.toFile().mkdirs();
        mr.saveImage(wc.initialState, path.toFile());
    }

    /**
     * Runs a curriculum, logs the data, plots results, and
     * compares to from-scratch learning
     * @param curriculum
     * @param startStep
     * @param endStep
     * @param numTrials
     */
    private static void assessCurriculum(BlockDudeCurriculum curriculum, Integer startStep, Integer endStep, int numTrials) {
        int numSteps = endStep - startStep + 1;

        // Start timing
        final Date startStamp = new Date();
        long startTime = System.nanoTime();
        Map<BlockDudeCurriculum.Step, AggregatedTrial> transferResults = BlockDudeExperiment.runCurriculum(curriculum, startStep, endStep, numTrials);

        Map<BlockDudeMap, AggregatedTrial> scratchResults = new HashMap<>();
        String transferSummary = "";
        String transferPerformance = "";

        if (numSteps > 1) {
            Set<BlockDudeMap> maps = curriculum.mapsInStepRange(startStep, endStep + 1);
            scratchResults = getScratchResults(maps, numTrials);

            BlockDudeMap finalTarget = curriculum.step(endStep).target;
            CurriculumResults results = new CurriculumResults(transferResults, scratchResults, finalTarget);
            // Compares how long it took to learn from scratch against
            // the time spent in the curriculum
            transferSummary = results.summarize();
            transferPerformance = results.meanStepsToConvergenceDescription();
        }

        long endTime = System.nanoTime();
        long duration = endTime - startTime;
        final Date endStamp = new Date();

        if (args.storePlots) {
            System.out.println("Saving plots...");
            DataUtilities.generatePlots(BlockDudeExperiment.paths.plotsPath, transferResults, scratchResults);
        }
        System.out.println("Saving data...");
        DataUtilities.saveCSVs(BlockDudeExperiment.paths.dataPath, transferResults);
        DataUtilities.saveScratchCSVs(BlockDudeExperiment.paths.dataPath, scratchResults);

        final DateFormat formatter = new SimpleDateFormat();

        String summary = "Block Dude Experiment Results\n---\n\n";
        summary += "Started at " + formatter.format(startStamp) + " and ended at " + formatter.format(endStamp)
                + " (" + NamingUtilities.durationToString(duration) + ") \n";
        summary += transferSummary + "\n\n";

        summary += "## Per transfer step performance\n\n";
        summary += transferPerformance + "\n\n";
        summary += "## Parameters\n\n";
        summary += args + "\n\n";
        summary += "## Curriculum\n\n";
        summary += curriculum;
        DataUtilities.saveExperimentSummary(BlockDudeExperiment.paths.base, summary);

        System.out.println(summary);
    }

    /**
     * Generates a curriculum using the paper's algorithm.
     *
     * @param taskPool the index of the curriculum that will be used as the pool of tasks
     * @return
     */
    private static BlockDudeCurriculum generateCurriculumWithSourcePool(final int taskPool) {
        CurriculumGraphGenerator generator = new CurriculumGraphGenerator(new TransferPotentialFunction());
        generator.useInterGroupTransfer = !args.intergroupTransferDisabled;
        generator.onlyUseLargestGroup = args.largestGroupOnly;
        generator.largestInterGroupTargetOnly = args.largestIntergroupOnly;
        Set<BlockDudeMap> sources = new HashSet<>();
        BlockDudeCurriculum sourceMapCurriculum;
        BlockDudeMap finalTarget;

        sourceMapCurriculum = BlockDudeCurriculum.withIndex(taskPool);
        finalTarget = sourceMapCurriculum.mapWithIndex(sourceMapCurriculum.numTasks() - 1);

        sources.addAll(sourceMapCurriculum.mapsInStepRange(0, sourceMapCurriculum.numSteps()));

        sources.remove(finalTarget);
        BlockDudeCurriculum curriculum = generator.generate(sources, finalTarget);
        System.out.println(generator.describeIntermediateSteps(curriculum.mapsInStepRange(0, curriculum.numSteps() - 1), curriculum.mapWithIndex(curriculum.numTasks() - 1)));
        return curriculum;
    }

    /**
     * Opens an interactive visualizer with a versioned VFA overlay
     *
     * @param path
     * @param vfaPath
     */
    private static void visualizeSavedEpisodesWithVFA(BlockDudeCurriculum curriculum, Path path, Path vfaPath) {
        int mapNum = Integer.parseInt(path.getFileName().toString());

        WorldComponents wc = new WorldComponents(curriculum, mapNum);

        FeatureDatabase featureDatabase = VFAUtilities.createRBFFeatureDatabase(wc, 1, args.bandwidth);
        VFAVersioner versioner = new VFAVersioner(featureDatabase);
        try (
                FileInputStream is = new FileInputStream(vfaPath.toFile());
                ObjectInputStream os = new ObjectInputStream(is)
        ) {
            versioner.deserialize(os, wc.actions());
            versioner.setFeatureDatabase(featureDatabase);
        } catch (Exception e) {

        }

        DifferentiableStateActionValue snapshot = versioner.functionForSnapshot(0, 0);
        HeatmapRenderLayer hrl = new HeatmapRenderLayer(snapshot, wc.actions(), wc.mapWidth(), wc.mapHeight());
        Visualizer v = TastefulBlockDudeVisualizer.getVisualizer(hrl, wc.mapWidth(), wc.mapHeight());
        InstrumentedEpisodeSequenceVisualizer esv = new InstrumentedEpisodeSequenceVisualizer(v, wc.domain, path.toString());
        esv.setSelectionDidChange((episode, step) ->
                hrl.setVFA(versioner.functionForSnapshot(episode, step)));
    }

    /**
     * Opens an interactive visualizer for saved episodes
     *
     * @param path Path to a map folder in an experiment output directory
     */
    private static void visualizeSavedEpisodes(BlockDudeCurriculum curriculum, Path path) {
        int mapNum = Integer.parseInt(path.getFileName().toString());

        WorldComponents wc = new WorldComponents(curriculum, mapNum);

        Visualizer v = TastefulBlockDudeVisualizer.getVisualizer(wc.mapWidth(), wc.mapHeight());
        // This will open up an interface for browsing the episodes
        EpisodeSequenceVisualizer esv = new EpisodeSequenceVisualizer(v, wc.domain, path.toString());

    }

    /**
     * Saves images of all maps in a curriculum
     *
     * @param curriculum
     * @param outDir
     */
    private static void saveCurriculumImages(BlockDudeCurriculum curriculum, Path outDir) {
        for (int currentMap = 0; currentMap < curriculum.numTasks(); currentMap++) {
            saveMapImage(curriculum.mapWithIndex(currentMap), outDir);
        }
    }

    private static void saveEpisodeImagesToDisk(BlockDudeCurriculum curriculum, Path inDir, Path outDir) {
        int mapNum = Integer.parseInt(inDir.getFileName().toString());
        WorldComponents wc = new WorldComponents(curriculum, mapNum);

        FeatureDatabase featureDatabase = VFAUtilities.createRBFFeatureDatabase(wc, 1, args.bandwidth);
        VFAVersioner versioner = new VFAVersioner(featureDatabase);
        // Is there a saved VFA?
        Path vfaPath = inDir.resolve("vfa.ser");
        try (
                FileInputStream is = new FileInputStream(vfaPath.toFile());
                ObjectInputStream os = new ObjectInputStream(is)
        ) {
            versioner.deserialize(os, wc.actions());
            versioner.setFeatureDatabase(featureDatabase);
        } catch (Exception e) {
            versioner = null;
            System.out.println("Failed to deserialize VFA");
        }
        EpisodesToImages.process(inDir, outDir, wc, versioner);

    }

    private static Map<BlockDudeMap, AggregatedTrial> getScratchResults(Set<BlockDudeMap> maps, int numTrials) {
        Path scratchCache = args.logPath.resolve("scratch-cache");
        Map<BlockDudeMap, AggregatedTrial> scratchResults = new HashMap<>();
        for (BlockDudeMap map : maps) {

            // If only the final scratch is desired, then
            // if the current map is not the target of the last step, skip it
            if (args.onlyFinalScratch
                    && map.curriculum.stepWithTarget(map) != map.curriculum.step(map.curriculum.numSteps() - 1)) {
                continue;
            }

            AggregatedTrial result = ScratchResultsManager.loadResults(map, numTrials, scratchCache);
            if (result == null) {
                result = BlockDudeExperiment.runMapScratch(map, numTrials);
                ScratchResultsManager.saveResults(map, result, scratchCache);
            } else {
                System.out.println("Loading map " + map.index + " from cache");
            }
            scratchResults.put(map, result);
        }
        return scratchResults;
    }

    private static void saveMapImageWithVFAOverlay(BlockDudeMap map, Path outDir, DifferentiableStateActionValue vfa) {
        WorldComponents wc = new WorldComponents(map.curriculum, map.index);
        MapRenderer mr = new MapRenderer(wc.mapWidth(), wc.mapHeight());

        String fileName = map + "_vfa.png";
        Path path = outDir.resolve(fileName);
        path.toFile().mkdirs();
        mr.saveImage(wc.initialState, vfa, wc.actions(), path.toFile());
    }

}
