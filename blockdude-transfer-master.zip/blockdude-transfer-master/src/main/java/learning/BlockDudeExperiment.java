package learning;

import burlap.behavior.singleagent.EpisodeAnalysis;
import burlap.behavior.singleagent.learning.LearningAgent;
import burlap.behavior.singleagent.learning.LearningAgentFactory;
import burlap.behavior.singleagent.vfa.DifferentiableStateActionValue;
import burlap.behavior.singleagent.vfa.rbf.RBFFeatureDatabase;
import burlap.oomdp.singleagent.environment.SimulatedEnvironment;
import learning.experiment.*;
import learning.reward.BlockDudeGoalTrapRF;
import learning.reward.CombinedTerminalFunction;
import learning.reward.TrapBasedTerminalFunction;
import learning.transfer.ExtendedShapingRewardFunction;
import learning.transfer.TransferAgentFactories;
import learning.transfer.curriculum.BlockDudeCurriculum;
import learning.transfer.curriculum.BlockDudeMap;
import learning.transfer.vfa.VFAVersioner;
import learning.transfer.vfa.VersionableLinearVFA;
import learning.utilities.DataUtilities;
import learning.utilities.ExperimentOutPaths;
import learning.utilities.FileUtilities;
import learning.utilities.VFAUtilities;
import learning.visualization.MapRenderer;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class BlockDudeExperiment {

    public static ExperimentOutPaths paths;
    public static CLIArgs args;

    static void clearPreviousResults() {
        // Clear the existing results
        try {
            FileUtilities.deleteDirectory(BlockDudeExperiment.paths.base);
        } catch (Exception e) {
            System.out.println("Unable to clear experiment output directory.");
            System.exit(-1);
        }
    }

    static Map<BlockDudeCurriculum.Step, AggregatedTrial> runCurriculum(BlockDudeCurriculum curriculum, int startStep, int endStep, int numberOfTrials) {
        // We'll index VFAs by map. Each map will have a list of VFAs, where the index into the list is the VFA for a
        // particular trial.
        Map<BlockDudeMap, DifferentiableStateActionValue[]> learnedVfas = new HashMap<>();

        // Initially, every map has just an list of nulls for each trial.
        for (int i = 0; i < curriculum.numTasks(); i++) {
            BlockDudeMap map = curriculum.mapWithIndex(i);
            DifferentiableStateActionValue[] trials = new DifferentiableStateActionValue[numberOfTrials];
            learnedVfas.put(map, trials);
        }

        Map<BlockDudeCurriculum.Step, AggregatedTrial> aggregatedTrials = new HashMap<>();

        for (int currentStep = startStep; currentStep <= endStep; currentStep++) {
            final BlockDudeCurriculum.Step step = curriculum.step(currentStep);
            AggregatedTrial aggregatedTrial = new AggregatedTrial();
            int finalCurrentStep = currentStep;
            IntStream.range(0, numberOfTrials).parallel().mapToObj(trialNum -> {
                System.out.println("Step " + step.index + ": " + step + " trial: " + (trialNum + 1) + "/" + numberOfTrials);
                WorldComponents wc = new WorldComponents(curriculum, step.target.index);
                List<DifferentiableStateActionValue> sourceVFAs = step.sources.stream()
                        .map(source -> learnedVfas.get(source)[trialNum])
                        .collect(Collectors.toCollection(LinkedList::new));
                // The curriculum should not tell us to use sources we haven't learned yet.
                sourceVFAs.forEach(vfa -> {
                    assert (vfa != null);
                });
                TrialResult result;

                // Visualize the first trial
                if (trialNum == 0 && args.storeVisualizationData) {
                    VFAVersioner versioner = new VFAVersioner(null);

                    if (finalCurrentStep == endStep && args.extendFinalEvaluation) {
                        result = runFinalTargetTrial(sourceVFAs, wc, versioner);
                    } else {
                        result = runTransferTrial(sourceVFAs, wc, versioner);
                    }

                    System.out.println("Saving visualization data...");
                    DataUtilities.writeVisualizationData(result.episodeAnalyses, paths.visualizationPath, step);

                    // Output weights
                    Path vfaOutPath = paths.visualizationPath.resolve(step.index + "/vfa.ser");
                    vfaOutPath.toFile().getParentFile().mkdirs();
                    try (
                            FileOutputStream fs = new FileOutputStream(vfaOutPath.toFile());
                            ObjectOutputStream os = new ObjectOutputStream(fs)
                    ) {
                        versioner.serialize(os);
                    } catch (Exception e) {
                        System.out.println("Failed to serialize vfa");
                    }

                    String fileName = step.index + "_vfa.png";
                    Path path = paths.vfaPath.resolve(fileName);
                    path.toFile().mkdirs();
                    MapRenderer renderer = new MapRenderer(wc.mapWidth(), wc.mapHeight());
                    renderer.saveImage(wc.initialState, result.learnedVFA, wc.actions(), path.toFile());

                } else {
                    if (finalCurrentStep == endStep && args.extendFinalEvaluation) {
                        result = runFinalTargetTrial(sourceVFAs, wc, null);
                    } else {
                        result = runTransferTrial(sourceVFAs, wc, null);
                    }
                }

                learnedVfas.get(step.target)[trialNum] = result.learnedVFA;
                return result.logs;
            }).forEach(aggregatedTrial::combineWith);
            aggregatedTrial.finalizeVariances();
            aggregatedTrials.put(step, aggregatedTrial);

            if (!step.hasSources()) {
                ScratchResultsManager.saveResultsIfMoreTrials(step.target, aggregatedTrial, paths.base.getParent().resolve("scratch-cache"));

            }
        }

        System.out.println("Finished running curriculum");

        return aggregatedTrials;
    }

    static TrialResult runFinalTargetTrial(List<DifferentiableStateActionValue> sourceVFAs, WorldComponents wc, VFAVersioner versioner) {

        CombinedTerminalFunction combined = new CombinedTerminalFunction();
        combined.addTerminalFunction(BlockDudeGoalTrapRF.GOAL_TF, wc.tf);
        combined.addTerminalFunction(BlockDudeGoalTrapRF.TRAP_TF, new TrapBasedTerminalFunction());
        BlockDudeGoalTrapRF grf = new BlockDudeGoalTrapRF(combined, 50.0, -5., -1.0);

        // Use look-ahead or look-back advice based on command line argument
        final ExtendedShapingRewardFunction rf = ExtendedShapingRewardFunction.create(grf, sourceVFAs, args.advice == CLIArgs.Advice.Behind, args.gamma);

        RBFFeatureDatabase featureDatabase = VFAUtilities.createRBFFeatureDatabase(wc, args.perceptionDepth, args.bandwidth);
        DifferentiableStateActionValue vfa;
        if (versioner != null) {
            vfa = new VersionableLinearVFA(featureDatabase, args.defaultWeightValue);
        } else {
            vfa = featureDatabase.generateVFA(args.defaultWeightValue);
        }

        LearningAgentFactory factory;
        factory = TransferAgentFactories.getGradientDescentSarsaLamTransferFactory(wc.domain, vfa, rf, args.alpha, args.epsilon, args.lambda, args.gamma);
        LearningAgent agent = factory.generateAgent();

        //define learning environment
        SimulatedEnvironment env = new SimulatedEnvironment(wc.domain, rf, combined, wc.stateGenerator);

        if (versioner != null) {
            versioner.setFeatureDatabase(featureDatabase);
            VFAVersioningEnvironmentObserver observer = new VFAVersioningEnvironmentObserver((VersionableLinearVFA) vfa, versioner);
            env.addObservers(observer);
        }

        EvaluationEnvironmentObserver evaluationObserver = new EvaluationEnvironmentObserver(wc.curriculum, agent, sourceVFAs, wc.map.index, args.steps, args.evaluationPeriod, args.gamma);
        env.addObservers(evaluationObserver);

        ConvergenceDetectingTrialRunner experimenter = new ConvergenceDetectingTrialRunner(env, evaluationObserver, 300, args.steps, agent);
        // Set a criteria that will not be met
        experimenter.convergenceCriteria = new TimesSeenConvergenceCriteria(3000);
        grf.setStepsLeftSupplier(experimenter::numStepsLeft);
        LoggingEnvironmentObserver.Trial trial = experimenter.run();

        trial.evaluationRewards = evaluationObserver.getEvaluationRewards();

        return new TrialResult(vfa, trial, experimenter.getEpisodeAnalysis());

    }

    static TrialResult runTransferTrial(List<DifferentiableStateActionValue> sourceVFAs, WorldComponents wc, VFAVersioner versioner) {

        CombinedTerminalFunction combined = new CombinedTerminalFunction();
        combined.addTerminalFunction(BlockDudeGoalTrapRF.GOAL_TF, wc.tf);
        combined.addTerminalFunction(BlockDudeGoalTrapRF.TRAP_TF, new TrapBasedTerminalFunction());
        BlockDudeGoalTrapRF grf = new BlockDudeGoalTrapRF(combined, 50.0, -5., -1.0);

        // Use look-ahead or look-back advice based on command line argument
        final ExtendedShapingRewardFunction rf = ExtendedShapingRewardFunction.create(grf, sourceVFAs, args.advice == CLIArgs.Advice.Behind, args.gamma);

        RBFFeatureDatabase featureDatabase = VFAUtilities.createRBFFeatureDatabase(wc, args.perceptionDepth, args.bandwidth);
        DifferentiableStateActionValue vfa;
        if (versioner != null) {
            vfa = new VersionableLinearVFA(featureDatabase, args.defaultWeightValue);
        } else {
            vfa = featureDatabase.generateVFA(args.defaultWeightValue);
        }

        LearningAgentFactory factory;
        factory = TransferAgentFactories.getGradientDescentSarsaLamTransferFactory(wc.domain, vfa, rf, args.alpha, args.epsilon, args.lambda, args.gamma);
        LearningAgent agent = factory.generateAgent();

        //define learning environment
        SimulatedEnvironment env = new SimulatedEnvironment(wc.domain, rf, combined, wc.stateGenerator);

        if (versioner != null) {
            versioner.setFeatureDatabase(featureDatabase);
            VFAVersioningEnvironmentObserver observer = new VFAVersioningEnvironmentObserver((VersionableLinearVFA) vfa, versioner);
            env.addObservers(observer);
        }

        EvaluationEnvironmentObserver evaluationObserver = new EvaluationEnvironmentObserver(wc.curriculum, agent, sourceVFAs, wc.map.index, args.steps, args.evaluationPeriod, args.gamma);
        env.addObservers(evaluationObserver);

        TrialRunner experimenter = new ConvergenceDetectingTrialRunner(env, evaluationObserver, args.episodes, args.steps, agent);
        grf.setStepsLeftSupplier(experimenter::numStepsLeft);
        LoggingEnvironmentObserver.Trial trial = experimenter.run();

        trial.evaluationRewards = evaluationObserver.getEvaluationRewards();

        return new TrialResult(vfa, trial, experimenter.getEpisodeAnalysis());

    }

    public static AggregatedTrial runMapScratch(final BlockDudeMap map, final int numberOfTrials) {
        // Evaluate from scratch
        System.out.println("Evaluating from scratch...");
        DifferentiableStateActionValue emptyVfa = new RBFFeatureDatabase(true).generateVFA(0.);
        DifferentiableStateActionValue[] learnedVfas = new DifferentiableStateActionValue[numberOfTrials];
        for (int i = 0; i < learnedVfas.length; i++) {
            learnedVfas[i] = (DifferentiableStateActionValue) emptyVfa.copy();
        }

        AggregatedTrial scratchAggregated = new AggregatedTrial();
        IntStream.range(0, numberOfTrials).parallel().mapToObj(trialNum -> {
            System.out.println("Scratch map: " + map.index + " trial: " + (trialNum + 1) + "/" + numberOfTrials);
            WorldComponents wc = new WorldComponents(map.curriculum, map.index);
            List<DifferentiableStateActionValue> sources = new LinkedList<>();
            sources.add(learnedVfas[trialNum]);
            TrialResult result = runTransferTrial(sources, wc, null);
            return result.logs;
        }).forEach(scratchAggregated::combineWith);
        scratchAggregated.finalizeVariances();

        return scratchAggregated;
    }

    public static class TrialResult {
        public final DifferentiableStateActionValue learnedVFA;
        public final LoggingEnvironmentObserver.Trial logs;
        public final List<EpisodeAnalysis> episodeAnalyses;

        public TrialResult(DifferentiableStateActionValue learnedVFA,
                           LoggingEnvironmentObserver.Trial logs,
                           List<EpisodeAnalysis> episodeAnalyses) {

            this.learnedVFA = learnedVFA;
            this.logs = logs;
            this.episodeAnalyses = episodeAnalyses;
        }
    }


}
