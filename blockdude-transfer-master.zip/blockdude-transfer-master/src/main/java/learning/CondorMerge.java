package learning;

import learning.experiment.AggregatedTrial;
import learning.experiment.LoggingEnvironmentObserver;
import learning.utilities.DataUtilities;
import learning.utilities.FileUtilities;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class CondorMerge {

    // Number of steps to extend the evaluation rewards
    private static final int EVALUATION_EXTENSION = 10000;

    /**
     * Merge all files of the same name across many experiment directories.
     * Works for Condor output, as well as `RunMany` output.
     *
     * @param args
     */
    public static void main(String[] args) {
        Path parentDir = new File(args[0]).toPath();
        Map<String, AggregatedTrial> aggregatedByName = mergeAllFilesWithSameName(parentDir);

        saveCSVs(parentDir.resolve("combined"), aggregatedByName);

    }

    public static Map<String, AggregatedTrial> mergeAllFilesWithSameName(Path parentDirectory) {
        List<File> dataDirectories = getDataDirectories(parentDirectory);
        Map<String, Pair<List<File>, List<File>>> grouped = groupFiles(dataDirectories);
        Map<String, List<LoggingEnvironmentObserver.Trial>> asTrials = groupsToTrials(grouped);
        Map<String, AggregatedTrial> aggregated = aggregateGroupedTrials(asTrials);
        return aggregated;

    }

    public static void saveCSVs(Path outPath, Map<String, AggregatedTrial> trials) {
        List<Path> csvFiles = new LinkedList<>();
        for (Map.Entry<String, AggregatedTrial> entry : trials.entrySet()) {
            // Write episode-wise data
            String episodefileName = entry.getKey();
            csvFiles.add(DataUtilities.writeTrialToCSV(entry.getValue(), outPath.resolve(episodefileName), true));

            // Write step-wise data
            String stepfileName = entry.getKey() + "-stepwise";
            csvFiles.add(DataUtilities.writeTrialToCSV(entry.getValue(), outPath.resolve(stepfileName), false));
        }
    }

    /**
     * Searches all subdirectories for `data` directories
     *
     * @param parentDirectory
     * @return a list of data directories
     */
    private static List<File> getDataDirectories(Path parentDirectory) {
        // The root is assumed to contain a number of folders indexed by process ID
        File[] directories = parentDirectory.toFile().listFiles(File::isDirectory);
        List<File> dataDirectories = new LinkedList<>();
        for (File directory : directories) {
            // Each process ID directory is assumed to contain a scratch cache and an experiment directory
            File[] subDirectories = directory.listFiles(File::isDirectory);
            for (File subDirectory : subDirectories) {
                // The experiment directory will have a data subdirectory
                File dataDir = subDirectory.toPath().resolve("data").toFile();
                if (dataDir.exists()) {
                    dataDirectories.add(dataDir);
                }
            }
        }
        return dataDirectories;
    }

    /**
     * Collects all files that correspond to the same trial across the different directories.
     *
     * @param dataDirectories
     * @return a map from a string that describes the trial to a pair of lists; the left is episodic data and the right is stepwise data
     */
    private static Map<String, Pair<List<File>, List<File>>> groupFiles(List<File> dataDirectories) {
        Map<String, Pair<List<File>, List<File>>> allFilesOfAName = new HashMap<>();
        for (File dataDir : dataDirectories) {

            // File names to ignore
            String[] ignoreFiles = { ".DS_Store" };

            // List data files
            File[] dataFiles = dataDir.listFiles(pathname -> pathname.isFile() && !Arrays.asList(ignoreFiles).contains(pathname.getName()));

            for (File dataFile : dataFiles) {
                final String name = dataFile.getName();
                final String indexName = dataFile.getName().replace("-stepwise", "");
                Pair<List<File>, List<File>> files = allFilesOfAName.getOrDefault(indexName, new ImmutablePair<>(new LinkedList<>(), new LinkedList<>()));
                if (name.contains("stepwise")) {
                    files.getRight().add(dataFile);
                } else {
                    files.getLeft().add(dataFile);
                }
                allFilesOfAName.put(indexName, files);
            }
        }
        return allFilesOfAName;
    }

    private static Map<String, List<LoggingEnvironmentObserver.Trial>> groupsToTrials(Map<String, Pair<List<File>, List<File>>> groups) {
        Map<String, List<LoggingEnvironmentObserver.Trial>> namesToTrials = new HashMap<>();
        for (Map.Entry<String, Pair<List<File>, List<File>>> entry : groups.entrySet()) {
            List<File> episodic = entry.getValue().getLeft();
            List<File> stepwise = entry.getValue().getRight();
            String name = entry.getKey();

            for (int i = 0; i < episodic.size(); i++) {
                File episodeFile = episodic.get(i);
                File stepwiseFile = stepwise.get(i);

                episodeFile = FileUtilities.unzip(episodeFile.toPath());
                stepwiseFile = FileUtilities.unzip(stepwiseFile.toPath());

                try {
                    List<String> lines = Files.readAllLines(episodeFile.toPath(), StandardCharsets.UTF_8);
                    List<String> stepwiseLines = Files.readAllLines(stepwiseFile.toPath(), StandardCharsets.UTF_8);
                    AggregatedTrial trial = DataUtilities.readEpisodeInformation(lines);
                    trial.evaluationReward = DataUtilities.readStepwiseInformation(stepwiseLines, trial.nTrials);

                    // Evaluation period step size
                    assert(trial.evaluationReward.size() > 1);
                    int evaluationStepSize = trial.evaluationReward.get(1).getLeft() - trial.evaluationReward.get(0).getLeft();

                    // Extend evaluation rewards
                    for (int n = 0; n < EVALUATION_EXTENSION / evaluationStepSize; n++) {
                        Pair<Integer, AggregatedTrial.StatPair> lastER = trial.evaluationReward.get(trial.evaluationReward.size() - 1);
                        trial.evaluationReward.add(new ImmutablePair<>(lastER.getLeft() + evaluationStepSize, lastER.getRight()));
                    }

                    List<LoggingEnvironmentObserver.Trial> trials = namesToTrials.getOrDefault(name, new LinkedList<>());
                    trials.add(aggregateToSingle(trial));
                    namesToTrials.put(name, trials);

                } catch (IOException e) {

                }
                FileUtilities.deleteFile(episodeFile.toPath());
                FileUtilities.deleteFile(stepwiseFile.toPath());
            }
        }
        return namesToTrials;
    }

    private static Map<String, AggregatedTrial> aggregateGroupedTrials(Map<String, List<LoggingEnvironmentObserver.Trial>> asTrials) {
        Map<String, AggregatedTrial> namesToAggregates = new HashMap<>();
        for (Map.Entry<String, List<LoggingEnvironmentObserver.Trial>> entry : asTrials.entrySet()) {
            AggregatedTrial aggregate = new AggregatedTrial();
            entry.getValue().forEach(aggregate::combineWith);
            aggregate.finalizeVariances();
            namesToAggregates.put(entry.getKey(), aggregate);
        }
        return namesToAggregates;
    }

    private static LoggingEnvironmentObserver.Trial aggregateToSingle(AggregatedTrial single) {
        assert single.nTrials == 1;
        LoggingEnvironmentObserver.Trial trial = new LoggingEnvironmentObserver.Trial();
        trial.stepsPerEpisode = stripVariances(single.stepsPerEpisode);
        trial.evaluationRewards = stripVariancesPairs(single.evaluationReward);
        trial.totalSteps = trial.stepsPerEpisode.stream().mapToInt(Double::intValue).sum();
        // If there's no step episode data, use the mean time to convergence, which is the same for n = 1
        if (trial.totalSteps == 0) {
            trial.totalSteps = (int) single.meanStepsTilConvergence.mean;
        }
        trial.totalEpisodes = trial.stepsPerEpisode.size();
        return trial;
    }

    private static List<Double> stripVariances(List<AggregatedTrial.StatPair> pairs) {
        List<Double> stripped = new LinkedList<>();
        for (AggregatedTrial.StatPair pair : pairs) {
            stripped.add(pair.mean);
        }
        return stripped;
    }

    private static List<Pair<Integer, Integer>> stripVariancesPairs(List<Pair<Integer, AggregatedTrial.StatPair>> evaluationReward) {
        List<Pair<Integer, Integer>> stripped = new LinkedList<>();
        for (int i = 0; i < evaluationReward.size(); i++) {
            Pair<Integer, AggregatedTrial.StatPair> point = evaluationReward.get(i);
            stripped.add(new ImmutablePair<>(point.getLeft(), (int) point.getRight().mean));
        }
        return stripped;
    }
}
