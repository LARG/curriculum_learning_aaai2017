import numpy as np
import math
from scipy import stats
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib import pyplot

significance_level = 0.05

# Max's template:
#pyplot.errorbar(x=range(len(targetTask)), y=targetTask[:,1], yerr=targetStderr, color='r', label="Baseline Q-Learning Agent", errorevery=200, markevery=100, markersize=4, marker='x')

trials = 1000 # Number of trials that were averaged
cutoff = 19000 # X value to cutoff the graph at (set to 0 to disable)
c1_offset = 8489 # Offset of c1
c2_offset = 9146 # Offset of c2

def prepare_data(csvpath, num_trials, x_offset=0, cutoff=0):
    data = np.genfromtxt(csvpath, delimiter=',', skip_header=1)
    data[:, 0] += x_offset

    if cutoff > 0:
        # Grab the first index where x > cutoff
        indices = np.where(data[:, 0] >= cutoff)[0]
        if len(indices) < 1:
            print("Cutoff too large\n\n")
        idx = indices[0]
        data = data[0:idx, :]

    data_crit = stats.t.ppf(1.0 - (significance_level / 2.0), num_trials - 1)
    data_conf = map(lambda variance: (data_crit * math.sqrt(variance)) / math.sqrt(num_trials), data[:, 2])
    return (data, data_conf)

basecurve, basecurve_conf = prepare_data('basecurve.csv', trials, cutoff=cutoff)
c1, c1_conf = prepare_data('c1.csv', trials, x_offset=c1_offset, cutoff=cutoff)
c2, c2_conf = prepare_data('c2.csv', trials, x_offset=c2_offset, cutoff=cutoff)

pyplot.errorbar(x=basecurve[:, 0], y=basecurve[:, 1], yerr=basecurve_conf, color='r', label="Scratch", errorevery=2)

pyplot.errorbar(x=c1[:, 0], y=c1[:, 1], yerr=c1_conf, color='b', label="Full Curriculum", errorevery=2, markevery=2, markersize=4, marker='D')

pyplot.errorbar(x=c2[:, 0], y=c2[:, 1], yerr=c2_conf, color='c', ls='dashed', label="Curriculum Subset", errorevery=2)

pyplot.axes().set_xlabel("Time Steps")
pyplot.axes().set_ylabel("Evaluation Reward")

# loc: 0 for best
# loc: 4 for bottom right
pyplot.legend(loc=0)

# Uncomment to show the graph
# pyplot.show()

pdf = PdfPages('plot.pdf')
pdf.savefig()
pdf.close()
