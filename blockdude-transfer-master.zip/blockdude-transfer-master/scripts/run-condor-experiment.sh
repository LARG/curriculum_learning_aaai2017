#!/usr/bin/env bash

###### Arguments ########
# 1) num of experiments #
# 2) output directory   #
# 3) extra args         #
#########################

if [ "$#" -ne 3 ]; then
    echo "Incorrect parameters"
    exit 1
fi

# CD to enclosing directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Compile code (comment to compile/pack every time)
(cd ..; sbt assembly)


# Make a timestamped directory in the out dir that was passed in
OUTPUT_DIR="$( readlink -f "$2" )"
TIMESTAMP="$(date +%a-%b-%d-%T)"
OUTPUT_DIR="$OUTPUT_DIR/$TIMESTAMP"

mkdir -p "$OUTPUT_DIR/logs"
mkdir -p "$OUTPUT_DIR/out"


# Form the final argument string that condor will use to run the code
NUM_TRIALS="$1"
# Example: generate-curriculum 4 -episodes 200 -steps 200 -evaluation-period 100
EXPERIMENT_ARGS="$3"

# Run the experiment the user wants massively in parallel, with a few outputs disabled
ARGUMENTS="learning.Runner ${EXPERIMENT_ARGS} -trials 1 -log ${OUTPUT_DIR}/out/\$(Process) -no-plots -no-map-images"

# Write condor submission file
JAR_FULLPATH="$( readlink -f ../target/blockdude-*.jar )"
cat << EOF > submit.condor
Universe        = java
Executable      = $JAR_FULLPATH
Error           = $OUTPUT_DIR/logs/err.\$(cluster)
Output          = $OUTPUT_DIR/logs/out.\$(cluster)
Log             = $OUTPUT_DIR/logs/log.\$(cluster)
jar_files       = $JAR_FULLPATH

+Group = "UNDER"
+Project = "AI_ROBOTICS"
+ProjectDescription = "Curriculum learning on the Block Dude domain"

Arguments       = $ARGUMENTS
Queue $NUM_TRIALS
EOF

echo "======== Condor Submission ========="
cat submit.condor

condor_submit submit.condor

# Save the submission to the results folder
mv submit.condor $OUTPUT_DIR/arguments.txt