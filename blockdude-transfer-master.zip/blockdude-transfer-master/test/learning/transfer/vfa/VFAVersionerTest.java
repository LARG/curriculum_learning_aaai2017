package learning.transfer.vfa;

import burlap.behavior.singleagent.vfa.FeatureDatabase;
import burlap.behavior.singleagent.vfa.rbf.RBFFeatureDatabase;
import junit.framework.TestCase;

import java.io.File;

public class VFAVersionerTest extends TestCase {
    public void testSerialize() {
        File outFile = new File("/tmp/test.ser");

        FeatureDatabase featureDatabase = new RBFFeatureDatabase(false);

        VFAVersioner versioner = new VFAVersioner(featureDatabase);
    }

}
