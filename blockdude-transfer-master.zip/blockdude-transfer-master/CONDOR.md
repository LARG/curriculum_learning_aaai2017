Condor Experiments
========================

### Packaging

First, install `sbt` on the CS lab machines, and add it to your PATH for convenience.

    curl -L 'https://dl.bintray.com/sbt/native-packages/sbt/0.13.9/sbt-0.13.9.tgz' | tar xz

Copy `.sbtopts.example` to `.sbtopts`. This contains the JAVA_HOME path, which can be changed if necessary.

To generate the uber jar, run:

    sbt assembly

### Scheduling on Condor

SSH into `submit64` and execute the script.

    run-condor-experiment.sh <number of trials> <results path> <experiment arguments>

To run the experiments on Condor, run the Condor submission script (in the `scripts` directory) passing it arguments as usual, but leave out number of trials, mode, and log. The script will pass the appropriate values for these. For example:

    ./run-condor-experiment.sh 10 ../results "generate -curriculum 4 -episodes 200 -steps 100"

*Note*: The program arguments **must** be in quotes.

You can check the status of the jobs by running `condor_q`. When they are all complete, you should see the output inside an `out` directory at the location you specified.

### Post-processing

To merge all of the trials and get means and variances, run the main method of CondorMerge on the output directory. It will produce a new directory, `combined`.
